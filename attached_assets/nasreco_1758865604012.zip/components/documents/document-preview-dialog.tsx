"use client"

import { useState, useEffect } from "react"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import {
  FileText,
  ImageIcon,
  Edit3,
  Save,
  RotateCcw,
  Download,
  Tag,
  Clock,
  CheckCircle,
  AlertCircle,
  Loader2,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"

import { DocumentType, OCRStatus, type PatientDocument } from "@/lib/db/document-schema"

interface DocumentPreviewDialogProps {
  document: PatientDocument | null
  isOpen: boolean
  onClose: () => void
  onUpdateText: (documentId: string, newText: string) => void
}

export function DocumentPreviewDialog({ document, isOpen, onClose, onUpdateText }: DocumentPreviewDialogProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [editedText, setEditedText] = useState("")
  const [isSaving, setIsSaving] = useState(false)

  useEffect(() => {
    if (document?.ocrText) {
      setEditedText(document.ocrText)
    }
  }, [document])

  const getDocumentTypeLabel = (type: DocumentType): string => {
    const labels = {
      [DocumentType.CARE_PLAN]: "ケアプラン",
      [DocumentType.MEDICAL_INSTRUCTION]: "医療指示書",
      [DocumentType.PRESCRIPTION]: "処方箋",
      [DocumentType.REPORT]: "報告書",
      [DocumentType.PHOTO]: "写真",
      [DocumentType.OTHER]: "その他",
    }
    return labels[type]
  }

  const getOCRStatusBadge = (status: OCRStatus) => {
    switch (status) {
      case OCRStatus.NOT_PROCESSED:
        return (
          <Badge variant="secondary" className="text-xs">
            <Clock className="mr-1 h-3 w-3" />
            未処理
          </Badge>
        )
      case OCRStatus.PROCESSING:
        return (
          <Badge variant="outline" className="text-xs">
            <Loader2 className="mr-1 h-3 w-3 animate-spin" />
            処理中
          </Badge>
        )
      case OCRStatus.COMPLETED:
        return (
          <Badge variant="default" className="text-xs bg-green-500">
            <CheckCircle className="mr-1 h-3 w-3" />
            完了
          </Badge>
        )
      case OCRStatus.FAILED:
        return (
          <Badge variant="destructive" className="text-xs">
            <AlertCircle className="mr-1 h-3 w-3" />
            失敗
          </Badge>
        )
      default:
        return null
    }
  }

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const handleSaveText = async () => {
    if (!document) return

    setIsSaving(true)
    try {
      await onUpdateText(document.id, editedText)
      setIsEditing(false)
    } catch (error) {
      console.error("テキストの保存に失敗しました:", error)
    } finally {
      setIsSaving(false)
    }
  }

  const handleCancelEdit = () => {
    setEditedText(document?.ocrText || "")
    setIsEditing(false)
  }

  if (!document) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <DialogTitle className="text-lg font-semibold pr-8">{document.originalFileName}</DialogTitle>
              <div className="flex flex-wrap items-center gap-2 mt-2">
                <Badge variant="outline" className="text-xs">
                  {getDocumentTypeLabel(document.documentType)}
                </Badge>
                {getOCRStatusBadge(document.ocrStatus)}
                <span className="text-xs text-gray-500">{formatFileSize(document.fileSize)}</span>
              </div>
            </div>
          </div>

          {document.description && <p className="text-sm text-gray-600 mt-2">{document.description}</p>}

          {document.tags && document.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {document.tags.map((tag, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  <Tag className="mr-1 h-3 w-3" />
                  {tag}
                </Badge>
              ))}
            </div>
          )}

          <p className="text-xs text-gray-500 mt-2">
            {format(document.uploadedAt, "yyyy年M月d日 HH:mm", { locale: ja })} にアップロード
          </p>
        </DialogHeader>

        <div className="flex-1 overflow-hidden">
          <Tabs defaultValue="preview" className="h-full flex flex-col">
            <TabsList className="flex-shrink-0">
              <TabsTrigger value="preview">書類プレビュー</TabsTrigger>
              {document.ocrStatus === OCRStatus.COMPLETED && <TabsTrigger value="ocr">OCR結果</TabsTrigger>}
            </TabsList>

            <TabsContent value="preview" className="flex-1 overflow-hidden mt-4">
              <div className="h-full border rounded-lg bg-gray-50 flex items-center justify-center">
                {document.mimeType.startsWith("image/") ? (
                  <div className="text-center">
                    <ImageIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">画像プレビュー</p>
                    <p className="text-xs text-gray-400 mt-1">実際の実装では、ここに画像が表示されます</p>
                  </div>
                ) : (
                  <div className="text-center">
                    <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">書類プレビュー</p>
                    <p className="text-xs text-gray-400 mt-1">実際の実装では、PDFビューアーなどが表示されます</p>
                  </div>
                )}
              </div>
            </TabsContent>

            {document.ocrStatus === OCRStatus.COMPLETED && (
              <TabsContent value="ocr" className="flex-1 overflow-hidden mt-4">
                <div className="h-full flex flex-col">
                  <div className="flex items-center justify-between mb-4 flex-shrink-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">抽出されたテキスト</h3>
                      {document.ocrConfidence && (
                        <Badge variant="outline" className="text-xs">
                          信頼度: {Math.round(document.ocrConfidence * 100)}%
                        </Badge>
                      )}
                    </div>
                    <div className="flex gap-2">
                      {!isEditing ? (
                        <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                          <Edit3 className="mr-1 h-4 w-4" />
                          編集
                        </Button>
                      ) : (
                        <>
                          <Button variant="outline" size="sm" onClick={handleCancelEdit} disabled={isSaving}>
                            <RotateCcw className="mr-1 h-4 w-4" />
                            キャンセル
                          </Button>
                          <Button size="sm" onClick={handleSaveText} disabled={isSaving}>
                            {isSaving ? (
                              <Loader2 className="mr-1 h-4 w-4 animate-spin" />
                            ) : (
                              <Save className="mr-1 h-4 w-4" />
                            )}
                            保存
                          </Button>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex-1 overflow-hidden">
                    {isEditing ? (
                      <Textarea
                        value={editedText}
                        onChange={(e) => setEditedText(e.target.value)}
                        className="h-full resize-none font-mono text-sm"
                        placeholder="OCRで抽出されたテキストを編集..."
                      />
                    ) : (
                      <ScrollArea className="h-full">
                        <div className="p-4 bg-gray-50 rounded-lg">
                          <pre className="whitespace-pre-wrap text-sm font-mono">
                            {document.ocrText || "テキストが抽出されていません"}
                          </pre>
                        </div>
                      </ScrollArea>
                    )}
                  </div>

                  {document.ocrProcessedAt && (
                    <p className="text-xs text-gray-500 mt-2 flex-shrink-0">
                      {format(document.ocrProcessedAt, "yyyy年M月d日 HH:mm", { locale: ja })} に処理完了
                    </p>
                  )}
                </div>
              </TabsContent>
            )}

            {document.ocrStatus === OCRStatus.PROCESSING && (
              <TabsContent value="ocr" className="flex-1 overflow-hidden mt-4">
                <div className="h-full flex items-center justify-center">
                  <div className="text-center">
                    <Loader2 className="h-12 w-12 text-primary animate-spin mx-auto mb-4" />
                    <p className="text-gray-600">OCR処理中...</p>
                    <p className="text-xs text-gray-500 mt-1">しばらくお待ちください</p>
                  </div>
                </div>
              </TabsContent>
            )}

            {document.ocrStatus === OCRStatus.FAILED && (
              <TabsContent value="ocr" className="flex-1 overflow-hidden mt-4">
                <div className="h-full flex items-center justify-center">
                  <div className="text-center">
                    <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
                    <p className="text-gray-600">OCR処理に失敗しました</p>
                    <p className="text-xs text-gray-500 mt-1">画像の品質を確認して再度アップロードしてください</p>
                  </div>
                </div>
              </TabsContent>
            )}
          </Tabs>
        </div>

        <div className="flex justify-end gap-2 pt-4 border-t flex-shrink-0">
          <Button variant="outline" onClick={onClose}>
            閉じる
          </Button>
          <Button variant="outline">
            <Download className="mr-1 h-4 w-4" />
            ダウンロード
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
