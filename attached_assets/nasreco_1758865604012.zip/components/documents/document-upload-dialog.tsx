"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Camera, Upload, FileText, X, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { DocumentType } from "@/lib/db/document-schema"

interface DocumentUploadDialogProps {
  isOpen: boolean
  onClose: () => void
  onUpload: (data: {
    file: File
    documentType: DocumentType
    description: string
    tags: string[]
    enableOCR: boolean
  }) => void
  patientId: string
  patientName: string
}

export function DocumentUploadDialog({ isOpen, onClose, onUpload, patientId, patientName }: DocumentUploadDialogProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [documentType, setDocumentType] = useState<DocumentType>(DocumentType.OTHER)
  const [description, setDescription] = useState("")
  const [tags, setTags] = useState("")
  const [enableOCR, setEnableOCR] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const [captureMode, setCaptureMode] = useState<"file" | "camera">("file")
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null)

  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  const documentTypeOptions = [
    { value: DocumentType.CARE_PLAN, label: "ケアプラン" },
    { value: DocumentType.MEDICAL_INSTRUCTION, label: "医療指示書" },
    { value: DocumentType.PRESCRIPTION, label: "処方箋" },
    { value: DocumentType.REPORT, label: "報告書" },
    { value: DocumentType.PHOTO, label: "写真" },
    { value: DocumentType.OTHER, label: "その他" },
  ]

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setSelectedFile(file)
      // 画像ファイルの場合はOCRを有効にする
      if (file.type.startsWith("image/")) {
        setEnableOCR(true)
      }
    }
  }

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" }, // 背面カメラを優先
      })
      setCameraStream(stream)
      if (videoRef.current) {
        videoRef.current.srcObject = stream
      }
      setCaptureMode("camera")
    } catch (error) {
      console.error("カメラの起動に失敗しました:", error)
      alert("カメラの起動に失敗しました。ファイル選択をご利用ください。")
    }
  }

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop())
      setCameraStream(null)
    }
    setCaptureMode("file")
  }

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current
      const canvas = canvasRef.current
      const context = canvas.getContext("2d")

      canvas.width = video.videoWidth
      canvas.height = video.videoHeight

      if (context) {
        context.drawImage(video, 0, 0)
        canvas.toBlob(
          (blob) => {
            if (blob) {
              const file = new File([blob], `capture-${Date.now()}.jpg`, { type: "image/jpeg" })
              setSelectedFile(file)
              setEnableOCR(true) // 撮影した画像は自動でOCR有効
              stopCamera()
            }
          },
          "image/jpeg",
          0.8,
        )
      }
    }
  }

  const handleUpload = async () => {
    if (!selectedFile) return

    setIsUploading(true)
    try {
      const tagsArray = tags
        .split(",")
        .map((tag) => tag.trim())
        .filter((tag) => tag.length > 0)

      await onUpload({
        file: selectedFile,
        documentType,
        description,
        tags: tagsArray,
        enableOCR,
      })

      // リセット
      setSelectedFile(null)
      setDescription("")
      setTags("")
      setEnableOCR(false)
      setDocumentType(DocumentType.OTHER)
      onClose()
    } catch (error) {
      console.error("アップロードに失敗しました:", error)
    } finally {
      setIsUploading(false)
    }
  }

  const handleClose = () => {
    stopCamera()
    setSelectedFile(null)
    setDescription("")
    setTags("")
    setEnableOCR(false)
    setCaptureMode("file")
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>書類をアップロード</DialogTitle>
          <DialogDescription>{patientName}さんの書類をアップロードします</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* アップロード方法選択 */}
          <div className="flex gap-2">
            <Button
              variant={captureMode === "file" ? "default" : "outline"}
              onClick={() => {
                stopCamera()
                setCaptureMode("file")
              }}
              className="flex-1"
            >
              <Upload className="mr-2 h-4 w-4" />
              ファイル選択
            </Button>
            <Button variant={captureMode === "camera" ? "default" : "outline"} onClick={startCamera} className="flex-1">
              <Camera className="mr-2 h-4 w-4" />
              カメラで撮影
            </Button>
          </div>

          {/* ファイル選択モード */}
          {captureMode === "file" && (
            <div>
              <Label htmlFor="file-upload">ファイルを選択</Label>
              <Input
                id="file-upload"
                type="file"
                ref={fileInputRef}
                onChange={handleFileSelect}
                accept="image/*,.pdf,.doc,.docx"
                className="mt-1"
              />
            </div>
          )}

          {/* カメラモード */}
          {captureMode === "camera" && (
            <div className="space-y-2">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full rounded-lg border"
                style={{ maxHeight: "300px" }}
              />
              <canvas ref={canvasRef} className="hidden" />
              <div className="flex gap-2">
                <Button onClick={capturePhoto} className="flex-1">
                  <Camera className="mr-2 h-4 w-4" />
                  撮影
                </Button>
                <Button variant="outline" onClick={stopCamera}>
                  <X className="mr-2 h-4 w-4" />
                  キャンセル
                </Button>
              </div>
            </div>
          )}

          {/* 選択されたファイル表示 */}
          {selectedFile && (
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                <span className="text-sm font-medium">{selectedFile.name}</span>
                <span className="text-xs text-gray-500">({Math.round(selectedFile.size / 1024)} KB)</span>
              </div>
            </div>
          )}

          {/* 書類種別 */}
          <div>
            <Label htmlFor="document-type">書類種別</Label>
            <Select value={documentType} onValueChange={(value) => setDocumentType(value as DocumentType)}>
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="書類の種別を選択" />
              </SelectTrigger>
              <SelectContent>
                {documentTypeOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* 説明 */}
          <div>
            <Label htmlFor="description">説明（任意）</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="書類の内容や目的を入力"
              className="mt-1"
              rows={3}
            />
          </div>

          {/* タグ */}
          <div>
            <Label htmlFor="tags">タグ（任意）</Label>
            <Input
              id="tags"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="タグをカンマ区切りで入力（例: 緊急, 重要）"
              className="mt-1"
            />
          </div>

          {/* OCR設定 */}
          {selectedFile && selectedFile.type.startsWith("image/") && (
            <div className="flex items-center space-x-2">
              <Checkbox
                id="enable-ocr"
                checked={enableOCR}
                onCheckedChange={(checked) => setEnableOCR(checked as boolean)}
              />
              <Label htmlFor="enable-ocr" className="text-sm">
                AI-OCRでテキストを抽出する
              </Label>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>
            キャンセル
          </Button>
          <Button onClick={handleUpload} disabled={!selectedFile || isUploading}>
            {isUploading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                アップロード中...
              </>
            ) : (
              "アップロード"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
