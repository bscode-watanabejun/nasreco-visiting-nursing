"use client"

import { useState } from "react"
import { Plus, Edit, Trash2, Copy, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import type { DocumentTemplate, DocumentType } from "@/lib/db/document-schema"

// モックデータ
const mockTemplates: DocumentTemplate[] = [
  {
    id: "template-1",
    name: "訪問看護計画書",
    description: "標準的な訪問看護計画書のテンプレート",
    documentType: "care_plan",
    content: "<h1>訪問看護計画書</h1><p>患者名: {{patientName}}</p><p>生年月日: {{birthDate}}</p>...",
    placeholders: ["patientName", "birthDate", "address", "diagnosis", "careManager"],
    createdAt: new Date("2025-01-01"),
    updatedAt: new Date("2025-01-15"),
    createdBy: "user-1",
    isActive: true,
    version: 2,
    approvalWorkflow: [
      { id: "step-1", name: "看護師確認", approverRole: ["nurse"], order: 1, isRequired: true },
      { id: "step-2", name: "管理者承認", approverRole: ["manager"], order: 2, isRequired: true },
    ],
    expirationDays: 180,
  },
  {
    id: "template-2",
    name: "経過報告書",
    description: "医師への経過報告書",
    documentType: "progress_report",
    content: "<h1>訪問看護経過報告書</h1><p>報告日: {{reportDate}}</p><p>患者名: {{patientName}}</p>...",
    placeholders: ["reportDate", "patientName", "period", "vitalSigns", "nursingCare", "observation"],
    createdAt: new Date("2025-01-05"),
    updatedAt: new Date("2025-01-05"),
    createdBy: "user-2",
    isActive: true,
    version: 1,
    approvalWorkflow: [{ id: "step-1", name: "看護師確認", approverRole: ["nurse"], order: 1, isRequired: true }],
  },
  {
    id: "template-3",
    name: "サービス利用契約書",
    description: "訪問看護サービス利用契約書",
    documentType: "service_contract",
    content: "<h1>訪問看護サービス利用契約書</h1><p>契約日: {{contractDate}}</p>...",
    placeholders: ["contractDate", "patientName", "patientAddress", "representativeName", "serviceFee"],
    createdAt: new Date("2025-01-10"),
    updatedAt: new Date("2025-01-10"),
    createdBy: "user-1",
    isActive: true,
    version: 1,
    requiredSignatures: [
      { id: "sig-1", role: "patient", description: "利用者署名", isRequired: true, order: 1 },
      { id: "sig-2", role: "family", description: "家族署名", isRequired: false, order: 2 },
      { id: "sig-3", role: "manager", description: "事業所代表者署名", isRequired: true, order: 3 },
    ],
    expirationDays: 365,
  },
  {
    id: "template-4",
    name: "個人情報取扱同意書",
    description: "個人情報の取り扱いに関する同意書",
    documentType: "consent",
    content: "<h1>個人情報取扱同意書</h1><p>同意日: {{consentDate}}</p>...",
    placeholders: ["consentDate", "patientName", "patientAddress"],
    createdAt: new Date("2025-01-15"),
    updatedAt: new Date("2025-01-15"),
    createdBy: "user-2",
    isActive: true,
    version: 1,
    requiredSignatures: [{ id: "sig-1", role: "patient", description: "利用者署名", isRequired: true, order: 1 }],
  },
]

// 書類タイプの表示名マッピング
const documentTypeLabels: Record<DocumentType, string> = {
  care_plan: "訪問看護計画書",
  progress_report: "経過報告書",
  service_contract: "サービス利用契約書",
  medical_instruction: "訪問看護指示書",
  assessment: "アセスメント",
  consent: "同意書",
  other: "その他",
}

interface TemplateManagerProps {
  onSelectTemplate?: (template: DocumentTemplate) => void
  onCreateTemplate?: (template: DocumentTemplate) => void
  onUpdateTemplate?: (template: DocumentTemplate) => void
  onDeleteTemplate?: (templateId: string) => void
}

export function TemplateManager({
  onSelectTemplate,
  onCreateTemplate,
  onUpdateTemplate,
  onDeleteTemplate,
}: TemplateManagerProps) {
  const [templates, setTemplates] = useState<DocumentTemplate[]>(mockTemplates)
  const [selectedTemplate, setSelectedTemplate] = useState<DocumentTemplate | null>(null)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isPreviewDialogOpen, setIsPreviewDialogOpen] = useState(false)
  const [activeTab, setActiveTab] = useState<"all" | "active" | "inactive">("all")
  const [searchQuery, setSearchQuery] = useState("")

  // 新規テンプレート作成用の状態
  const [newTemplate, setNewTemplate] = useState<Partial<DocumentTemplate>>({
    name: "",
    description: "",
    documentType: "care_plan",
    content: "",
    placeholders: [],
    isActive: true,
    version: 1,
  })

  // フィルタリングされたテンプレートリスト
  const filteredTemplates = templates.filter((template) => {
    // 検索クエリでフィルタリング
    const matchesSearch =
      searchQuery === "" ||
      template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.description?.toLowerCase().includes(searchQuery.toLowerCase())

    // タブでフィルタリング
    const matchesTab =
      activeTab === "all" ||
      (activeTab === "active" && template.isActive) ||
      (activeTab === "inactive" && !template.isActive)

    return matchesSearch && matchesTab
  })

  // テンプレートの選択
  const handleSelectTemplate = (template: DocumentTemplate) => {
    setSelectedTemplate(template)
    if (onSelectTemplate) {
      onSelectTemplate(template)
    }
  }

  // テンプレートの作成
  const handleCreateTemplate = () => {
    const createdTemplate: DocumentTemplate = {
      id: `template-${Date.now()}`,
      name: newTemplate.name || "新規テンプレート",
      description: newTemplate.description,
      documentType: newTemplate.documentType as DocumentType,
      content: newTemplate.content || "",
      placeholders: newTemplate.placeholders || [],
      createdAt: new Date(),
      updatedAt: new Date(),
      createdBy: "current-user", // 実際の実装では現在のユーザーIDを使用
      isActive: newTemplate.isActive !== undefined ? newTemplate.isActive : true,
      version: 1,
    }

    setTemplates([...templates, createdTemplate])
    setIsCreateDialogOpen(false)
    setNewTemplate({
      name: "",
      description: "",
      documentType: "care_plan",
      content: "",
      placeholders: [],
      isActive: true,
      version: 1,
    })

    if (onCreateTemplate) {
      onCreateTemplate(createdTemplate)
    }
  }

  // テンプレートの更新
  const handleUpdateTemplate = () => {
    if (!selectedTemplate) return

    const updatedTemplates = templates.map((template) =>
      template.id === selectedTemplate.id
        ? {
            ...selectedTemplate,
            updatedAt: new Date(),
            version: selectedTemplate.version + 1,
          }
        : template,
    )

    setTemplates(updatedTemplates)
    setIsEditDialogOpen(false)

    if (onUpdateTemplate) {
      onUpdateTemplate({
        ...selectedTemplate,
        updatedAt: new Date(),
        version: selectedTemplate.version + 1,
      })
    }
  }

  // テンプレートの削除
  const handleDeleteTemplate = () => {
    if (!selectedTemplate) return

    const updatedTemplates = templates.filter((template) => template.id !== selectedTemplate.id)
    setTemplates(updatedTemplates)
    setIsDeleteDialogOpen(false)
    setSelectedTemplate(null)

    if (onDeleteTemplate) {
      onDeleteTemplate(selectedTemplate.id)
    }
  }

  // テンプレートの複製
  const handleDuplicateTemplate = (template: DocumentTemplate) => {
    const duplicatedTemplate: DocumentTemplate = {
      ...template,
      id: `template-${Date.now()}`,
      name: `${template.name} (コピー)`,
      createdAt: new Date(),
      updatedAt: new Date(),
      version: 1,
    }

    setTemplates([...templates, duplicatedTemplate])

    if (onCreateTemplate) {
      onCreateTemplate(duplicatedTemplate)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">書類テンプレート管理</h2>
          <p className="text-muted-foreground">書類テンプレートの作成・編集・管理を行います</p>
        </div>
        <Button onClick={() => setIsCreateDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          新規テンプレート作成
        </Button>
      </div>

      <div className="flex items-center space-x-4">
        <div className="flex-1">
          <Input
            placeholder="テンプレートを検索..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
          <TabsList>
            <TabsTrigger value="all">すべて</TabsTrigger>
            <TabsTrigger value="active">有効</TabsTrigger>
            <TabsTrigger value="inactive">無効</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredTemplates.map((template) => (
          <Card key={template.id} className={!template.isActive ? "opacity-60" : undefined}>
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="flex items-center">
                    {template.name}
                    {!template.isActive && (
                      <Badge variant="outline" className="ml-2 text-muted-foreground">
                        無効
                      </Badge>
                    )}
                  </CardTitle>
                  <CardDescription>{template.description}</CardDescription>
                </div>
                <Badge>{documentTypeLabels[template.documentType]}</Badge>
              </div>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="text-sm text-muted-foreground">
                <div className="flex justify-between">
                  <span>バージョン: {template.version}</span>
                  <span>作成日: {template.createdAt.toLocaleDateString()}</span>
                </div>
                <div className="mt-1">
                  <span>更新日: {template.updatedAt.toLocaleDateString()}</span>
                </div>
                {template.approvalWorkflow && (
                  <div className="mt-2">
                    <span className="font-medium text-xs">承認フロー: </span>
                    {template.approvalWorkflow.map((step) => step.name).join(" → ")}
                  </div>
                )}
                {template.requiredSignatures && (
                  <div className="mt-2">
                    <span className="font-medium text-xs">必要署名: </span>
                    {template.requiredSignatures.map((sig) => sig.description).join(", ")}
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="flex justify-between pt-2">
              <div className="flex space-x-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setSelectedTemplate(template)
                    setIsPreviewDialogOpen(true)
                  }}
                >
                  <Eye className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setSelectedTemplate(template)
                    setIsEditDialogOpen(true)
                  }}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleDuplicateTemplate(template)}>
                  <Copy className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setSelectedTemplate(template)
                    setIsDeleteDialogOpen(true)
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
              <Button variant="outline" size="sm" onClick={() => handleSelectTemplate(template)}>
                選択
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {filteredTemplates.length === 0 && (
        <div className="text-center py-10">
          <p className="text-muted-foreground">テンプレートが見つかりません</p>
        </div>
      )}

      {/* 新規テンプレート作成ダイアログ */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>新規テンプレート作成</DialogTitle>
            <DialogDescription>新しい書類テンプレートの基本情報を入力してください</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">テンプレート名</Label>
                <Input
                  id="name"
                  value={newTemplate.name || ""}
                  onChange={(e) => setNewTemplate({ ...newTemplate, name: e.target.value })}
                  placeholder="例: 訪問看護計画書"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="documentType">書類タイプ</Label>
                <Select
                  value={newTemplate.documentType}
                  onValueChange={(value) => setNewTemplate({ ...newTemplate, documentType: value as DocumentType })}
                >
                  <SelectTrigger id="documentType">
                    <SelectValue placeholder="書類タイプを選択" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(documentTypeLabels).map(([value, label]) => (
                      <SelectItem key={value} value={value}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">説明</Label>
              <Textarea
                id="description"
                value={newTemplate.description || ""}
                onChange={(e) => setNewTemplate({ ...newTemplate, description: e.target.value })}
                placeholder="このテンプレートの用途や特徴を記入してください"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="content">テンプレート内容</Label>
              <Textarea
                id="content"
                value={newTemplate.content || ""}
                onChange={(e) => setNewTemplate({ ...newTemplate, content: e.target.value })}
                placeholder="HTMLまたはマークダウン形式でテンプレート内容を入力してください。プレースホルダーは {{変数名}} の形式で指定します。"
                rows={10}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="isActive"
                checked={newTemplate.isActive}
                onCheckedChange={(checked) => setNewTemplate({ ...newTemplate, isActive: checked })}
              />
              <Label htmlFor="isActive">有効にする</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
              キャンセル
            </Button>
            <Button onClick={handleCreateTemplate} disabled={!newTemplate.name}>
              作成
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* テンプレート編集ダイアログ */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>テンプレート編集</DialogTitle>
            <DialogDescription>テンプレートの情報を編集します</DialogDescription>
          </DialogHeader>
          {selectedTemplate && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">テンプレート名</Label>
                  <Input
                    id="edit-name"
                    value={selectedTemplate.name}
                    onChange={(e) => setSelectedTemplate({ ...selectedTemplate, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-documentType">書類タイプ</Label>
                  <Select
                    value={selectedTemplate.documentType}
                    onValueChange={(value) =>
                      setSelectedTemplate({ ...selectedTemplate, documentType: value as DocumentType })
                    }
                  >
                    <SelectTrigger id="edit-documentType">
                      <SelectValue placeholder="書類タイプを選択" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(documentTypeLabels).map(([value, label]) => (
                        <SelectItem key={value} value={value}>
                          {label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-description">説明</Label>
                <Textarea
                  id="edit-description"
                  value={selectedTemplate.description || ""}
                  onChange={(e) => setSelectedTemplate({ ...selectedTemplate, description: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-content">テンプレート内容</Label>
                <Textarea
                  id="edit-content"
                  value={selectedTemplate.content}
                  onChange={(e) => setSelectedTemplate({ ...selectedTemplate, content: e.target.value })}
                  rows={10}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="edit-isActive"
                  checked={selectedTemplate.isActive}
                  onCheckedChange={(checked) => setSelectedTemplate({ ...selectedTemplate, isActive: checked })}
                />
                <Label htmlFor="edit-isActive">有効にする</Label>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              キャンセル
            </Button>
            <Button onClick={handleUpdateTemplate}>更新</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* テンプレート削除確認ダイアログ */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>テンプレート削除の確認</DialogTitle>
            <DialogDescription>
              このテンプレートを削除してもよろしいですか？この操作は元に戻せません。
            </DialogDescription>
          </DialogHeader>
          {selectedTemplate && (
            <div className="py-4">
              <p className="font-medium">{selectedTemplate.name}</p>
              <p className="text-sm text-muted-foreground">{selectedTemplate.description}</p>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              キャンセル
            </Button>
            <Button variant="destructive" onClick={handleDeleteTemplate}>
              削除
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* テンプレートプレビューダイアログ */}
      <Dialog open={isPreviewDialogOpen} onOpenChange={setIsPreviewDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>テンプレートプレビュー</DialogTitle>
            <DialogDescription>
              {selectedTemplate?.name} - {documentTypeLabels[selectedTemplate?.documentType || "other"]}
            </DialogDescription>
          </DialogHeader>
          <div className="border rounded-md p-4 max-h-[60vh] overflow-auto">
            {selectedTemplate && <div dangerouslySetInnerHTML={{ __html: selectedTemplate.content }} />}
          </div>
          <DialogFooter>
            <Button onClick={() => setIsPreviewDialogOpen(false)}>閉じる</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
