"use client"

import { useState } from "react"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import {
  Upload,
  FileText,
  ImageIcon,
  Eye,
  Trash2,
  Download,
  Tag,
  Clock,
  CheckCircle,
  AlertCircle,
  Loader2,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

import { DocumentUploadDialog } from "./document-upload-dialog"
import { DocumentPreviewDialog } from "./document-preview-dialog"
import { DocumentType, OCRStatus, type PatientDocument } from "@/lib/db/document-schema"

interface PatientDocumentManagerProps {
  documents: PatientDocument[]
  patientId: string
  patientName: string
  onUpload: (data: {
    file: File
    documentType: DocumentType
    description: string
    tags: string[]
    enableOCR: boolean
  }) => void
  onDelete: (documentId: string) => void
  onUpdateText: (documentId: string, newText: string) => void
}

export function PatientDocumentManager({
  documents,
  patientId,
  patientName,
  onUpload,
  onDelete,
  onUpdateText,
}: PatientDocumentManagerProps) {
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false)
  const [isPreviewDialogOpen, setIsPreviewDialogOpen] = useState(false)
  const [selectedDocument, setSelectedDocument] = useState<PatientDocument | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState<DocumentType | "all">("all")
  const [filterOCRStatus, setFilterOCRStatus] = useState<OCRStatus | "all">("all")

  // フィルタリング
  const filteredDocuments = documents.filter((doc) => {
    const matchesSearch =
      doc.originalFileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.tags?.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesType = filterType === "all" || doc.documentType === filterType
    const matchesOCRStatus = filterOCRStatus === "all" || doc.ocrStatus === filterOCRStatus

    return matchesSearch && matchesType && matchesOCRStatus
  })

  const getDocumentTypeLabel = (type: DocumentType): string => {
    const labels = {
      [DocumentType.CARE_PLAN]: "ケアプラン",
      [DocumentType.MEDICAL_INSTRUCTION]: "医療指示書",
      [DocumentType.PRESCRIPTION]: "処方箋",
      [DocumentType.REPORT]: "報告書",
      [DocumentType.PHOTO]: "写真",
      [DocumentType.OTHER]: "その他",
    }
    return labels[type]
  }

  const getOCRStatusBadge = (status: OCRStatus) => {
    switch (status) {
      case OCRStatus.NOT_PROCESSED:
        return (
          <Badge variant="secondary" className="text-xs">
            <Clock className="mr-1 h-3 w-3" />
            未処理
          </Badge>
        )
      case OCRStatus.PROCESSING:
        return (
          <Badge variant="outline" className="text-xs">
            <Loader2 className="mr-1 h-3 w-3 animate-spin" />
            処理中
          </Badge>
        )
      case OCRStatus.COMPLETED:
        return (
          <Badge variant="default" className="text-xs bg-green-500">
            <CheckCircle className="mr-1 h-3 w-3" />
            完了
          </Badge>
        )
      case OCRStatus.FAILED:
        return (
          <Badge variant="destructive" className="text-xs">
            <AlertCircle className="mr-1 h-3 w-3" />
            失敗
          </Badge>
        )
      default:
        return null
    }
  }

  const getFileIcon = (mimeType: string) => {
    if (mimeType.startsWith("image/")) {
      return <ImageIcon className="h-5 w-5 text-blue-500" />
    }
    return <FileText className="h-5 w-5 text-gray-500" />
  }

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const handlePreview = (document: PatientDocument) => {
    setSelectedDocument(document)
    setIsPreviewDialogOpen(true)
  }

  const handleDelete = async (documentId: string) => {
    if (confirm("この書類を削除してもよろしいですか？")) {
      await onDelete(documentId)
    }
  }

  return (
    <div className="space-y-6">
      {/* ヘッダー */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">書類一覧</h2>
          <p className="text-gray-600">合計 {documents.length} 件の書類</p>
        </div>
        <Button onClick={() => setIsUploadDialogOpen(true)}>
          <Upload className="mr-2 h-4 w-4" />
          書類をアップロード
        </Button>
      </div>

      {/* フィルター */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <Input
            placeholder="ファイル名、説明、タグで検索..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={filterType} onValueChange={(value) => setFilterType(value as DocumentType | "all")}>
          <SelectTrigger className="w-full sm:w-[180px]">
            <SelectValue placeholder="書類種別" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">すべての種別</SelectItem>
            <SelectItem value={DocumentType.CARE_PLAN}>ケアプラン</SelectItem>
            <SelectItem value={DocumentType.MEDICAL_INSTRUCTION}>医療指示書</SelectItem>
            <SelectItem value={DocumentType.PRESCRIPTION}>処方箋</SelectItem>
            <SelectItem value={DocumentType.REPORT}>報告書</SelectItem>
            <SelectItem value={DocumentType.PHOTO}>写真</SelectItem>
            <SelectItem value={DocumentType.OTHER}>その他</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterOCRStatus} onValueChange={(value) => setFilterOCRStatus(value as OCRStatus | "all")}>
          <SelectTrigger className="w-full sm:w-[150px]">
            <SelectValue placeholder="OCR状態" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">すべて</SelectItem>
            <SelectItem value={OCRStatus.NOT_PROCESSED}>未処理</SelectItem>
            <SelectItem value={OCRStatus.PROCESSING}>処理中</SelectItem>
            <SelectItem value={OCRStatus.COMPLETED}>完了</SelectItem>
            <SelectItem value={OCRStatus.FAILED}>失敗</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* 書類一覧 */}
      <div className="grid gap-4">
        {filteredDocuments.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <FileText className="h-12 w-12 text-gray-400 mb-4" />
              <p className="text-gray-500 text-center">
                {searchTerm || filterType !== "all" || filterOCRStatus !== "all"
                  ? "条件に一致する書類が見つかりません"
                  : "まだ書類がアップロードされていません"}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredDocuments.map((document) => (
            <Card key={document.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row gap-4">
                  {/* ファイル情報 */}
                  <div className="flex items-start gap-3 flex-1">
                    {getFileIcon(document.mimeType)}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold truncate">{document.originalFileName}</h3>
                      <div className="flex flex-wrap items-center gap-2 mt-1">
                        <Badge variant="outline" className="text-xs">
                          {getDocumentTypeLabel(document.documentType)}
                        </Badge>
                        {getOCRStatusBadge(document.ocrStatus)}
                        <span className="text-xs text-gray-500">{formatFileSize(document.fileSize)}</span>
                      </div>
                      {document.description && (
                        <p className="text-sm text-gray-600 mt-1 line-clamp-2">{document.description}</p>
                      )}
                      {document.tags && document.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {document.tags.map((tag, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              <Tag className="mr-1 h-3 w-3" />
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      )}
                      <p className="text-xs text-gray-500 mt-2">
                        {format(document.uploadedAt, "yyyy年M月d日 HH:mm", { locale: ja })} にアップロード
                      </p>
                    </div>
                  </div>

                  {/* アクション */}
                  <div className="flex sm:flex-col gap-2 flex-shrink-0">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handlePreview(document)}
                      className="flex-1 sm:flex-none"
                    >
                      <Eye className="mr-1 h-4 w-4" />
                      プレビュー
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1 sm:flex-none bg-transparent">
                      <Download className="mr-1 h-4 w-4" />
                      ダウンロード
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(document.id)}
                      className="flex-1 sm:flex-none text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="mr-1 h-4 w-4" />
                      削除
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* ダイアログ */}
      <DocumentUploadDialog
        isOpen={isUploadDialogOpen}
        onClose={() => setIsUploadDialogOpen(false)}
        onUpload={onUpload}
        patientId={patientId}
        patientName={patientName}
      />

      <DocumentPreviewDialog
        document={selectedDocument}
        isOpen={isPreviewDialogOpen}
        onClose={() => {
          setIsPreviewDialogOpen(false)
          setSelectedDocument(null)
        }}
        onUpdateText={onUpdateText}
      />
    </div>
  )
}
