"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Save, Send, Download, ArrowLeft, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import type { DocumentTemplate, Document, DocumentStatus } from "@/lib/db/document-schema"
import { TemplateManager } from "./template-manager"

// モックデータ - 実際の実装ではAPIから取得
const mockPatients = [
  { id: "patient-1", name: "佐藤 一郎", age: 68 },
  { id: "patient-2", name: "田中 正男", age: 75 },
  { id: "patient-3", name: "鈴木 良子", age: 82 },
  { id: "patient-4", name: "佐藤 花子", age: 45 },
  { id: "patient-5", name: "高橋 健太", age: 58 },
]

interface DocumentCreatorProps {
  initialTemplate?: DocumentTemplate
  initialPatientId?: string
  onSave?: (document: Document) => void
  onSubmit?: (document: Document) => void
}

export function DocumentCreator({ initialTemplate, initialPatientId, onSave, onSubmit }: DocumentCreatorProps) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<"edit" | "preview">("edit")
  const [selectedTemplate, setSelectedTemplate] = useState<DocumentTemplate | null>(initialTemplate || null)
  const [selectedPatientId, setSelectedPatientId] = useState<string>(initialPatientId || "")
  const [documentTitle, setDocumentTitle] = useState<string>("")
  const [documentContent, setDocumentContent] = useState<string>("")
  const [placeholderValues, setPlaceholderValues] = useState<Record<string, string>>({})
  const [showTemplateSelector, setShowTemplateSelector] = useState<boolean>(!initialTemplate)
  const [validationErrors, setValidationErrors] = useState<string[]>([])

  // 選択されたテンプレートが変更されたときの処理
  useEffect(() => {
    if (selectedTemplate) {
      // テンプレート名をデフォルトのタイトルとして設定
      setDocumentTitle(selectedTemplate.name)

      // テンプレートの内容を設定
      setDocumentContent(selectedTemplate.content)

      // プレースホルダーの初期値を設定
      const initialPlaceholders: Record<string, string> = {}
      selectedTemplate.placeholders.forEach((placeholder) => {
        initialPlaceholders[placeholder] = ""
      })
      setPlaceholderValues(initialPlaceholders)
    }
  }, [selectedTemplate])

  // 選択された患者が変更されたときの処理
  useEffect(() => {
    if (selectedPatientId && selectedTemplate) {
      // 実際の実装では、ここで患者情報をAPIから取得し、プレースホルダーに自動入力する
      const selectedPatient = mockPatients.find((patient) => patient.id === selectedPatientId)

      if (selectedPatient) {
        // 患者情報をプレースホルダーに設定
        setPlaceholderValues((prev) => ({
          ...prev,
          patientName: selectedPatient.name,
          patientAge: selectedPatient.age.toString(),
          // 他の患者情報も同様に設定
        }))
      }
    }
  }, [selectedPatientId, selectedTemplate])

  // プレースホルダー値が変更されたときの処理
  useEffect(() => {
    if (selectedTemplate && documentContent) {
      // プレースホルダーを実際の値で置換
      let updatedContent = selectedTemplate.content

      Object.entries(placeholderValues).forEach(([key, value]) => {
        const placeholder = `{{${key}}}`
        updatedContent = updatedContent.replace(new RegExp(placeholder, "g"), value || placeholder)
      })

      setDocumentContent(updatedContent)
    }
  }, [placeholderValues, selectedTemplate])

  // テンプレートの選択
  const handleSelectTemplate = (template: DocumentTemplate) => {
    setSelectedTemplate(template)
    setShowTemplateSelector(false)
  }

  // プレースホルダー値の更新
  const handlePlaceholderChange = (placeholder: string, value: string) => {
    setPlaceholderValues((prev) => ({
      ...prev,
      [placeholder]: value,
    }))
  }

  // 下書き保存
  const handleSaveDraft = () => {
    if (!validateForm()) return

    const document: Document = createDocumentObject("draft")

    if (onSave) {
      onSave(document)
    }

    // 実際の実装ではAPIを呼び出して保存
    alert("下書きとして保存しました")
  }

  // 提出
  const handleSubmit = () => {
    if (!validateForm()) return

    const document: Document = createDocumentObject("pending")

    if (onSubmit) {
      onSubmit(document)
    }

    // 実際の実装ではAPIを呼び出して保存
    alert("書類を提出しました")
    router.push("/documents")
  }

  // ドキュメントオブジェクトの作成
  const createDocumentObject = (status: DocumentStatus): Document => {
    return {
      id: `doc-${Date.now()}`,
      templateId: selectedTemplate?.id || "",
      templateVersion: selectedTemplate?.version || 1,
      documentType: selectedTemplate?.documentType || "other",
      patientId: selectedPatientId,
      title: documentTitle,
      content: documentContent,
      status: status,
      createdAt: new Date(),
      updatedAt: new Date(),
      createdBy: "current-user", // 実際の実装では現在のユーザーIDを使用
      signatures: [],
      approvalHistory: [],
      isDeleted: false,
    }
  }

  // フォームのバリデーション
  const validateForm = (): boolean => {
    const errors: string[] = []

    if (!selectedTemplate) {
      errors.push("テンプレートを選択してください")
    }

    if (!selectedPatientId) {
      errors.push("患者を選択してください")
    }

    if (!documentTitle.trim()) {
      errors.push("書類タイトルを入力してください")
    }

    // 必須プレースホルダーのチェック
    if (selectedTemplate) {
      const missingPlaceholders = selectedTemplate.placeholders.filter(
        (placeholder) => !placeholderValues[placeholder] && documentContent.includes(`{{${placeholder}}}`),
      )

      if (missingPlaceholders.length > 0) {
        errors.push(`以下の項目を入力してください: ${missingPlaceholders.join(", ")}`)
      }
    }

    setValidationErrors(errors)
    return errors.length === 0
  }

  // PDFのダウンロード
  const handleDownloadPDF = () => {
    // 実際の実装ではPDF生成APIを呼び出す
    alert("PDFをダウンロードします")
  }

  return (
    <div className="space-y-6">
      {showTemplateSelector ? (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">テンプレートを選択</h2>
            <Button variant="outline" onClick={() => router.push("/documents")}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              戻る
            </Button>
          </div>
          <TemplateManager onSelectTemplate={handleSelectTemplate} />
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">書類作成</h2>
              <p className="text-muted-foreground">
                {selectedTemplate ? selectedTemplate.name : "新規書類"}を作成しています
              </p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={() => setShowTemplateSelector(true)}>
                テンプレート変更
              </Button>
              <Button variant="outline" onClick={() => router.push("/documents")}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                戻る
              </Button>
            </div>
          </div>

          {validationErrors.length > 0 && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>エラー</AlertTitle>
              <AlertDescription>
                <ul className="list-disc list-inside">
                  {validationErrors.map((error, index) => (
                    <li key={index}>{error}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-1 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>基本情報</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="patient">患者</Label>
                    <Select value={selectedPatientId} onValueChange={setSelectedPatientId}>
                      <SelectTrigger id="patient">
                        <SelectValue placeholder="患者を選択してください" />
                      </SelectTrigger>
                      <SelectContent>
                        {mockPatients.map((patient) => (
                          <SelectItem key={patient.id} value={patient.id}>
                            {patient.name} ({patient.age}歳)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="title">書類タイトル</Label>
                    <Input id="title" value={documentTitle} onChange={(e) => setDocumentTitle(e.target.value)} />
                  </div>
                  {selectedTemplate && (
                    <div className="pt-2">
                      <Badge>
                        {selectedTemplate.documentType === "care_plan"
                          ? "訪問看護計画書"
                          : selectedTemplate.documentType === "progress_report"
                            ? "経過報告書"
                            : selectedTemplate.documentType === "service_contract"
                              ? "サービス利用契約書"
                              : selectedTemplate.documentType === "medical_instruction"
                                ? "訪問看護指示書"
                                : selectedTemplate.documentType === "assessment"
                                  ? "アセスメント"
                                  : selectedTemplate.documentType === "consent"
                                    ? "同意書"
                                    : "その他"}
                      </Badge>
                    </div>
                  )}
                </CardContent>
              </Card>

              {selectedTemplate && selectedTemplate.placeholders.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>入力項目</CardTitle>
                    <CardDescription>必要な情報を入力してください</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {selectedTemplate.placeholders.map((placeholder) => (
                      <div key={placeholder} className="space-y-2">
                        <Label htmlFor={`placeholder-${placeholder}`}>
                          {placeholder}
                          {documentContent.includes(`{{${placeholder}}}`) && (
                            <span className="text-destructive ml-1">*</span>
                          )}
                        </Label>
                        <Input
                          id={`placeholder-${placeholder}`}
                          value={placeholderValues[placeholder] || ""}
                          onChange={(e) => handlePlaceholderChange(placeholder, e.target.value)}
                        />
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}
            </div>

            <div className="md:col-span-2">
              <Card className="h-full flex flex-col">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle>書類内容</CardTitle>
                    <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "edit" | "preview")}>
                      <TabsList>
                        <TabsTrigger value="edit">編集</TabsTrigger>
                        <TabsTrigger value="preview">プレビュー</TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>
                </CardHeader>
                <CardContent className="flex-1">
                  <TabsContent value="edit" className="mt-0 h-full">
                    <Textarea
                      value={documentContent}
                      onChange={(e) => setDocumentContent(e.target.value)}
                      className="min-h-[60vh] font-mono"
                    />
                  </TabsContent>
                  <TabsContent value="preview" className="mt-0 h-full">
                    <div className="border rounded-md p-4 min-h-[60vh] overflow-auto">
                      <div dangerouslySetInnerHTML={{ __html: documentContent }} />
                    </div>
                  </TabsContent>
                </CardContent>
                <CardFooter className="border-t pt-4">
                  <div className="flex justify-between w-full">
                    <Button variant="outline" onClick={handleDownloadPDF}>
                      <Download className="mr-2 h-4 w-4" />
                      PDFダウンロード
                    </Button>
                    <div className="space-x-2">
                      <Button variant="outline" onClick={handleSaveDraft}>
                        <Save className="mr-2 h-4 w-4" />
                        下書き保存
                      </Button>
                      <Button onClick={handleSubmit}>
                        <Send className="mr-2 h-4 w-4" />
                        提出
                      </Button>
                    </div>
                  </div>
                </CardFooter>
              </Card>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
