"use client"

import { Textarea } from "@/components/ui/textarea"

import { Label } from "@/components/ui/label"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Plus, Search, Filter, FileText, Download, Eye, Pencil, Trash2, Check, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Document, DocumentStatus, DocumentType, DocumentFilter } from "@/lib/db/document-schema"

// モックデータ
const mockDocuments: Document[] = [
  {
    id: "doc-1",
    templateId: "template-1",
    templateVersion: 1,
    documentType: "care_plan",
    patientId: "patient-1",
    title: "佐藤一郎様 訪問看護計画書",
    content: "<h1>訪問看護計画書</h1><p>患者名: 佐藤 一郎</p><p>生年月日: 1955年4月10日</p>...",
    status: "approved",
    createdAt: new Date("2025-03-01"),
    updatedAt: new Date("2025-03-05"),
    createdBy: "user-1",
    approvedBy: "user-2",
    approvedAt: new Date("2025-03-05"),
    signatures: [
      {
        id: "sig-1",
        documentId: "doc-1",
        signerName: "佐藤 一郎",
        signerRole: "patient",
        signatureData: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA...",
        signedAt: new Date("2025-03-03"),
        isValid: true,
      },
      {
        id: "sig-2",
        documentId: "doc-1",
        signerName: "山田 花子",
        signerRole: "nurse",
        signatureData: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA...",
        signedAt: new Date("2025-03-04"),
        isValid: true,
      },
    ],
    approvalHistory: [
      {
        id: "approval-1",
        documentId: "doc-1",
        stepId: "step-1",
        stepName: "看護師確認",
        approverId: "user-1",
        approverName: "山田 花子",
        action: "approve",
        timestamp: new Date("2025-03-04"),
      },
      {
        id: "approval-2",
        documentId: "doc-1",
        stepId: "step-2",
        stepName: "管理者承認",
        approverId: "user-2",
        approverName: "鈴木 次郎",
        action: "approve",
        timestamp: new Date("2025-03-05"),
      },
    ],
    expiresAt: new Date("2025-09-01"),
    isDeleted: false,
    pdfUrl: "/documents/doc-1.pdf",
  },
  {
    id: "doc-2",
    templateId: "template-2",
    templateVersion: 1,
    documentType: "progress_report",
    patientId: "patient-1",
    title: "佐藤一郎様 3月経過報告書",
    content: "<h1>訪問看護経過報告書</h1><p>報告日: 2025年3月15日</p><p>患者名: 佐藤 一郎</p>...",
    status: "pending",
    createdAt: new Date("2025-03-15"),
    updatedAt: new Date("2025-03-15"),
    createdBy: "user-1",
    signatures: [],
    approvalHistory: [],
    isDeleted: false,
  },
  {
    id: "doc-3",
    templateId: "template-3",
    templateVersion: 1,
    documentType: "service_contract",
    patientId: "patient-2",
    title: "田中正男様 サービス利用契約書",
    content: "<h1>訪問看護サービス利用契約書</h1><p>契約日: 2025年2月1日</p>...",
    status: "signed",
    createdAt: new Date("2025-02-01"),
    updatedAt: new Date("2025-02-05"),
    createdBy: "user-2",
    signatures: [
      {
        id: "sig-3",
        documentId: "doc-3",
        signerName: "田中 正男",
        signerRole: "patient",
        signatureData: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA...",
        signedAt: new Date("2025-02-05"),
        isValid: true,
      },
      {
        id: "sig-4",
        documentId: "doc-3",
        signerName: "鈴木 次郎",
        signerRole: "manager",
        signatureData: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA...",
        signedAt: new Date("2025-02-05"),
        isValid: true,
      },
    ],
    approvalHistory: [],
    expiresAt: new Date("2026-02-01"),
    isDeleted: false,
    pdfUrl: "/documents/doc-3.pdf",
  },
  {
    id: "doc-4",
    templateId: "template-4",
    templateVersion: 1,
    documentType: "consent",
    patientId: "patient-3",
    title: "鈴木良子様 個人情報取扱同意書",
    content: "<h1>個人情報取扱同意書</h1><p>同意日: 2025年1月10日</p>...",
    status: "draft",
    createdAt: new Date("2025-01-10"),
    updatedAt: new Date("2025-01-10"),
    createdBy: "user-1",
    signatures: [],
    approvalHistory: [],
    isDeleted: false,
  },
  {
    id: "doc-5",
    templateId: "template-1",
    templateVersion: 1,
    documentType: "care_plan",
    patientId: "patient-4",
    title: "佐藤花子様 訪問看護計画書",
    content: "<h1>訪問看護計画書</h1><p>患者名: 佐藤 花子</p><p>生年月日: 1980年8月15日</p>...",
    status: "rejected",
    createdAt: new Date("2025-03-10"),
    updatedAt: new Date("2025-03-12"),
    createdBy: "user-3",
    rejectionReason: "アセスメント内容の追加が必要です",
    signatures: [],
    approvalHistory: [
      {
        id: "approval-3",
        documentId: "doc-5",
        stepId: "step-1",
        stepName: "看護師確認",
        approverId: "user-1",
        approverName: "山田 花子",
        action: "approve",
        timestamp: new Date("2025-03-11"),
      },
      {
        id: "approval-4",
        documentId: "doc-5",
        stepId: "step-2",
        stepName: "管理者承認",
        approverId: "user-2",
        approverName: "鈴木 次郎",
        action: "reject",
        comment: "アセスメント内容の追加が必要です",
        timestamp: new Date("2025-03-12"),
      },
    ],
    isDeleted: false,
  },
]

// モックデータ - 患者情報
const mockPatients = [
  { id: "patient-1", name: "佐藤 一郎", age: 68 },
  { id: "patient-2", name: "田中 正男", age: 75 },
  { id: "patient-3", name: "鈴木 良子", age: 82 },
  { id: "patient-4", name: "佐藤 花子", age: 45 },
  { id: "patient-5", name: "高橋 健太", age: 58 },
]

// 書類タイプの表示名マッピング
const documentTypeLabels: Record<DocumentType, string> = {
  care_plan: "訪問看護計画書",
  progress_report: "経過報告書",
  service_contract: "サービス利用契約書",
  medical_instruction: "訪問看護指示書",
  assessment: "アセスメント",
  consent: "同意書",
  other: "その他",
}

// 書類ステータスの表示名マッピング
const documentStatusLabels: Record<DocumentStatus, string> = {
  draft: "下書き",
  pending: "承認待ち",
  approved: "承認済み",
  rejected: "却下",
  signed: "署名済み",
  expired: "期限切れ",
  archived: "アーカイブ",
}

// ステータスに応じたバッジの色
const statusBadgeVariant = (status: DocumentStatus): "default" | "secondary" | "destructive" | "outline" => {
  switch (status) {
    case "approved":
      return "default"
    case "signed":
      return "default"
    case "pending":
      return "secondary"
    case "rejected":
      return "destructive"
    case "expired":
      return "destructive"
    default:
      return "outline"
  }
}

interface DocumentListProps {
  onCreateDocument?: () => void
  onViewDocument?: (document: Document) => void
  onEditDocument?: (document: Document) => void
  onDeleteDocument?: (documentId: string) => void
  onApproveDocument?: (document: Document) => void
  onRejectDocument?: (document: Document, reason: string) => void
}

export function DocumentList({
  onCreateDocument,
  onViewDocument,
  onEditDocument,
  onDeleteDocument,
  onApproveDocument,
  onRejectDocument,
}: DocumentListProps) {
  const router = useRouter()
  const [documents, setDocuments] = useState<Document[]>(mockDocuments)
  const [filteredDocuments, setFilteredDocuments] = useState<Document[]>(mockDocuments)
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState<"all" | "pending" | "approved" | "signed" | "draft">("all")
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isApproveDialogOpen, setIsApproveDialogOpen] = useState(false)
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false)
  const [rejectionReason, setRejectionReason] = useState("")
  const [filter, setFilter] = useState<DocumentFilter>({})
  const [isFilterDialogOpen, setIsFilterDialogOpen] = useState(false)

  // フィルタリングされた書類リスト
  useEffect(() => {
    let filtered = [...documents]

    // 検索クエリでフィルタリング
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (doc) =>
          doc.title.toLowerCase().includes(query) ||
          getPatientName(doc.patientId).toLowerCase().includes(query) ||
          documentTypeLabels[doc.documentType].toLowerCase().includes(query),
      )
    }

    // タブでフィルタリング
    if (activeTab !== "all") {
      if (activeTab === "pending") {
        filtered = filtered.filter((doc) => doc.status === "pending")
      } else if (activeTab === "approved") {
        filtered = filtered.filter((doc) => doc.status === "approved")
      } else if (activeTab === "signed") {
        filtered = filtered.filter((doc) => doc.status === "signed")
      } else if (activeTab === "draft") {
        filtered = filtered.filter((doc) => doc.status === "draft")
      }
    }

    // 詳細フィルタでフィルタリング
    if (filter.documentType && filter.documentType.length > 0) {
      filtered = filtered.filter((doc) => filter.documentType?.includes(doc.documentType))
    }

    if (filter.status && filter.status.length > 0) {
      filtered = filtered.filter((doc) => filter.status?.includes(doc.status))
    }

    if (filter.patientId) {
      filtered = filtered.filter((doc) => doc.patientId === filter.patientId)
    }

    if (filter.dateFrom) {
      filtered = filtered.filter((doc) => doc.createdAt >= filter.dateFrom!)
    }

    if (filter.dateTo) {
      const dateTo = new Date(filter.dateTo!)
      dateTo.setHours(23, 59, 59, 999)
      filtered = filtered.filter((doc) => doc.createdAt <= dateTo)
    }

    setFilteredDocuments(filtered)
  }, [documents, searchQuery, activeTab, filter])

  // 患者名を取得
  const getPatientName = (patientId: string): string => {
    const patient = mockPatients.find((p) => p.id === patientId)
    return patient ? patient.name : "不明"
  }

  // 書類の表示
  const handleViewDocument = (document: Document) => {
    setSelectedDocument(document)
    setIsViewDialogOpen(true)

    if (onViewDocument) {
      onViewDocument(document)
    }
  }

  // 書類の編集
  const handleEditDocument = (document: Document) => {
    if (onEditDocument) {
      onEditDocument(document)
    } else {
      router.push(`/documents/edit/${document.id}`)
    }
  }

  // 書類の削除
  const handleDeleteDocument = () => {
    if (!selectedDocument) return

    // 実際の実装ではAPIを呼び出して削除
    const updatedDocuments = documents.filter((doc) => doc.id !== selectedDocument.id)
    setDocuments(updatedDocuments)
    setIsDeleteDialogOpen(false)

    if (onDeleteDocument) {
      onDeleteDocument(selectedDocument.id)
    }
  }

  // 書類の承認
  const handleApproveDocument = () => {
    if (!selectedDocument) return

    // 実際の実装ではAPIを呼び出して承認
    const updatedDocuments = documents.map((doc) => {
      if (doc.id === selectedDocument.id) {
        return {
          ...doc,
          status: "approved" as DocumentStatus,
          approvedBy: "current-user", // 実際の実装では現在のユーザーIDを使用
          approvedAt: new Date(),
          updatedAt: new Date(),
          approvalHistory: [
            ...doc.approvalHistory,
            {
              id: `approval-${Date.now()}`,
              documentId: doc.id,
              stepId: "step-1", // 実際の実装では現在のステップIDを使用
              stepName: "承認", // 実際の実装では現在のステップ名を使用
              approverId: "current-user", // 実際の実装では現在のユーザーIDを使用
              approverName: "現在のユーザー", // 実際の実装では現在のユーザー名を使用
              action: "approve",
              timestamp: new Date(),
            },
          ],
        }
      }
      return doc
    })

    setDocuments(updatedDocuments)
    setIsApproveDialogOpen(false)

    if (onApproveDocument) {
      onApproveDocument(selectedDocument)
    }
  }

  // 書類の却下
  const handleRejectDocument = () => {
    if (!selectedDocument || !rejectionReason.trim()) return

    // 実際の実装ではAPIを呼び出して却下
    const updatedDocuments = documents.map((doc) => {
      if (doc.id === selectedDocument.id) {
        return {
          ...doc,
          status: "rejected" as DocumentStatus,
          rejectionReason: rejectionReason,
          updatedAt: new Date(),
          approvalHistory: [
            ...doc.approvalHistory,
            {
              id: `approval-${Date.now()}`,
              documentId: doc.id,
              stepId: "step-1", // 実際の実装では現在のステップIDを使用
              stepName: "却下", // 実際の実装では現在のステップ名を使用
              approverId: "current-user", // 実際の実装では現在のユーザーIDを使用
              approverName: "現在のユーザー", // 実際の実装では現在のユーザー名を使用
              action: "reject",
              comment: rejectionReason,
              timestamp: new Date(),
            },
          ],
        }
      }
      return doc
    })

    setDocuments(updatedDocuments)
    setIsRejectDialogOpen(false)
    setRejectionReason("")

    if (onRejectDocument) {
      onRejectDocument(selectedDocument, rejectionReason)
    }
  }

  // フィルターのリセット
  const resetFilter = () => {
    setFilter({})
    setIsFilterDialogOpen(false)
  }

  // フィルターの適用
  const applyFilter = () => {
    setIsFilterDialogOpen(false)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">書類管理</h2>
          <p className="text-muted-foreground">書類の作成・管理・承認を行います</p>
        </div>
        <Button onClick={onCreateDocument || (() => router.push("/documents/create"))}>
          <Plus className="mr-2 h-4 w-4" />
          新規書類作成
        </Button>
      </div>

      <div className="flex items-center space-x-4">
        <div className="relative flex-1">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="書類を検索..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button variant="outline" size="icon" onClick={() => setIsFilterDialogOpen(true)}>
          <Filter className="h-4 w-4" />
        </Button>
        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
          <TabsList>
            <TabsTrigger value="all">すべて</TabsTrigger>
            <TabsTrigger value="pending">承認待ち</TabsTrigger>
            <TabsTrigger value="approved">承認済み</TabsTrigger>
            <TabsTrigger value="signed">署名済み</TabsTrigger>
            <TabsTrigger value="draft">下書き</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {Object.keys(filter).length > 0 && (
        <div className="flex items-center gap-2 text-sm">
          <span className="text-muted-foreground">フィルター:</span>
          {filter.documentType && filter.documentType.length > 0 && (
            <Badge variant="outline" className="flex items-center gap-1">
              書類タイプ: {filter.documentType.map((type) => documentTypeLabels[type]).join(", ")}
              <Button
                variant="ghost"
                size="icon"
                className="h-4 w-4 p-0"
                onClick={() => setFilter({ ...filter, documentType: undefined })}
              >
                <X className="h-3 w-3" />
              </Button>
            </Badge>
          )}
          {filter.status && filter.status.length > 0 && (
            <Badge variant="outline" className="flex items-center gap-1">
              ステータス: {filter.status.map((status) => documentStatusLabels[status]).join(", ")}
              <Button
                variant="ghost"
                size="icon"
                className="h-4 w-4 p-0"
                onClick={() => setFilter({ ...filter, status: undefined })}
              >
                <X className="h-3 w-3" />
              </Button>
            </Badge>
          )}
          {filter.patientId && (
            <Badge variant="outline" className="flex items-center gap-1">
              患者: {getPatientName(filter.patientId)}
              <Button
                variant="ghost"
                size="icon"
                className="h-4 w-4 p-0"
                onClick={() => setFilter({ ...filter, patientId: undefined })}
              >
                <X className="h-3 w-3" />
              </Button>
            </Badge>
          )}
          {(filter.dateFrom || filter.dateTo) && (
            <Badge variant="outline" className="flex items-center gap-1">
              期間: {filter.dateFrom?.toLocaleDateString() || ""}～{filter.dateTo?.toLocaleDateString() || ""}
              <Button
                variant="ghost"
                size="icon"
                className="h-4 w-4 p-0"
                onClick={() => setFilter({ ...filter, dateFrom: undefined, dateTo: undefined })}
              >
                <X className="h-3 w-3" />
              </Button>
            </Badge>
          )}
          <Button variant="ghost" size="sm" className="h-6 px-2 text-xs" onClick={resetFilter}>
            すべてクリア
          </Button>
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredDocuments.map((document) => (
          <Card key={document.id}>
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="flex items-center">
                    <FileText className="mr-2 h-4 w-4" />
                    {document.title}
                  </CardTitle>
                  <CardDescription>{getPatientName(document.patientId)}</CardDescription>
                </div>
                <Badge variant={statusBadgeVariant(document.status)}>{documentStatusLabels[document.status]}</Badge>
              </div>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="text-sm text-muted-foreground">
                <div className="flex justify-between">
                  <span>{documentTypeLabels[document.documentType]}</span>
                  <span>作成日: {document.createdAt.toLocaleDateString()}</span>
                </div>
                {document.approvedAt && (
                  <div className="mt-1">
                    <span>承認日: {document.approvedAt.toLocaleDateString()}</span>
                  </div>
                )}
                {document.expiresAt && (
                  <div className="mt-1">
                    <span>有効期限: {document.expiresAt.toLocaleDateString()}</span>
                  </div>
                )}
                {document.signatures.length > 0 && (
                  <div className="mt-2">
                    <span className="font-medium text-xs">署名: </span>
                    {document.signatures.map((sig) => sig.signerName).join(", ")}
                  </div>
                )}
                {document.rejectionReason && (
                  <div className="mt-2 text-destructive">
                    <span className="font-medium text-xs">却下理由: </span>
                    {document.rejectionReason}
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="flex justify-between pt-2">
              <Button variant="ghost" size="sm" onClick={() => handleViewDocument(document)}>
                <Eye className="mr-2 h-4 w-4" />
                表示
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    アクション
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>書類操作</DropdownMenuLabel>
                  <DropdownMenuItem onClick={() => handleViewDocument(document)}>
                    <Eye className="mr-2 h-4 w-4" />
                    表示
                  </DropdownMenuItem>
                  {document.status === "draft" && (
                    <DropdownMenuItem onClick={() => handleEditDocument(document)}>
                      <Pencil className="mr-2 h-4 w-4" />
                      編集
                    </DropdownMenuItem>
                  )}
                  {document.pdfUrl && (
                    <DropdownMenuItem onClick={() => window.open(document.pdfUrl, "_blank")}>
                      <Download className="mr-2 h-4 w-4" />
                      PDFダウンロード
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  {document.status === "pending" && (
                    <>
                      <DropdownMenuItem
                        onClick={() => {
                          setSelectedDocument(document)
                          setIsApproveDialogOpen(true)
                        }}
                      >
                        <Check className="mr-2 h-4 w-4" />
                        承認
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => {
                          setSelectedDocument(document)
                          setIsRejectDialogOpen(true)
                        }}
                      >
                        <X className="mr-2 h-4 w-4" />
                        却下
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                    </>
                  )}
                  <DropdownMenuItem
                    className="text-destructive"
                    onClick={() => {
                      setSelectedDocument(document)
                      setIsDeleteDialogOpen(true)
                    }}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    削除
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </CardFooter>
          </Card>
        ))}
      </div>

      {filteredDocuments.length === 0 && (
        <div className="text-center py-10">
          <p className="text-muted-foreground">書類が見つかりません</p>
        </div>
      )}

      {/* 書類表示ダイアログ */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>{selectedDocument?.title}</DialogTitle>
            <DialogDescription>
              {selectedDocument && (
                <div className="flex items-center justify-between">
                  <span>
                    {getPatientName(selectedDocument.patientId)} - {documentTypeLabels[selectedDocument.documentType]}
                  </span>
                  <Badge variant={statusBadgeVariant(selectedDocument.status)}>
                    {documentStatusLabels[selectedDocument.status]}
                  </Badge>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
          <div className="border rounded-md p-4 max-h-[60vh] overflow-auto">
            {selectedDocument && <div dangerouslySetInnerHTML={{ __html: selectedDocument.content }} />}
          </div>
          <DialogFooter>
            <div className="flex justify-between w-full">
              <div>
                {selectedDocument?.pdfUrl && (
                  <Button variant="outline" onClick={() => window.open(selectedDocument.pdfUrl, "_blank")}>
                    <Download className="mr-2 h-4 w-4" />
                    PDFダウンロード
                  </Button>
                )}
              </div>
              <div className="space-x-2">
                {selectedDocument?.status === "pending" && (
                  <>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setIsViewDialogOpen(false)
                        setIsRejectDialogOpen(true)
                      }}
                    >
                      <X className="mr-2 h-4 w-4" />
                      却下
                    </Button>
                    <Button
                      onClick={() => {
                        setIsViewDialogOpen(false)
                        setIsApproveDialogOpen(true)
                      }}
                    >
                      <Check className="mr-2 h-4 w-4" />
                      承認
                    </Button>
                  </>
                )}
                {selectedDocument?.status === "draft" && (
                  <Button onClick={() => handleEditDocument(selectedDocument)}>
                    <Pencil className="mr-2 h-4 w-4" />
                    編集
                  </Button>
                )}
                <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
                  閉じる
                </Button>
              </div>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 書類削除確認ダイアログ */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>書類削除の確認</DialogTitle>
            <DialogDescription>この書類を削除してもよろしいですか？この操作は元に戻せません。</DialogDescription>
          </DialogHeader>
          {selectedDocument && (
            <div className="py-4">
              <p className="font-medium">{selectedDocument.title}</p>
              <p className="text-sm text-muted-foreground">
                {getPatientName(selectedDocument.patientId)} - {documentTypeLabels[selectedDocument.documentType]}
              </p>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              キャンセル
            </Button>
            <Button variant="destructive" onClick={handleDeleteDocument}>
              削除
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 書類承認確認ダイアログ */}
      <Dialog open={isApproveDialogOpen} onOpenChange={setIsApproveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>書類承認の確認</DialogTitle>
            <DialogDescription>この書類を承認してもよろしいですか？</DialogDescription>
          </DialogHeader>
          {selectedDocument && (
            <div className="py-4">
              <p className="font-medium">{selectedDocument.title}</p>
              <p className="text-sm text-muted-foreground">
                {getPatientName(selectedDocument.patientId)} - {documentTypeLabels[selectedDocument.documentType]}
              </p>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsApproveDialogOpen(false)}>
              キャンセル
            </Button>
            <Button onClick={handleApproveDocument}>
              <Check className="mr-2 h-4 w-4" />
              承認
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 書類却下ダイアログ */}
      <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>書類却下</DialogTitle>
            <DialogDescription>却下理由を入力してください。</DialogDescription>
          </DialogHeader>
          {selectedDocument && (
            <div className="py-4 space-y-4">
              <div>
                <p className="font-medium">{selectedDocument.title}</p>
                <p className="text-sm text-muted-foreground">
                  {getPatientName(selectedDocument.patientId)} - {documentTypeLabels[selectedDocument.documentType]}
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="rejection-reason">却下理由</Label>
                <Textarea
                  id="rejection-reason"
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder="却下理由を入力してください"
                  rows={4}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRejectDialogOpen(false)}>
              キャンセル
            </Button>
            <Button variant="destructive" onClick={handleRejectDocument} disabled={!rejectionReason.trim()}>
              <X className="mr-2 h-4 w-4" />
              却下
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* フィルターダイアログ */}
      <Dialog open={isFilterDialogOpen} onOpenChange={setIsFilterDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>詳細フィルター</DialogTitle>
            <DialogDescription>表示する書類を絞り込みます</DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="space-y-2">
              <Label>書類タイプ</Label>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(documentTypeLabels).map(([value, label]) => (
                  <div key={value} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={`type-${value}`}
                      checked={filter.documentType?.includes(value as DocumentType) || false}
                      onChange={(e) => {
                        const documentTypes = filter.documentType || []
                        if (e.target.checked) {
                          setFilter({
                            ...filter,
                            documentType: [...documentTypes, value as DocumentType],
                          })
                        } else {
                          setFilter({
                            ...filter,
                            documentType: documentTypes.filter((type) => type !== value),
                          })
                        }
                      }}
                    />
                    <Label htmlFor={`type-${value}`}>{label}</Label>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <Label>ステータス</Label>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(documentStatusLabels).map(([value, label]) => (
                  <div key={value} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={`status-${value}`}
                      checked={filter.status?.includes(value as DocumentStatus) || false}
                      onChange={(e) => {
                        const statuses = filter.status || []
                        if (e.target.checked) {
                          setFilter({
                            ...filter,
                            status: [...statuses, value as DocumentStatus],
                          })
                        } else {
                          setFilter({
                            ...filter,
                            status: statuses.filter((status) => status !== value),
                          })
                        }
                      }}
                    />
                    <Label htmlFor={`status-${value}`}>{label}</Label>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="patient-filter">患者</Label>
              <Select
                value={filter.patientId || ""}
                onValueChange={(value) => setFilter({ ...filter, patientId: value || undefined })}
              >
                <SelectTrigger id="patient-filter">
                  <SelectValue placeholder="すべての患者" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">すべての患者</SelectItem>
                  {mockPatients.map((patient) => (
                    <SelectItem key={patient.id} value={patient.id}>
                      {patient.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date-from">期間（開始）</Label>
                <Input
                  id="date-from"
                  type="date"
                  value={filter.dateFrom ? filter.dateFrom.toISOString().split("T")[0] : ""}
                  onChange={(e) =>
                    setFilter({
                      ...filter,
                      dateFrom: e.target.value ? new Date(e.target.value) : undefined,
                    })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="date-to">期間（終了）</Label>
                <Input
                  id="date-to"
                  type="date"
                  value={filter.dateTo ? filter.dateTo.toISOString().split("T")[0] : ""}
                  onChange={(e) =>
                    setFilter({
                      ...filter,
                      dateTo: e.target.value ? new Date(e.target.value) : undefined,
                    })
                  }
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={resetFilter}>
              リセット
            </Button>
            <Button onClick={applyFilter}>適用</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
