"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Trash2, Download, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Signature, SignatureRequirement } from "@/lib/db/document-schema"

interface SignaturePadProps {
  requirements?: SignatureRequirement[]
  existingSignatures?: Signature[]
  documentId: string
  onSave: (signature: Omit<Signature, "id" | "documentId" | "signedAt" | "isValid">) => void
  onClear?: () => void
  readOnly?: boolean
}

export function SignaturePad({
  requirements = [],
  existingSignatures = [],
  documentId,
  onSave,
  onClear,
  readOnly = false,
}: SignaturePadProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isDrawing, setIsDrawing] = useState(false)
  const [signerName, setSignerName] = useState("")
  const [signerRole, setSignerRole] = useState<string>(requirements.length > 0 ? requirements[0].role : "patient")
  const [isEmpty, setIsEmpty] = useState(true)
  const [ctx, setCtx] = useState<CanvasRenderingContext2D | null>(null)

  // キャンバスの初期化
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const context = canvas.getContext("2d")
    if (!context) return

    // キャンバスのサイズを設定
    const dpr = window.devicePixelRatio || 1
    const rect = canvas.getBoundingClientRect()

    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr

    context.scale(dpr, dpr)
    context.lineCap = "round"
    context.lineJoin = "round"
    context.lineWidth = 2
    context.strokeStyle = "#000000"

    setCtx(context)

    // キャンバスをクリア
    context.fillStyle = "#ffffff"
    context.fillRect(0, 0, canvas.width, canvas.height)

    // 罫線を描画
    context.beginPath()
    context.moveTo(0, canvas.height / dpr - 10)
    context.lineTo(canvas.width / dpr, canvas.height / dpr - 10)
    context.strokeStyle = "#cccccc"
    context.stroke()
    context.strokeStyle = "#000000"
  }, [])

  // マウスイベントハンドラ
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (readOnly) return

    const canvas = canvasRef.current
    if (!canvas || !ctx) return

    setIsDrawing(true)
    setIsEmpty(false)

    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    ctx.beginPath()
    ctx.moveTo(x, y)
  }

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || readOnly) return

    const canvas = canvasRef.current
    if (!canvas || !ctx) return

    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    ctx.lineTo(x, y)
    ctx.stroke()
  }

  const stopDrawing = () => {
    if (readOnly) return
    setIsDrawing(false)
  }

  // タッチイベントハンドラ
  const handleTouchStart = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (readOnly) return

    const canvas = canvasRef.current
    if (!canvas || !ctx) return

    setIsDrawing(true)
    setIsEmpty(false)

    const rect = canvas.getBoundingClientRect()
    const touch = e.touches[0]
    const x = touch.clientX - rect.left
    const y = touch.clientY - rect.top

    ctx.beginPath()
    ctx.moveTo(x, y)

    e.preventDefault()
  }

  const handleTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing || readOnly) return

    const canvas = canvasRef.current
    if (!canvas || !ctx) return

    const rect = canvas.getBoundingClientRect()
    const touch = e.touches[0]
    const x = touch.clientX - rect.left
    const y = touch.clientY - rect.top

    ctx.lineTo(x, y)
    ctx.stroke()

    e.preventDefault()
  }

  const handleTouchEnd = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (readOnly) return
    setIsDrawing(false)
    e.preventDefault()
  }

  // 署名をクリア
  const clearSignature = () => {
    const canvas = canvasRef.current
    if (!canvas || !ctx) return

    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // 背景を白で塗りつぶす
    ctx.fillStyle = "#ffffff"
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // 罫線を再描画
    ctx.beginPath()
    ctx.moveTo(0, canvas.height / window.devicePixelRatio - 10)
    ctx.lineTo(canvas.width / window.devicePixelRatio, canvas.height / window.devicePixelRatio - 10)
    ctx.strokeStyle = "#cccccc"
    ctx.stroke()
    ctx.strokeStyle = "#000000"

    setIsEmpty(true)

    if (onClear) {
      onClear()
    }
  }

  // 署名を保存
  const saveSignature = () => {
    if (isEmpty) {
      alert("署名を入力してください")
      return
    }

    if (!signerName.trim()) {
      alert("署名者名を入力してください")
      return
    }

    const canvas = canvasRef.current
    if (!canvas) return

    // 署名データをBase64形式で取得
    const signatureData = canvas.toDataURL("image/png")

    // デバイス情報を取得
    const deviceInfo = {
      userAgent: navigator.userAgent,
      platform: navigator.platform,
      screenWidth: window.screen.width,
      screenHeight: window.screen.height,
    }

    // 署名オブジェクトを作成
    const signature = {
      signerName,
      signerRole,
      signatureData,
      deviceInfo: JSON.stringify(deviceInfo),
    }

    onSave(signature)
  }

  // 署名をダウンロード
  const downloadSignature = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const link = document.createElement("a")
    link.download = `signature-${signerName}-${new Date().toISOString()}.png`
    link.href = canvas.toDataURL("image/png")
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  // 既存の署名を表示
  const renderExistingSignatures = () => {
    if (existingSignatures.length === 0) return null

    return (
      <div className="space-y-4 mt-4">
        <h3 className="text-sm font-medium">署名済み</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {existingSignatures.map((signature) => (
            <Card key={signature.id} className="overflow-hidden">
              <CardHeader className="py-2">
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="text-sm">{signature.signerName}</CardTitle>
                    <CardDescription className="text-xs">
                      {signature.signerRole === "patient"
                        ? "利用者"
                        : signature.signerRole === "family"
                          ? "家族"
                          : signature.signerRole === "guardian"
                            ? "後見人"
                            : signature.signerRole === "doctor"
                              ? "医師"
                              : signature.signerRole === "nurse"
                                ? "看護師"
                                : signature.signerRole === "manager"
                                  ? "管理者"
                                  : signature.signerRole}
                    </CardDescription>
                  </div>
                  <div className="text-xs text-muted-foreground">{new Date(signature.signedAt).toLocaleString()}</div>
                </div>
              </CardHeader>
              <CardContent className="p-2 bg-gray-50">
                <div className="h-20 flex items-center justify-center">
                  <img
                    src={signature.signatureData || "/placeholder.svg"}
                    alt={`${signature.signerName}の署名`}
                    className="max-h-full max-w-full object-contain"
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  // 必要な署名の表示
  const renderRequirements = () => {
    if (requirements.length === 0) return null

    // 既に署名されているものを除外
    const remainingRequirements = requirements.filter(
      (req) => !existingSignatures.some((sig) => sig.signerRole === req.role),
    )

    if (remainingRequirements.length === 0) return null

    return (
      <div className="space-y-2 mt-4">
        <h3 className="text-sm font-medium">必要な署名</h3>
        <div className="flex flex-wrap gap-2">
          {remainingRequirements.map((req) => (
            <div
              key={req.id}
              className={`text-xs px-2 py-1 rounded-full ${
                req.isRequired ? "bg-destructive/10 text-destructive" : "bg-muted text-muted-foreground"
              }`}
            >
              {req.description}
              {req.isRequired && " *"}
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {!readOnly && (
        <Card>
          <CardHeader>
            <CardTitle>電子署名</CardTitle>
            <CardDescription>
              下記の署名欄に署名してください。タッチスクリーンの場合は指で、マウスの場合はクリックしながら描画できます。
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="signerName">署名者名</Label>
                <Input
                  id="signerName"
                  value={signerName}
                  onChange={(e) => setSignerName(e.target.value)}
                  placeholder="例: 山田 太郎"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="signerRole">署名者区分</Label>
                <Select value={signerRole} onValueChange={setSignerRole}>
                  <SelectTrigger id="signerRole">
                    <SelectValue placeholder="署名者区分を選択" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="patient">利用者</SelectItem>
                    <SelectItem value="family">家族</SelectItem>
                    <SelectItem value="guardian">後見人</SelectItem>
                    <SelectItem value="doctor">医師</SelectItem>
                    <SelectItem value="nurse">看護師</SelectItem>
                    <SelectItem value="manager">管理者</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="border rounded-md p-2 bg-white">
              <canvas
                ref={canvasRef}
                className="w-full h-40 touch-none cursor-crosshair"
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                onTouchStart={handleTouchStart}
                onTouchMove={handleTouchMove}
                onTouchEnd={handleTouchEnd}
              />
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={clearSignature}>
              <Trash2 className="mr-2 h-4 w-4" />
              クリア
            </Button>
            <div className="space-x-2">
              <Button variant="outline" onClick={downloadSignature} disabled={isEmpty}>
                <Download className="mr-2 h-4 w-4" />
                ダウンロード
              </Button>
              <Button onClick={saveSignature} disabled={isEmpty || !signerName.trim()}>
                <Check className="mr-2 h-4 w-4" />
                署名を保存
              </Button>
            </div>
          </CardFooter>
        </Card>
      )}

      {renderExistingSignatures()}
      {renderRequirements()}
    </div>
  )
}
