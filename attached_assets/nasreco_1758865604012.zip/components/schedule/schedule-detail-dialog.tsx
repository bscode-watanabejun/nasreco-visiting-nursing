"use client"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import {
  Calendar,
  Clock,
  Edit,
  FileText,
  MapPin,
  Phone,
  User,
  Users,
  CheckCircle,
  XCircle,
  AlertCircle,
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Label } from "@/components/ui/label"

import type { VisitSchedule } from "../../lib/db/schedule-schema"
import { VisitStatus } from "../../lib/db/schedule-schema"
import {
  getVisitStatusName,
  getVisitStatusColor,
  getVisitTypeName,
  getVisitTypeColor,
  formatVisitTime,
} from "../../lib/utils/schedule-utils"

interface ScheduleDetailDialogProps {
  schedule: VisitSchedule | null
  isOpen: boolean
  onClose: () => void
  onEdit: (schedule: VisitSchedule) => void
  onCreateRecord: (schedule: VisitSchedule) => void
  patientName: string
  staffName: string
}

// モック患者詳細データ
const getPatientDetails = (patientId: string) => {
  const patients: Record<string, any> = {
    "patient-1": {
      name: "佐藤 一郎",
      age: 68,
      address: "東京都新宿区西新宿1-1-1",
      phone: "03-1234-5678",
      diagnosis: "糖尿病、高血圧",
      careLevel: "要介護2",
      emergencyContact: "佐藤 花子（娘）",
      emergencyPhone: "090-1234-5678",
    },
    "patient-2": {
      name: "田中 正男",
      age: 75,
      address: "東京都渋谷区渋谷2-2-2",
      phone: "03-2345-6789",
      diagnosis: "脳梗塞後遺症",
      careLevel: "要介護3",
      emergencyContact: "田中 美子（妻）",
      emergencyPhone: "090-2345-6789",
    },
    "patient-3": {
      name: "鈴木 良子",
      age: 82,
      address: "東京都港区赤坂3-3-3",
      phone: "03-3456-7890",
      diagnosis: "認知症、骨粗鬆症",
      careLevel: "要介護4",
      emergencyContact: "鈴木 太郎（息子）",
      emergencyPhone: "090-3456-7890",
    },
    "patient-4": {
      name: "佐藤 花子",
      age: 45,
      address: "東京都品川区品川4-4-4",
      phone: "03-4567-8901",
      diagnosis: "がん終末期",
      careLevel: "要介護5",
      emergencyContact: "佐藤 次郎（夫）",
      emergencyPhone: "090-4567-8901",
    },
    "patient-5": {
      name: "高橋 健太",
      age: 58,
      address: "東京都目黒区目黒5-5-5",
      phone: "03-5678-9012",
      diagnosis: "ALS",
      careLevel: "要介護5",
      emergencyContact: "高橋 美香（妻）",
      emergencyPhone: "090-5678-9012",
    },
  }
  return (
    patients[patientId] || {
      name: "不明",
      age: 0,
      address: "不明",
      phone: "不明",
      diagnosis: "不明",
      careLevel: "不明",
      emergencyContact: "不明",
      emergencyPhone: "不明",
    }
  )
}

export function ScheduleDetailDialog({
  schedule,
  isOpen,
  onClose,
  onEdit,
  onCreateRecord,
  patientName,
  staffName,
}: ScheduleDetailDialogProps) {
  if (!schedule) return null

  const patientDetails = getPatientDetails(schedule.patientId)
  const isToday = format(schedule.visitDate, "yyyy-MM-dd") === format(new Date(), "yyyy-MM-dd")
  const canCreateRecord =
    isToday && (schedule.status === VisitStatus.SCHEDULED || schedule.status === VisitStatus.IN_PROGRESS)

  const getStatusIcon = (status: string) => {
    switch (status) {
      case VisitStatus.COMPLETED:
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case VisitStatus.CANCELLED:
        return <XCircle className="h-4 w-4 text-red-600" />
      case VisitStatus.RESCHEDULED:
        return <AlertCircle className="h-4 w-4 text-yellow-600" />
      default:
        return <Clock className="h-4 w-4 text-blue-600" />
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            訪問予定詳細
          </DialogTitle>
          <DialogDescription>
            {format(schedule.visitDate, "yyyy年M月d日(E)", { locale: ja })} の訪問予定
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <span className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  {patientName}
                </span>
                <div className="flex items-center gap-2 self-end sm:self-center">
                  {getStatusIcon(schedule.status)}
                  <Badge className={getVisitStatusColor(schedule.status)}>{getVisitStatusName(schedule.status)}</Badge>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{formatVisitTime(schedule.startTime, schedule.endTime)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span>{staffName}</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Badge variant="outline" className={getVisitTypeColor(schedule.visitType)}>
                    {getVisitTypeName(schedule.visitType)}
                  </Badge>
                  {schedule.estimatedTravelTime && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      移動時間: 約{schedule.estimatedTravelTime}分
                    </div>
                  )}
                </div>
              </div>
              {schedule.note && (
                <>
                  <Separator />
                  <div>
                    <h4 className="text-sm font-medium mb-2">備考</h4>
                    <p className="text-sm text-muted-foreground">{schedule.note}</p>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">患者情報</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label>年齢</Label>
                  <p className="text-sm">{patientDetails.age}歳</p>
                </div>
                <div>
                  <Label>介護度</Label>
                  <p className="text-sm">{patientDetails.careLevel}</p>
                </div>
              </div>
              <div>
                <Label>住所</Label>
                <p className="text-sm">{patientDetails.address}</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label>電話番号</Label>
                  <div className="flex items-center gap-2">
                    <Phone className="h-3 w-3" />
                    <p className="text-sm">{patientDetails.phone}</p>
                  </div>
                </div>
                <div>
                  <Label>緊急連絡先</Label>
                  <div className="flex items-center gap-2">
                    <Phone className="h-3 w-3" />
                    <p className="text-sm">{patientDetails.emergencyContact}</p>
                  </div>
                </div>
              </div>
              <div>
                <Label>主病名</Label>
                <p className="text-sm">{patientDetails.diagnosis}</p>
              </div>
            </CardContent>
          </Card>
          {isToday && (
            <Card className="border-orange-200 bg-orange-50">
              <CardHeader className="pb-3">
                <CardTitle className="text-base text-orange-800">本日の訪問</CardTitle>
                <CardDescription className="text-orange-600">
                  本日の訪問予定です。記録の作成や詳細の編集ができます。
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col sm:flex-row gap-2">
                  {canCreateRecord && (
                    <Button onClick={() => onCreateRecord(schedule)} className="bg-orange-500 hover:bg-orange-600">
                      <FileText className="mr-2 h-4 w-4" />
                      記録を作成
                    </Button>
                  )}
                  <Button variant="outline" onClick={() => onEdit(schedule)}>
                    <Edit className="mr-2 h-4 w-4" />
                    予定を編集
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            閉じる
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
