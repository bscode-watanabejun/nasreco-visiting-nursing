"use client"

import { useEffect, useState } from "react"
import {
  addMonths,
  eachDayOfInterval,
  endOfMonth,
  format,
  isSameDay,
  startOfMonth,
  subMonths,
} from "date-fns"
import { ja } from "date-fns/locale"
import { Calendar, ChevronLeft, ChevronRight, FileText, Info, ShieldAlert } from 'lucide-react'

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

import { useMediaQuery } from "@/hooks/use-media-query"

import { VisitStatus, VisitType } from "@/lib/db/schedule-schema"
import type { VisitSchedule } from "@/lib/db/schedule-schema"
import {
  getVisitStatusColor,
  getVisitStatusName,
  getVisitTypeColor,
  getVisitTypeName,
  getSchedulesForDate,
} from "@/lib/utils/schedule-utils"

import { ScheduleDetailDialog } from "./schedule-detail-dialog"
import { VisitRecordDialog } from "./visit-record-dialog"

// モック: スタッフ
const mockStaff = [
  { id: "staff-1", name: "山田 花子", role: "看護師" },
  { id: "staff-2", name: "佐藤 次郎", role: "看護師" },
  { id: "staff-3", name: "鈴木 三郎", role: "看護師" },
  { id: "staff-4", name: "田中 四郎", role: "看護師" },
  { id: "staff-5", name: "高橋 五郎", role: "看護師" },
]

// モック: 患者
const mockPatients = [
  { id: "patient-1", name: "佐藤 一郎", age: 68, condition: "糖尿病管理" },
  { id: "patient-2", name: "田中 正男", age: 75, condition: "血圧管理" },
  { id: "patient-3", name: "鈴木 良子", age: 82, condition: "リハビリ" },
  { id: "patient-4", name: "佐藤 花子", age: 45, condition: "化学療法後フォロー" },
  { id: "patient-5", name: "高橋 健太", age: 58, condition: "在宅酸素療法" },
]

// 今日の予定を少なくとも3件用意
const today = new Date()
const mockSchedules: VisitSchedule[] = [
  {
    id: "schedule-today-1",
    patientId: "patient-1",
    staffId: "staff-1",
    visitDate: today,
    startTime: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 9, 0),
    endTime: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 10, 0),
    visitType: VisitType.REGULAR,
    status: VisitStatus.COMPLETED,
    note: "定期訪問 - バイタルチェックと服薬確認",
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "schedule-today-2",
    patientId: "patient-2",
    staffId: "staff-1",
    visitDate: today,
    startTime: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 10, 30),
    endTime: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 11, 15),
    visitType: VisitType.ASSESSMENT,
    status: VisitStatus.IN_PROGRESS,
    note: "アセスメント訪問 - 状態評価と計画見直し",
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "schedule-today-3",
    patientId: "patient-3",
    staffId: "staff-2",
    visitDate: today,
    startTime: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 14, 0),
    endTime: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 15, 0),
    visitType: VisitType.REGULAR,
    status: VisitStatus.SCHEDULED,
    note: "定期訪問 - 創傷処置と清拭",
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
]

// 簡易: 特別管理加算バッジ
const getPatientMedicalProfile = (patientId: string) => {
  const mockProfiles = {
    "patient-1": { specialManagementAdditionStatus: { priorityType: "type1" as const } },
    "patient-2": { specialManagementAdditionStatus: { priorityType: "type2" as const } },
    "patient-3": { specialManagementAdditionStatus: { priorityType: "type2" as const } },
  }
  return mockProfiles[patientId as keyof typeof mockProfiles]
}

const SpecialManagementBadge = ({ patientId }: { patientId: string }) => {
  const profile = getPatientMedicalProfile(patientId)
  const type = profile?.specialManagementAdditionStatus?.priorityType
  if (!type) return null
  if (type === "type1") {
    return (
      <Badge variant="destructive" className="ml-2 text-xs">
        <ShieldAlert className="h-3 w-3 mr-1" />
        特管Ⅰ
      </Badge>
    )
  }
  return (
    <Badge variant="secondary" className="ml-2 bg-yellow-400 text-yellow-900 text-xs">
      <ShieldAlert className="h-3 w-3 mr-1" />
      特管Ⅱ
    </Badge>
  )
}

interface ScheduleCalendarProps {
  initialDate?: Date
  viewMode?: "month" | "week" | "day" | "staff"
  staffId?: string
}

export function ScheduleCalendar({
  initialDate = new Date(),
  viewMode: initialViewMode = "staff",
  staffId: initialStaffId,
}: ScheduleCalendarProps) {
  const [currentDate, setCurrentDate] = useState(initialDate)
  const [viewMode, setViewMode] = useState<"month" | "week" | "day" | "staff">(initialViewMode)
  const [selectedStaffId, setSelectedStaffId] = useState<string | undefined>(initialStaffId || "all")
  const [schedules, setSchedules] = useState<VisitSchedule[]>([])
  const [loading, setLoading] = useState(true)

  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false)
  const [selectedSchedule, setSelectedSchedule] = useState<VisitSchedule | null>(null)
  const [isRecordDialogOpen, setIsRecordDialogOpen] = useState(false)
  const [recordingSchedule, setRecordingSchedule] = useState<VisitSchedule | null>(null)

  const isDesktop = useMediaQuery("(min-width: 768px)")

  useEffect(() => {
    setLoading(true)
    const timer = setTimeout(() => {
      setSchedules(mockSchedules)
      setLoading(false)
    }, 200)
    return () => clearTimeout(timer)
  }, [])

  const goToPrevious = () => {
    if (viewMode === "staff" || viewMode === "day") {
      setCurrentDate((prev) => new Date(prev.getFullYear(), prev.getMonth(), prev.getDate() - 1))
    } else if (viewMode === "month") {
      setCurrentDate((d) => subMonths(d, 1))
    } else if (viewMode === "week") {
      setCurrentDate((prev) => new Date(prev.getTime() - 7 * 24 * 60 * 60 * 1000))
    }
  }

  const goToNext = () => {
    if (viewMode === "staff" || viewMode === "day") {
      setCurrentDate((prev) => new Date(prev.getFullYear(), prev.getMonth(), prev.getDate() + 1))
    } else if (viewMode === "month") {
      setCurrentDate((d) => addMonths(d, 1))
    } else if (viewMode === "week") {
      setCurrentDate((prev) => new Date(prev.getTime() + 7 * 24 * 60 * 60 * 1000))
    }
  }

  const goToToday = () => setCurrentDate(new Date())
  const handleDateClick = (date: Date) => {
    setViewMode("day")
    setCurrentDate(date)
  }

  const handleScheduleClick = (schedule: VisitSchedule) => {
    setSelectedSchedule(schedule)
    setIsDetailDialogOpen(true)
  }
  const handleCreateRecord = (schedule: VisitSchedule) => {
    setRecordingSchedule(schedule)
    setIsDetailDialogOpen(false)
    setIsRecordDialogOpen(true)
  }
  const handleSaveRecord = (recordData: any) => {
    setSchedules((prev) =>
      prev.map((s) => (s.id === recordData.scheduleId ? { ...s, status: recordData.visitStatus } : s)),
    )
    setIsRecordDialogOpen(false)
    setRecordingSchedule(null)
  }

  const getPatientInfo = (patientId: string) => mockPatients.find((p) => p.id === patientId)
  const getPatientName = (patientId: string) => getPatientInfo(patientId)?.name || "不明な患者"
  const getStaffName = (staffId: string) => mockStaff.find((s) => s.id === staffId)?.name || "不明なスタッフ"

  const getDaysInMonth = () =>
    eachDayOfInterval({ start: startOfMonth(currentDate), end: endOfMonth(currentDate) })

  const getSchedulesForDateAndStaff = (date: Date, staffId?: string) => {
    const dateSchedules = getSchedulesForDate(schedules, date)
    return staffId && staffId !== "all" ? dateSchedules.filter((s) => s.staffId === staffId) : dateSchedules
  }

  // 共通の予定カード（スマホ対応レイアウト）
  const renderScheduleItem = (scheduleItem: VisitSchedule, viewType: "day" | "staff") => {
    const patient = getPatientInfo(scheduleItem.patientId)
    const visitDuration = Math.round(
      (scheduleItem.endTime.getTime() - scheduleItem.startTime.getTime()) / (1000 * 60),
    )
    const bgColor =
      scheduleItem.status === VisitStatus.COMPLETED
        ? "bg-green-50"
        : scheduleItem.status === VisitStatus.IN_PROGRESS
          ? "bg-orange-50"
          : "bg-white"
    const borderColor =
      scheduleItem.status === VisitStatus.COMPLETED
        ? "border-green-300"
        : scheduleItem.status === VisitStatus.IN_PROGRESS
          ? "border-orange-300"
          : "border-gray-200"

    const canCreateRecord =
      (scheduleItem.status === VisitStatus.SCHEDULED || scheduleItem.status === VisitStatus.IN_PROGRESS) &&
      isSameDay(scheduleItem.visitDate, new Date())

    return (
      <div key={scheduleItem.id} className={`p-3 rounded-lg border ${bgColor} ${borderColor} shadow-sm`}>
        <div className="flex flex-col sm:flex-row items-start gap-3">
          <div className="w-full sm:w-20 sm:text-center pb-2 sm:pb-0 border-b sm:border-none flex-shrink-0 flex sm:flex-col justify-between items-baseline">
            <div className="text-lg font-bold">{format(scheduleItem.startTime, "HH:mm")}</div>
            <div className="text-xs text-gray-500">{visitDuration}分</div>
          </div>
          <div className="flex-grow w-full sm:pl-2">
            <div className="flex justify-between items-start mb-1">
              <h4 className="font-semibold text-md flex items-center flex-wrap">
                {patient?.name} ({patient?.age}歳)
                {viewType === "day" && (
                  <span className="text-xs text-gray-500 ml-2">担当: {getStaffName(scheduleItem.staffId)}</span>
                )}
                <SpecialManagementBadge patientId={scheduleItem.patientId} />
              </h4>
              <Badge className={`${getVisitStatusColor(scheduleItem.status)} px-2 py-0.5 text-xs`}>
                {getVisitStatusName(scheduleItem.status)}
              </Badge>
            </div>
            <p className="text-sm text-gray-600 mb-2">{patient?.condition}</p>
            {scheduleItem.note && <p className="text-xs text-gray-500 mb-2">備考: {scheduleItem.note}</p>}
          </div>
        </div>
        <div className="mt-3 pt-3 border-t flex gap-2 justify-end">
          <Button
            variant="outline"
            size="sm"
            className="bg-transparent flex-1 sm:flex-none"
            onClick={() => handleScheduleClick(scheduleItem)}
          >
            <Info className="mr-1 h-3 w-3" /> 詳細
          </Button>
          {canCreateRecord && (
            <Button
              size="sm"
              className="bg-orange-500 hover:bg-orange-600 flex-1 sm:flex-none"
              onClick={() => handleCreateRecord(scheduleItem)}
            >
              <FileText className="mr-1 h-3 w-3" /> 記録
            </Button>
          )}
        </div>
      </div>
    )
  }

  const renderMonthView = () => {
    const days = getDaysInMonth()
    // モバイルはリスト、デスクトップは7列グリッド
    if (!isDesktop) {
      return (
        <div className="space-y-2">
          {days.map((day) => {
            const daySchedules = getSchedulesForDateAndStaff(day, selectedStaffId)
            if (daySchedules.length === 0) return null
            return (
              <div key={day.toISOString()}>
                <h3 className="font-semibold text-sm bg-gray-100 p-2 rounded-t-md">
                  {format(day, "M月d日 (E)", { locale: ja })}
                </h3>
                <div className="space-y-2 p-2 border rounded-b-md">
                  {daySchedules.map((item) => (
                    <div
                      key={item.id}
                      className={`text-xs p-2 rounded cursor-pointer hover:opacity-80 ${getVisitTypeColor(
                        item.visitType,
                      )}`}
                      onClick={() => handleScheduleClick(item)}
                    >
                      {format(item.startTime, "HH:mm")} {getPatientName(item.patientId)}
                    </div>
                  ))}
                </div>
              </div>
            )
          })}
        </div>
      )
    }

    const dayNames = ["日", "月", "火", "水", "木", "金", "土"]
    return (
      <div className="grid grid-cols-7 gap-px bg-gray-200 border border-gray-200">
        {dayNames.map((day) => (
          <div key={day} className="py-2 text-center font-medium bg-gray-50 text-xs">
            {day}
          </div>
        ))}
        {days.map((day) => {
          const daySchedules = getSchedulesForDateAndStaff(day, selectedStaffId)
          const isTodayDate = isSameDay(day, new Date())
          return (
            <div
              key={day.toISOString()}
              className={`p-1.5 min-h-[90px] bg-white ${isTodayDate ? "bg-blue-50" : ""}`}
              onClick={() => handleDateClick(day)}
            >
              <div className={`text-right text-xs mb-1 ${isTodayDate ? "text-blue-600 font-bold" : ""}`}>
                {day.getDate()}
              </div>
              <div className="space-y-1">
                {daySchedules.slice(0, 2).map((item) => (
                  <div
                    key={item.id}
                    className={`text-[10px] p-1 rounded truncate cursor-pointer hover:opacity-80 ${getVisitTypeColor(item.visitType)}`}
                    onClick={(e) => {
                      e.stopPropagation()
                      handleScheduleClick(item)
                    }}
                  >
                    {format(item.startTime, "HH:mm")} {getPatientName(item.patientId)}
                  </div>
                ))}
                {daySchedules.length > 2 && (
                  <div className="text-[10px] text-center text-gray-500">他 {daySchedules.length - 2} 件</div>
                )}
              </div>
            </div>
          )
        })}
      </div>
    )
  }

  const renderStaffView = () => {
    const staffToDisplay =
      selectedStaffId && selectedStaffId !== "all" ? mockStaff.filter((s) => s.id === selectedStaffId) : mockStaff

    return (
      <div className="space-y-4">
        {staffToDisplay.map((staff) => {
          const staffSchedules = schedules
            .filter((s) => s.staffId === staff.id && isSameDay(s.visitDate, currentDate))
            .sort((a, b) => a.startTime.getTime() - b.startTime.getTime())

          if (staffSchedules.length === 0) {
            if (selectedStaffId && selectedStaffId !== "all") {
              return (
                <Card key={staff.id}>
                  <CardHeader>
                    <CardTitle>
                      {staff.name} ({staff.role})
                    </CardTitle>
                    <CardDescription>
                      {format(currentDate, "yyyy年M月d日 (E)", { locale: ja })} の予定はありません。
                    </CardDescription>
                  </CardHeader>
                </Card>
              )
            }
            return null
          }

          return (
            <div key={staff.id}>
              {selectedStaffId === "all" && (
                <h3 className="text-lg font-semibold mb-2">
                  {staff.name} ({staff.role})
                </h3>
              )}
              <div className="space-y-3">{staffSchedules.map((item) => renderScheduleItem(item, "staff"))}</div>
            </div>
          )
        })}
      </div>
    )
  }

  const renderDayView = () => {
    const daySchedules = getSchedulesForDateAndStaff(currentDate, selectedStaffId).sort(
      (a, b) => a.startTime.getTime() - b.startTime.getTime(),
    )
    if (daySchedules.length === 0) {
      return <div className="text-center py-8 text-gray-500">この日の予定はありません。</div>
    }
    return <div className="space-y-3">{daySchedules.map((item) => renderScheduleItem(item, "day"))}</div>
  }

  const renderView = () => {
    switch (viewMode) {
      case "month":
        return renderMonthView()
      case "week":
        return <div className="text-center py-8">週表示は現在開発中です。</div>
      case "day":
        return renderDayView()
      case "staff":
        return renderStaffView()
      default:
        return renderMonthView()
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>スケジュール読込中...</CardTitle>
        </CardHeader>
        <CardContent className="h-96 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <CardTitle className="text-xl font-bold">
            {viewMode === "month"
              ? format(currentDate, "yyyy年M月", { locale: ja })
              : `${format(currentDate, "yyyy年M月d日 (E)", { locale: ja })}${
                  selectedStaffId && selectedStaffId !== "all" && viewMode === "staff"
                    ? " - " + getStaffName(selectedStaffId)
                    : ""
                }`}
          </CardTitle>
          <div className="flex items-center space-x-1 sm:space-x-2">
            <Button variant="outline" size="icon" onClick={goToPrevious}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={goToNext}>
              <ChevronRight className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={goToToday}>
              <Calendar className="mr-1.5 h-4 w-4" />
              今日
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pb-2">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
          <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as any)}>
            <TabsList>
              <TabsTrigger value="staff">今日の訪問</TabsTrigger>
              <TabsTrigger value="day">日表示</TabsTrigger>
              <TabsTrigger value="month">月表示</TabsTrigger>
            </TabsList>
          </Tabs>

          <Select
            value={selectedStaffId || "all"}
            onValueChange={(value) => setSelectedStaffId(value === "all" ? undefined : value)}
          >
            <SelectTrigger className="w-full sm:w-[180px] text-xs">
              <SelectValue placeholder="スタッフ選択" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全スタッフ</SelectItem>
              {mockStaff.map((staff) => (
                <SelectItem key={staff.id} value={staff.id}>
                  {staff.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {renderView()}
      </CardContent>

      <CardFooter className="pt-2 border-t mt-4">
        <div className="flex flex-wrap gap-x-3 gap-y-1.5">
          {Object.values(VisitType).map((type) => (
            <TooltipProvider key={type}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Badge className={`text-xs ${getVisitTypeColor(type)}`} variant="outline">
                    {getVisitTypeName(type)}
                  </Badge>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{getVisitTypeName(type)}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ))}
        </div>
      </CardFooter>

      <ScheduleDetailDialog
        schedule={selectedSchedule}
        isOpen={isDetailDialogOpen}
        onClose={() => {
          setIsDetailDialogOpen(false)
          setSelectedSchedule(null)
        }}
        onEdit={() => setIsDetailDialogOpen(false)}
        onCreateRecord={handleCreateRecord}
        patientName={selectedSchedule ? getPatientName(selectedSchedule.patientId) : ""}
        staffName={selectedSchedule ? getStaffName(selectedSchedule.staffId) : ""}
      />

      <VisitRecordDialog
        schedule={recordingSchedule}
        isOpen={isRecordDialogOpen}
        onClose={() => {
          setIsRecordDialogOpen(false)
          setRecordingSchedule(null)
        }}
        onSave={handleSaveRecord}
        patientName={recordingSchedule ? getPatientName(recordingSchedule.patientId) : ""}
        staffName={recordingSchedule ? getStaffName(recordingSchedule.staffId) : ""}
      />
    </Card>
  )
}

// default でもエクスポート（どちらの import 形でも利用可能にする）
export default ScheduleCalendar
