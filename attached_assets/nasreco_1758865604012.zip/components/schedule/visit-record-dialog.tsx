"use client"

import type React from "react"
import { useState, useMemo } from "react"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import { Camera, FileText, Heart, Thermometer, ShieldAlert, AlertCircle, CheckCircle2, Info, Clock } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Alert, AlertDescription } from "@/components/ui/alert"
import type { VisitSchedule } from "../../lib/db/schedule-schema"
import { VisitStatus, VisitType } from "../../lib/db/schedule-schema"
import type { Document } from "@/lib/db/document-schema"
import { DocumentPreviewDialog } from "@/components/documents/document-preview-dialog"

interface VisitRecordDialogProps {
  schedule: VisitSchedule | null
  isOpen: boolean
  onClose: () => void
  onSave: (recordData: any) => void
  patientName: string
  staffName: string
}

const getPatientDocuments = (patientId: string): Document[] => {
  return [
    {
      id: "doc-1",
      patientId: patientId,
      title: "訪問看護指示書_20250401",
      type: "medical_instruction",
      content: "",
      createdAt: new Date("2025-04-01"),
      updatedAt: new Date("2025-04-01"),
      source: "upload",
      fileUrl: "/dummy-instruction.pdf",
      fileName: "訪問看護指示書_20250401.pdf",
    },
    {
      id: "doc-2",
      patientId: patientId,
      title: "居宅サービス計画書(1)",
      type: "care_plan",
      content: "",
      createdAt: new Date("2025-03-15"),
      updatedAt: new Date("2025-03-15"),
      source: "upload",
      fileUrl: "/dummy-careplan.pdf",
      fileName: "居宅サービス計画書(1).pdf",
    },
  ]
}

const getPatientMedicalProfile = (patientId: string) => {
  const mockProfiles: Record<string, any> = {
    "patient-1": {
      specialManagementAdditionStatus: {
        priorityType: "type1" as const,
        isType1Applicable: true,
        isType2Applicable: true,
        applicableItems: ["malignant_tumor", "indwelling_catheter"],
      },
    },
    "patient-2": {
      specialManagementAdditionStatus: {
        priorityType: "type2" as const,
        isType1Applicable: false,
        isType2Applicable: true,
        applicableItems: ["oxygen_therapy", "iv_injection"],
      },
    },
    "patient-3": {
      specialManagementAdditionStatus: {
        priorityType: "type2" as const,
        isType1Applicable: false,
        isType2Applicable: true,
        applicableItems: ["peg", "pressure_ulcer"],
      },
    },
  }
  return mockProfiles[patientId]
}

const getSpecialManagementBadge = (patientId: string) => {
  const profile = getPatientMedicalProfile(patientId)
  if (!profile?.specialManagementAdditionStatus) return null

  const status = profile.specialManagementAdditionStatus
  if (status.priorityType === "type1") {
    return (
      <Badge variant="destructive" className="ml-2 text-xs">
        <ShieldAlert className="h-3 w-3 mr-1" />
        特管Ⅰ
      </Badge>
    )
  }
  if (status.priorityType === "type2") {
    return (
      <Badge variant="secondary" className="ml-2 bg-yellow-400 text-yellow-900 text-xs">
        <ShieldAlert className="h-3 w-3 mr-1" />
        特管Ⅱ
      </Badge>
    )
  }
  return null
}

const getSpecialManagementItemName = (itemId: string) => {
  const itemNames: Record<string, string> = {
    malignant_tumor: "在宅悪性腫瘍等患者指導管理",
    tracheotomy: "在宅気管切開患者指導管理",
    tracheal_cannula: "気管カニューレ使用",
    indwelling_catheter: "留置カテーテル管理",
    narcotic_injection: "在宅麻薬等注射指導管理",
    chemotherapy_injection: "在宅腫瘍化学療法注射指導管理",
    cardiac_drug: "在宅強心剤持続投与指導管理",
    oxygen_therapy: "在宅酸素療法",
    cpap: "在宅持続陽圧呼吸療法(CPAP/ASV)",
    ventilator: "在宅人工呼吸療法",
    peg: "胃ろう・腸ろうによる経管栄養",
    ng_tube: "経鼻経管栄養",
    stoma: "人工肛門(ストーマ)",
    urostomy: "人工膀胱",
    pressure_ulcer: "真皮を越える褥瘡",
    iv_injection: "点滴注射(週3日以上)",
  }
  return itemNames[itemId] || itemId
}

export function VisitRecordDialog({
  schedule,
  isOpen,
  onClose,
  onSave,
  patientName,
  staffName,
}: VisitRecordDialogProps) {
  const [recordData, setRecordData] = useState({
    visitStatus: VisitStatus.COMPLETED,
    startTime: "",
    endTime: "",
    observations: "",
    careProvided: "",
    nextVisitNotes: "",
    photos: [] as File[],
    isMultipleVisits: false,
    multipleVisitsReason: "",
    emergencyReason: "",
    longDurationReason: "",
    vitalSigns: {
      bloodPressureSystolic: "",
      bloodPressureDiastolic: "",
      pulse: "",
      temperature: "",
      respiratoryRate: "",
      oxygenSaturation: "",
    },
    specialManagement: {
      deviceCheck: false,
      catheterStatus: "",
      skinCondition: "",
      managementDetail: "",
      abnormalFindings: "",
      doctorInstruction: false,
    },
  })

  const [activeTab, setActiveTab] = useState("basic")
  const [isPreviewOpen, setIsPreviewOpen] = useState(false)
  const [previewDocument, setPreviewDocument] = useState<Document | null>(null)

  const patientDocuments = useMemo(() => {
    return schedule ? getPatientDocuments(schedule.patientId) : []
  }, [schedule])

  const handlePreview = (type: "medical_instruction" | "care_plan") => {
    const doc = patientDocuments
      .filter((d) => d.type === type)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())[0]

    if (doc) {
      setPreviewDocument(doc)
      setIsPreviewOpen(true)
    } else {
      alert(`${type === "medical_instruction" ? "指示書" : "ケアプラン"}の書類が見つかりません。`)
    }
  }

  const patientProfile = schedule ? getPatientMedicalProfile(schedule.patientId) : null
  const isSpecialManagementPatient = !!patientProfile?.specialManagementAdditionStatus
  const specialManagementItems = patientProfile?.specialManagementAdditionStatus?.applicableItems || []

  const handleSave = () => {
    onSave({
      ...recordData,
      scheduleId: schedule?.id,
      patientId: schedule?.patientId,
      staffId: schedule?.staffId,
      recordedAt: new Date(),
    })
    onClose()
  }

  const handleVitalSignChange = (field: string, value: string) => {
    setRecordData((prev) => ({
      ...prev,
      vitalSigns: {
        ...prev.vitalSigns,
        [field]: value,
      },
    }))
  }

  const handleSpecialManagementChange = (field: string, value: string | boolean) => {
    setRecordData((prev) => ({
      ...prev,
      specialManagement: {
        ...prev.specialManagement,
        [field]: value,
      },
    }))
  }

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || [])
    setRecordData((prev) => ({
      ...prev,
      photos: [...prev.photos, ...files],
    }))
  }

  const visitConditions = useMemo(() => {
    if (!schedule) {
      return { isEmergencyVisit: false, isLongDurationVisit: false, actualDuration: 0 }
    }
    const isEmergencyVisit = schedule.visitType === VisitType.EMERGENCY
    const { startTime, endTime } = recordData
    let actualDuration = 0
    if (startTime && endTime) {
      const start = new Date(`1970-01-01T${startTime}`)
      const end = new Date(`1970-01-01T${endTime}`)
      actualDuration = (end.getTime() - start.getTime()) / (1000 * 60)
    }
    const isLongDurationVisit = actualDuration > 90
    return { isEmergencyVisit, isLongDurationVisit, actualDuration }
  }, [schedule, recordData])

  const missingFields = useMemo(() => {
    const missing: { id: string; message: string }[] = []
    if (!recordData.startTime) missing.push({ id: "startTime", message: "「実際の開始時間」を入力してください。" })
    if (!recordData.endTime) missing.push({ id: "endTime", message: "「実際の終了時間」を入力してください。" })
    if (!recordData.observations) missing.push({ id: "observations", message: "「観察記録」を入力してください。" })
    if (visitConditions.isEmergencyVisit && !recordData.emergencyReason) {
      missing.push({ id: "emergencyReason", message: "【緊急訪問】のため「理由」の入力が必要です。" })
    }
    if (visitConditions.isLongDurationVisit && !recordData.longDurationReason) {
      missing.push({
        id: "longDurationReason",
        message: `【長時間訪問(${Math.round(visitConditions.actualDuration)}分)】のため「理由」の入力が必要です。`,
      })
    }
    if (recordData.isMultipleVisits && !recordData.multipleVisitsReason) {
      missing.push({ id: "multipleVisitsReason", message: "【複数回訪問】のため「理由」の入力が必要です。" })
    }
    if (isSpecialManagementPatient) {
      if (!recordData.specialManagement.managementDetail) {
        missing.push({
          id: "specialManagementDetail",
          message: "【特別管理加算】の算定には「管理内容詳細」の記録が必要です。",
        })
      }
      if (!recordData.specialManagement.abnormalFindings) {
        missing.push({
          id: "specialManagementFindings",
          message: "【特別管理加算】の算定には「異常所見」の確認が必要です。",
        })
      }
    }
    return missing
  }, [recordData, visitConditions, isSpecialManagementPatient])

  if (!schedule) return null

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto text-base">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              <FileText className="h-6 w-6" />
              訪問記録の作成
            </DialogTitle>
            <DialogDescription className="text-base">
              {format(schedule.visitDate, "yyyy年M月d日(E)", { locale: ja })} の訪問記録を作成します
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">基本情報</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm text-muted-foreground">患者</Label>
                    <div className="flex items-center">
                      <p className="font-medium text-lg">{patientName}</p>
                      {schedule && getSpecialManagementBadge(schedule.patientId)}
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm text-muted-foreground">担当者</Label>
                    <p className="font-medium text-lg">{staffName}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 items-end">
                  <div>
                    <Label className="text-sm text-muted-foreground">予定時間</Label>
                    <p className="text-base">
                      {format(schedule.startTime, "HH:mm")} - {format(schedule.endTime, "HH:mm")}
                    </p>
                  </div>
                  <div>
                    <Label htmlFor="visitStatus" className="text-sm">
                      訪問ステータス
                    </Label>
                    <Select
                      value={recordData.visitStatus}
                      onValueChange={(value) => setRecordData((prev) => ({ ...prev, visitStatus: value as any }))}
                    >
                      <SelectTrigger className="h-10 text-base">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={VisitStatus.COMPLETED}>完了</SelectItem>
                        <SelectItem value={VisitStatus.CANCELLED}>キャンセル</SelectItem>
                        <SelectItem value={VisitStatus.RESCHEDULED}>日程変更</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {isSpecialManagementPatient && (
                  <Alert className="border-yellow-200 bg-yellow-50">
                    <ShieldAlert className="h-5 w-5 text-yellow-600" />
                    <AlertDescription className="text-yellow-800 text-base">
                      <div className="font-bold mb-2">特別管理加算対象患者</div>
                      <div>
                        <strong>対象項目:</strong>
                        <div className="mt-1 space-y-1">
                          {specialManagementItems.map((item) => (
                            <div key={item} className="flex items-center gap-2">
                              <CheckCircle2 className="h-4 w-4 text-green-600" />
                              <span>{getSpecialManagementItemName(item)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}

                {missingFields.length > 0 && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-5 w-5" />
                    <AlertDescription className="text-base">
                      <div className="font-bold mb-1">未入力の必須項目があります</div>
                      <ul className="list-disc list-inside">
                        {missingFields.map((field) => (
                          <li key={field.id}>{field.message}</li>
                        ))}
                      </ul>
                    </AlertDescription>
                  </Alert>
                )}
                <div className="flex flex-wrap gap-2 mt-3">
                  <Button
                    variant="outline"
                    className="flex items-center gap-1 border-blue-300 text-blue-700 hover:bg-blue-50 bg-transparent"
                    onClick={() => handlePreview("medical_instruction")}
                  >
                    <FileText className="h-4 w-4" />
                    医師指示書を確認
                  </Button>
                  <Button
                    variant="outline"
                    className="flex items-center gap-1 border-green-300 text-green-700 hover:bg-green-50 bg-transparent"
                    onClick={() => handlePreview("care_plan")}
                  >
                    <Heart className="h-4 w-4" />
                    ケアプランを確認
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3 md:grid-cols-5">
                <TabsTrigger value="basic" className="text-sm">
                  基本記録
                  {missingFields.some((f) =>
                    [
                      "startTime",
                      "endTime",
                      "observations",
                      "emergencyReason",
                      "longDurationReason",
                      "multipleVisitsReason",
                    ].includes(f.id),
                  ) && <span className="ml-1 h-2 w-2 bg-red-500 rounded-full"></span>}
                </TabsTrigger>
                <TabsTrigger value="vitals" className="text-sm">
                  バイタル
                </TabsTrigger>
                <TabsTrigger value="care" className="text-sm">
                  ケア内容
                </TabsTrigger>
                {isSpecialManagementPatient && (
                  <TabsTrigger value="special" className="text-sm">
                    特管記録
                    {missingFields.some((f) =>
                      ["specialManagementDetail", "specialManagementFindings"].includes(f.id),
                    ) && <span className="ml-1 h-2 w-2 bg-red-500 rounded-full"></span>}
                  </TabsTrigger>
                )}
                <TabsTrigger value="media" className="text-sm">
                  写真・メモ
                </TabsTrigger>
              </TabsList>

              <TabsContent value="basic" className="space-y-4 pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="actualStartTime" className="text-base flex items-center gap-1 mb-1">
                      実際の開始時間<span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="actualStartTime"
                      type="time"
                      value={recordData.startTime}
                      onChange={(e) => setRecordData((prev) => ({ ...prev, startTime: e.target.value }))}
                      className="h-10 text-base"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="actualEndTime" className="text-base flex items-center gap-1 mb-1">
                      実際の終了時間<span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="actualEndTime"
                      type="time"
                      value={recordData.endTime}
                      onChange={(e) => setRecordData((prev) => ({ ...prev, endTime: e.target.value }))}
                      className="h-10 text-base"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="observations" className="text-base flex items-center gap-1 mb-1">
                    観察記録<span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="observations"
                    placeholder="患者の状態、変化、気づいた点などを記録してください"
                    value={recordData.observations}
                    onChange={(e) => setRecordData((prev) => ({ ...prev, observations: e.target.value }))}
                    className="min-h-[100px] text-base"
                    required
                  />
                </div>

                <div className="space-y-4">
                  {visitConditions.isEmergencyVisit && (
                    <div className="border-l-4 border-red-400 bg-red-50 p-3 rounded-r">
                      <Label
                        htmlFor="emergencyReason"
                        className="text-base font-medium text-red-800 flex items-center gap-2"
                      >
                        <AlertCircle className="h-5 w-5" />
                        緊急訪問の理由<span className="text-red-500 ml-1">*</span>
                      </Label>
                      <Textarea
                        id="emergencyReason"
                        placeholder="緊急訪問となった理由を具体的に記載してください"
                        value={recordData.emergencyReason}
                        onChange={(e) => setRecordData((prev) => ({ ...prev, emergencyReason: e.target.value }))}
                        className="min-h-[80px] mt-2 bg-white text-base"
                        required
                      />
                    </div>
                  )}
                  {visitConditions.isLongDurationVisit && (
                    <div className="border-l-4 border-orange-400 bg-orange-50 p-3 rounded-r">
                      <Label
                        htmlFor="longDurationReason"
                        className="text-base font-medium text-orange-800 flex items-center gap-2"
                      >
                        <Clock className="h-5 w-5" />
                        長時間訪問の理由 ({Math.round(visitConditions.actualDuration)}分)
                        <span className="text-red-500 ml-1">*</span>
                      </Label>
                      <Textarea
                        id="longDurationReason"
                        placeholder="訪問時間が90分を超えました。理由を具体的に記載してください"
                        value={recordData.longDurationReason}
                        onChange={(e) => setRecordData((prev) => ({ ...prev, longDurationReason: e.target.value }))}
                        className="min-h-[80px] mt-2 bg-white text-base"
                        required
                      />
                    </div>
                  )}
                  <div className="flex items-center space-x-2 pt-2">
                    <Checkbox
                      id="isMultipleVisits"
                      checked={recordData.isMultipleVisits}
                      onCheckedChange={(checked) =>
                        setRecordData((prev) => ({ ...prev, isMultipleVisits: checked as boolean }))
                      }
                    />
                    <Label htmlFor="isMultipleVisits" className="text-base font-medium">
                      本日2回目以降の訪問
                    </Label>
                  </div>
                  {recordData.isMultipleVisits && (
                    <div className="border-l-4 border-blue-400 bg-blue-50 p-3 rounded-r">
                      <Label
                        htmlFor="multipleVisitsReason"
                        className="text-base font-medium text-blue-800 flex items-center gap-2"
                      >
                        <Info className="h-5 w-5" />
                        複数回訪問の理由<span className="text-red-500 ml-1">*</span>
                      </Label>
                      <Textarea
                        id="multipleVisitsReason"
                        placeholder="複数回訪問となった理由を具体的に記載してください"
                        value={recordData.multipleVisitsReason}
                        onChange={(e) => setRecordData((prev) => ({ ...prev, multipleVisitsReason: e.target.value }))}
                        className="min-h-[80px] mt-2 bg-white text-base"
                        required
                      />
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="vitals" className="space-y-4 pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-base flex items-center gap-1 mb-1">
                      <Heart className="h-4 w-4" />
                      血圧 (mmHg)
                    </Label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="収縮期"
                        value={recordData.vitalSigns.bloodPressureSystolic}
                        onChange={(e) => handleVitalSignChange("bloodPressureSystolic", e.target.value)}
                        className="h-10 text-base"
                      />
                      <span className="self-center text-lg">/</span>
                      <Input
                        placeholder="拡張期"
                        value={recordData.vitalSigns.bloodPressureDiastolic}
                        onChange={(e) => handleVitalSignChange("bloodPressureDiastolic", e.target.value)}
                        className="h-10 text-base"
                      />
                    </div>
                  </div>
                  <div>
                    <Label className="text-base mb-1">脈拍 (回/分)</Label>
                    <Input
                      placeholder="例: 72"
                      value={recordData.vitalSigns.pulse}
                      onChange={(e) => handleVitalSignChange("pulse", e.target.value)}
                      className="h-10 text-base"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-base flex items-center gap-1 mb-1">
                      <Thermometer className="h-4 w-4" />
                      体温 (℃)
                    </Label>
                    <Input
                      placeholder="例: 36.5"
                      value={recordData.vitalSigns.temperature}
                      onChange={(e) => handleVitalSignChange("temperature", e.target.value)}
                      className="h-10 text-base"
                    />
                  </div>
                  <div>
                    <Label className="text-base mb-1">呼吸数 (回/分)</Label>
                    <Input
                      placeholder="例: 18"
                      value={recordData.vitalSigns.respiratoryRate}
                      onChange={(e) => handleVitalSignChange("respiratoryRate", e.target.value)}
                      className="h-10 text-base"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-base mb-1">酸素飽和度 (%)</Label>
                    <Input
                      placeholder="例: 98"
                      value={recordData.vitalSigns.oxygenSaturation}
                      onChange={(e) => handleVitalSignChange("oxygenSaturation", e.target.value)}
                      className="h-10 text-base"
                    />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="care" className="space-y-4 pt-4">
                <div>
                  <Label htmlFor="careProvided" className="text-base mb-1">
                    実施したケア内容
                  </Label>
                  <Textarea
                    id="careProvided"
                    placeholder="実施した看護ケア、処置、指導内容などを記録してください"
                    value={recordData.careProvided}
                    onChange={(e) => setRecordData((prev) => ({ ...prev, careProvided: e.target.value }))}
                    className="min-h-[120px] text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="nextVisitNotes" className="text-base mb-1">
                    次回訪問時の申し送り
                  </Label>
                  <Textarea
                    id="nextVisitNotes"
                    placeholder="次回訪問時に注意すべき点、継続すべきケアなどを記録してください"
                    value={recordData.nextVisitNotes}
                    onChange={(e) => setRecordData((prev) => ({ ...prev, nextVisitNotes: e.target.value }))}
                    className="min-h-[100px] text-base"
                  />
                </div>
              </TabsContent>

              {isSpecialManagementPatient && (
                <TabsContent value="special" className="space-y-4 pt-4">
                  <Alert className="border-blue-200 bg-blue-50">
                    <Info className="h-5 w-5 text-blue-600" />
                    <AlertDescription className="text-blue-800 text-base">
                      特別管理加算対象患者のため、以下の項目は必須入力です。
                    </AlertDescription>
                  </Alert>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2 pt-2">
                      <Checkbox
                        id="deviceCheck"
                        checked={recordData.specialManagement.deviceCheck}
                        onCheckedChange={(checked) => handleSpecialManagementChange("deviceCheck", checked as boolean)}
                      />
                      <Label htmlFor="deviceCheck" className="text-base">
                        医療機器作動確認を実施した
                      </Label>
                    </div>
                    <div>
                      <Label htmlFor="catheterStatus" className="text-base mb-1">
                        カテーテル固定・清潔状態
                      </Label>
                      <Select
                        value={recordData.specialManagement.catheterStatus}
                        onValueChange={(value) => handleSpecialManagementChange("catheterStatus", value)}
                      >
                        <SelectTrigger className="h-10 text-base">
                          <SelectValue placeholder="状態を選択" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="good">良好</SelectItem>
                          <SelectItem value="attention">要注意</SelectItem>
                          <SelectItem value="problem">問題あり</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="skinCondition" className="text-base mb-1">
                        皮膚状態観察
                      </Label>
                      <Textarea
                        id="skinCondition"
                        placeholder="皮膚の状態、発赤、浮腫、創傷の有無などを記録"
                        value={recordData.specialManagement.skinCondition}
                        onChange={(e) => handleSpecialManagementChange("skinCondition", e.target.value)}
                        className="min-h-[80px] text-base"
                      />
                    </div>
                    <div>
                      <Label htmlFor="managementDetail" className="text-base flex items-center gap-1 mb-1">
                        管理内容詳細<span className="text-red-500">*</span>
                      </Label>
                      <Textarea
                        id="managementDetail"
                        placeholder="特別管理加算対象項目に関する具体的な管理内容を記録してください"
                        value={recordData.specialManagement.managementDetail}
                        onChange={(e) => handleSpecialManagementChange("managementDetail", e.target.value)}
                        className="min-h-[100px] text-base"
                        required
                      />
                    </div>
                    <div>
                      <Label className="text-base flex items-center gap-1 mb-1">
                        異常所見<span className="text-red-500">*</span>
                      </Label>
                      <Select
                        value={recordData.specialManagement.abnormalFindings}
                        onValueChange={(value) => handleSpecialManagementChange("abnormalFindings", value)}
                      >
                        <SelectTrigger className="h-10 text-base">
                          <SelectValue placeholder="選択してください" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">異常所見なし</SelectItem>
                          <SelectItem value="minor">軽微な異常あり</SelectItem>
                          <SelectItem value="significant">重要な異常あり</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-center space-x-2 pt-2">
                      <Checkbox
                        id="doctorInstruction"
                        checked={recordData.specialManagement.doctorInstruction}
                        onCheckedChange={(checked) =>
                          handleSpecialManagementChange("doctorInstruction", checked as boolean)
                        }
                      />
                      <Label htmlFor="doctorInstruction" className="text-base">
                        医師指示書の内容を確認した
                      </Label>
                    </div>
                  </div>
                </TabsContent>
              )}

              <TabsContent value="media" className="space-y-4 pt-4">
                <div>
                  <Label className="text-base flex items-center gap-1 mb-1">
                    <Camera className="h-4 w-4" />
                    写真の追加
                  </Label>
                  <Input
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handlePhotoUpload}
                    className="h-10 text-base"
                  />
                  {recordData.photos.length > 0 && (
                    <div className="mt-2">
                      <p className="text-sm text-muted-foreground">
                        {recordData.photos.length} 枚の写真が選択されています
                      </p>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>

          <DialogFooter className="gap-2 pt-4">
            <Button variant="outline" onClick={onClose} size="lg">
              キャンセル
            </Button>
            <Button
              onClick={handleSave}
              className="bg-orange-500 hover:bg-orange-600"
              disabled={missingFields.length > 0}
              size="lg"
            >
              記録を保存
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <DocumentPreviewDialog
        isOpen={isPreviewOpen}
        onClose={() => setIsPreviewOpen(false)}
        document={previewDocument}
      />
    </>
  )
}
