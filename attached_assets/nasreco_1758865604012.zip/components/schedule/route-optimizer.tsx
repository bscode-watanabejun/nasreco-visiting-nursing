"use client"

import { useState, useEffect } from "react"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import { MapPin, Navigation, RotateCw, Clock, ArrowRight, Check } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { VisitStatus, VisitType, type VisitSchedule, type Route, type Location } from "@/lib/db/schedule-schema"
import { getVisitTypeName, formatVisitTime } from "@/lib/utils/schedule-utils"
import {
  generateRoute,
  optimizeRoute,
  generateGoogleMapsNavigationUrl,
  generateGoogleMapsRouteUrl,
} from "@/lib/utils/map-utils"

// モックデータ - スタッフ
const mockStaff = [
  { id: "staff-1", name: "山田 花子", role: "看護師" },
  { id: "staff-2", name: "佐藤 次郎", role: "看護師" },
  { id: "staff-3", name: "鈴木 三郎", role: "看護師" },
  { id: "staff-4", name: "田中 四郎", role: "看護師" },
  { id: "staff-5", name: "高橋 五郎", role: "看護師" },
]

// モックデータ - 患者
const mockPatients = [
  { id: "patient-1", name: "佐藤 一郎", age: 68 },
  { id: "patient-2", name: "田中 正男", age: 75 },
  { id: "patient-3", name: "鈴木 良子", age: 82 },
  { id: "patient-4", name: "佐藤 花子", age: 45 },
  { id: "patient-5", name: "高橋 健太", age: 58 },
]

// モックデータ - 訪問スケジュール
const mockSchedules: VisitSchedule[] = [
  {
    id: "schedule-1",
    patientId: "patient-1",
    staffId: "staff-1",
    visitDate: new Date(2025, 3, 1), // 2025-04-01
    startTime: new Date(2025, 3, 1, 9, 0), // 9:00
    endTime: new Date(2025, 3, 1, 10, 0), // 10:00
    visitType: VisitType.REGULAR,
    status: VisitStatus.SCHEDULED,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "schedule-2",
    patientId: "patient-2",
    staffId: "staff-1",
    visitDate: new Date(2025, 3, 1), // 2025-04-01
    startTime: new Date(2025, 3, 1, 11, 0), // 11:00
    endTime: new Date(2025, 3, 1, 12, 0), // 12:00
    visitType: VisitType.REGULAR,
    status: VisitStatus.SCHEDULED,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "schedule-3",
    patientId: "patient-3",
    staffId: "staff-1",
    visitDate: new Date(2025, 3, 1), // 2025-04-01
    startTime: new Date(2025, 3, 1, 14, 0), // 14:00
    endTime: new Date(2025, 3, 1, 15, 0), // 15:00
    visitType: VisitType.REGULAR,
    status: VisitStatus.SCHEDULED,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
]

// モックデータ - 位置情報
const mockLocations: Record<string, Location> = {
  office: {
    id: "office",
    name: "訪問看護ステーション",
    address: "東京都新宿区西新宿1-1-1",
    latitude: 35.6938,
    longitude: 139.7034,
    type: "office",
    isDefault: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  "patient-1": {
    id: "location-1",
    name: "佐藤 一郎宅",
    address: "東京都新宿区西新宿2-2-2",
    latitude: 35.6924,
    longitude: 139.6965,
    type: "patient",
    patientId: "patient-1",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  "patient-2": {
    id: "location-2",
    name: "田中 正男宅",
    address: "東京都新宿区西新宿3-3-3",
    latitude: 35.6891,
    longitude: 139.6922,
    type: "patient",
    patientId: "patient-2",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  "patient-3": {
    id: "location-3",
    name: "鈴木 良子宅",
    address: "東京都新宿区西新宿4-4-4",
    latitude: 35.6857,
    longitude: 139.6897,
    type: "patient",
    patientId: "patient-3",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  "patient-4": {
    id: "location-4",
    name: "佐藤 花子宅",
    address: "東京都新宿区西新宿5-5-5",
    latitude: 35.6832,
    longitude: 139.6874,
    type: "patient",
    patientId: "patient-4",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  "patient-5": {
    id: "location-5",
    name: "高橋 健太宅",
    address: "東京都新宿区西新宿6-6-6",
    latitude: 35.6812,
    longitude: 139.6853,
    type: "patient",
    patientId: "patient-5",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
}

interface RouteOptimizerProps {
  initialDate?: Date
  staffId?: string
}

export function RouteOptimizer({ initialDate = new Date(), staffId: initialStaffId }: RouteOptimizerProps) {
  const [currentDate, setCurrentDate] = useState(initialDate)
  const [selectedStaffId, setSelectedStaffId] = useState<string>(initialStaffId || "staff-1")
  const [schedules, setSchedules] = useState<VisitSchedule[]>([])
  const [route, setRoute] = useState<Route | null>(null)
  const [optimizedRoute, setOptimizedRoute] = useState<Route | null>(null)
  const [loading, setLoading] = useState(true)
  const [optimizing, setOptimizing] = useState(false)
  const [activeTab, setActiveTab] = useState("current")

  // データ取得（モック）
  useEffect(() => {
    // 実際の実装ではAPIからデータを取得
    setLoading(true)

    // モックデータをセット
    setTimeout(() => {
      // 選択されたスタッフと日付のスケジュールをフィルタリング
      const filteredSchedules = mockSchedules.filter(
        (schedule) =>
          schedule.staffId === selectedStaffId &&
          schedule.visitDate.getDate() === currentDate.getDate() &&
          schedule.visitDate.getMonth() === currentDate.getMonth() &&
          schedule.visitDate.getFullYear() === currentDate.getFullYear(),
      )

      setSchedules(filteredSchedules)

      // ルート情報を生成
      if (filteredSchedules.length > 0) {
        const newRoute = generateRoute(filteredSchedules, mockLocations, mockLocations["office"])
        setRoute(newRoute)
      } else {
        setRoute(null)
      }

      setOptimizedRoute(null)
      setLoading(false)
    }, 500)
  }, [selectedStaffId, currentDate])

  // ルートを最適化
  const handleOptimizeRoute = () => {
    if (!route) return

    setOptimizing(true)

    // 実際の実装ではAPIを呼び出して最適化
    setTimeout(() => {
      const newOptimizedRoute = optimizeRoute(route, mockLocations, mockLocations["office"])
      setOptimizedRoute(newOptimizedRoute)
      setOptimizing(false)
      setActiveTab("optimized")
    }, 1000)
  }

  // 患者名を取得
  const getPatientName = (patientId: string) => {
    const patient = mockPatients.find((p) => p.id === patientId)
    return patient ? patient.name : "不明な患者"
  }

  // スタッフ名を取得
  const getStaffName = (staffId: string) => {
    const staff = mockStaff.find((s) => s.id === staffId)
    return staff ? staff.name : "不明なスタッフ"
  }

  // Google マップのナビゲーションURLを生成
  const getNavigationUrl = (fromLocationId: string, toLocationId: string) => {
    const fromLocation = fromLocationId === "office" ? mockLocations["office"] : mockLocations[fromLocationId]
    const toLocation = toLocationId === "office" ? mockLocations["office"] : mockLocations[toLocationId]

    if (!fromLocation || !toLocation) return "#"

    return generateGoogleMapsNavigationUrl(fromLocation, toLocation)
  }

  // Google マップのルートURLを生成
  const getRouteUrl = (routeData: Route) => {
    const origin = mockLocations["office"]
    const destination = mockLocations["office"]
    const waypoints = routeData.schedules.map((schedule) => mockLocations[schedule.patientId])

    return generateGoogleMapsRouteUrl(origin, destination, waypoints)
  }

  // 現在のルートを表示
  const renderCurrentRoute = () => {
    if (!route || route.schedules.length === 0) {
      return (
        <div className="text-center py-8">
          <p className="text-muted-foreground">訪問予定がありません</p>
        </div>
      )
    }

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-medium">現在のルート</h3>
            <p className="text-sm text-muted-foreground">
              総移動距離: {route.totalTravelDistance}km / 総移動時間: 約{route.totalTravelTime}分
            </p>
          </div>
          <Button onClick={handleOptimizeRoute} disabled={optimizing}>
            {optimizing ? (
              <>
                <RotateCw className="mr-2 h-4 w-4 animate-spin" />
                最適化中...
              </>
            ) : (
              <>
                <Navigation className="mr-2 h-4 w-4" />
                ルート最適化
              </>
            )}
          </Button>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>順序</TableHead>
                <TableHead>時間</TableHead>
                <TableHead>訪問先</TableHead>
                <TableHead>訪問タイプ</TableHead>
                <TableHead>移動</TableHead>
                <TableHead className="text-right">アクション</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>出発</TableCell>
                <TableCell>-</TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <MapPin className="mr-2 h-4 w-4 text-primary" />
                    {mockLocations["office"].name}
                  </div>
                </TableCell>
                <TableCell>-</TableCell>
                <TableCell>-</TableCell>
                <TableCell className="text-right">-</TableCell>
              </TableRow>

              {route.schedules.map((schedule, index) => {
                const fromLocationId = index === 0 ? "office" : route.schedules[index - 1].patientId
                const toLocationId = schedule.patientId

                return (
                  <TableRow key={schedule.id}>
                    <TableCell>{index + 1}</TableCell>
                    <TableCell>{formatVisitTime(schedule.startTime, schedule.endTime)}</TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <MapPin className="mr-2 h-4 w-4 text-primary" />
                        {getPatientName(schedule.patientId)}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {mockLocations[schedule.patientId]?.address}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{getVisitTypeName(schedule.visitType)}</Badge>
                    </TableCell>
                    <TableCell>
                      {schedule.estimatedTravelTime ? (
                        <div className="flex items-center text-sm">
                          <Clock className="mr-1 h-3 w-3 text-muted-foreground" />
                          <span>約{schedule.estimatedTravelTime}分</span>
                        </div>
                      ) : (
                        <div className="flex items-center text-sm">
                          <Clock className="mr-1 h-3 w-3 text-muted-foreground" />
                          <span>計算中...</span>
                        </div>
                      )}
                      {schedule.estimatedTravelDistance && (
                        <div className="text-xs text-muted-foreground">{schedule.estimatedTravelDistance}km</div>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <a
                        href={getNavigationUrl(fromLocationId, toLocationId)}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Button variant="outline" size="sm">
                          <Navigation className="mr-2 h-3 w-3" />
                          ナビ
                        </Button>
                      </a>
                    </TableCell>
                  </TableRow>
                )
              })}

              <TableRow>
                <TableCell>帰着</TableCell>
                <TableCell>-</TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <MapPin className="mr-2 h-4 w-4 text-primary" />
                    {mockLocations["office"].name}
                  </div>
                </TableCell>
                <TableCell>-</TableCell>
                <TableCell>
                  {route.schedules.length > 0 && (
                    <>
                      <div className="flex items-center text-sm">
                        <Clock className="mr-1 h-3 w-3 text-muted-foreground" />
                        <span>約30分</span>
                      </div>
                      <div className="text-xs text-muted-foreground">5.2km</div>
                    </>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  {route.schedules.length > 0 && (
                    <a
                      href={getNavigationUrl(route.schedules[route.schedules.length - 1].patientId, "office")}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm">
                        <Navigation className="mr-2 h-3 w-3" />
                        ナビ
                      </Button>
                    </a>
                  )}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>

        <div className="flex justify-end">
          <a href={getRouteUrl(route)} target="_blank" rel="noopener noreferrer">
            <Button variant="outline">
              <MapPin className="mr-2 h-4 w-4" />
              全体ルートを地図で見る
            </Button>
          </a>
        </div>
      </div>
    )
  }

  // 最適化されたルートを表示
  const renderOptimizedRoute = () => {
    if (!optimizedRoute) {
      return (
        <div className="text-center py-8">
          <p className="text-muted-foreground">最適化されたルートがありません</p>
          <Button className="mt-4" onClick={handleOptimizeRoute} disabled={!route || optimizing}>
            {optimizing ? (
              <>
                <RotateCw className="mr-2 h-4 w-4 animate-spin" />
                最適化中...
              </>
            ) : (
              <>
                <Navigation className="mr-2 h-4 w-4" />
                ルート最適化
              </>
            )}
          </Button>
        </div>
      )
    }

    // 最適化による改善を計算
    const distanceImprovement = route
      ? Math.round((route.totalTravelDistance - optimizedRoute.totalTravelDistance) * 100) / 100
      : 0
    const timeImprovement = route ? route.totalTravelTime - optimizedRoute.totalTravelTime : 0
    const improvementPercentage = route ? Math.round((distanceImprovement / route.totalTravelDistance) * 100) : 0

    return (
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-medium">最適化されたルート</h3>
          <p className="text-sm text-muted-foreground">
            総移動距離: {optimizedRoute.totalTravelDistance}km / 総移動時間: 約{optimizedRoute.totalTravelTime}分
          </p>
        </div>

        {distanceImprovement > 0 && (
          <Alert className="bg-green-50 border-green-200">
            <Check className="h-4 w-4 text-green-600" />
            <AlertTitle className="text-green-800">ルートが最適化されました</AlertTitle>
            <AlertDescription className="text-green-700">
              移動距離が{distanceImprovement}km ({improvementPercentage}%)、移動時間が約{timeImprovement}
              分短縮されました。
            </AlertDescription>
          </Alert>
        )}

        {distanceImprovement <= 0 && (
          <Alert className="bg-blue-50 border-blue-200">
            <Check className="h-4 w-4 text-blue-600" />
            <AlertTitle className="text-blue-800">現在のルートが最適です</AlertTitle>
            <AlertDescription className="text-blue-700">現在のルートが既に最適な順序になっています。</AlertDescription>
          </Alert>
        )}

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>順序</TableHead>
                <TableHead>時間</TableHead>
                <TableHead>訪問先</TableHead>
                <TableHead>訪問タイプ</TableHead>
                <TableHead>移動</TableHead>
                <TableHead className="text-right">アクション</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>出発</TableCell>
                <TableCell>-</TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <MapPin className="mr-2 h-4 w-4 text-primary" />
                    {mockLocations["office"].name}
                  </div>
                </TableCell>
                <TableCell>-</TableCell>
                <TableCell>-</TableCell>
                <TableCell className="text-right">-</TableCell>
              </TableRow>

              {optimizedRoute.schedules.map((schedule, index) => {
                const fromLocationId = index === 0 ? "office" : optimizedRoute.schedules[index - 1].patientId
                const toLocationId = schedule.patientId

                return (
                  <TableRow key={schedule.id}>
                    <TableCell>{index + 1}</TableCell>
                    <TableCell>{formatVisitTime(schedule.startTime, schedule.endTime)}</TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <MapPin className="mr-2 h-4 w-4 text-primary" />
                        {getPatientName(schedule.patientId)}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {mockLocations[schedule.patientId]?.address}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{getVisitTypeName(schedule.visitType)}</Badge>
                    </TableCell>
                    <TableCell>
                      {schedule.estimatedTravelTime ? (
                        <div className="flex items-center text-sm">
                          <Clock className="mr-1 h-3 w-3 text-muted-foreground" />
                          <span>約{schedule.estimatedTravelTime}分</span>
                        </div>
                      ) : (
                        <div className="flex items-center text-sm">
                          <Clock className="mr-1 h-3 w-3 text-muted-foreground" />
                          <span>計算中...</span>
                        </div>
                      )}
                      {schedule.estimatedTravelDistance && (
                        <div className="text-xs text-muted-foreground">{schedule.estimatedTravelDistance}km</div>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <a
                        href={getNavigationUrl(fromLocationId, toLocationId)}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Button variant="outline" size="sm">
                          <Navigation className="mr-2 h-3 w-3" />
                          ナビ
                        </Button>
                      </a>
                    </TableCell>
                  </TableRow>
                )
              })}

              <TableRow>
                <TableCell>帰着</TableCell>
                <TableCell>-</TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <MapPin className="mr-2 h-4 w-4 text-primary" />
                    {mockLocations["office"].name}
                  </div>
                </TableCell>
                <TableCell>-</TableCell>
                <TableCell>
                  {optimizedRoute.schedules.length > 0 && (
                    <>
                      <div className="flex items-center text-sm">
                        <Clock className="mr-1 h-3 w-3 text-muted-foreground" />
                        <span>約30分</span>
                      </div>
                      <div className="text-xs text-muted-foreground">5.2km</div>
                    </>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  {optimizedRoute.schedules.length > 0 && (
                    <a
                      href={getNavigationUrl(
                        optimizedRoute.schedules[optimizedRoute.schedules.length - 1].patientId,
                        "office",
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm">
                        <Navigation className="mr-2 h-3 w-3" />
                        ナビ
                      </Button>
                    </a>
                  )}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>

        <div className="flex justify-between">
          <Button variant="outline" onClick={() => setActiveTab("current")}>
            <ArrowRight className="mr-2 h-4 w-4 rotate-180" />
            現在のルートに戻る
          </Button>
          <a href={getRouteUrl(optimizedRoute)} target="_blank" rel="noopener noreferrer">
            <Button variant="outline">
              <MapPin className="mr-2 h-4 w-4" />
              全体ルートを地図で見る
            </Button>
          </a>
        </div>
      </div>
    )
  }

  // ルート比較を表示
  const renderRouteComparison = () => {
    if (!route || !optimizedRoute) {
      return (
        <div className="text-center py-8">
          <p className="text-muted-foreground">比較するルートがありません</p>
        </div>
      )
    }

    // 最適化による改善を計算
    const distanceImprovement = Math.round((route.totalTravelDistance - optimizedRoute.totalTravelDistance) * 100) / 100
    const timeImprovement = route.totalTravelTime - optimizedRoute.totalTravelTime
    const improvementPercentage = Math.round((distanceImprovement / route.totalTravelDistance) * 100)

    return (
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-medium">ルート比較</h3>
          <p className="text-sm text-muted-foreground">現在のルートと最適化されたルートの比較</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">現在のルート</CardTitle>
              <CardDescription>
                総移動距離: {route.totalTravelDistance}km / 総移動時間: 約{route.totalTravelTime}分
              </CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="space-y-2">
                {route.schedules.map((schedule, index) => (
                  <div key={schedule.id} className="flex items-center">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center mr-2">
                      {index + 1}
                    </div>
                    <div className="truncate">{getPatientName(schedule.patientId)}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">最適化されたルート</CardTitle>
              <CardDescription>
                総移動距離: {optimizedRoute.totalTravelDistance}km / 総移動時間: 約{optimizedRoute.totalTravelTime}分
              </CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="space-y-2">
                {optimizedRoute.schedules.map((schedule, index) => (
                  <div key={schedule.id} className="flex items-center">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center mr-2">
                      {index + 1}
                    </div>
                    <div className="truncate">{getPatientName(schedule.patientId)}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">改善効果</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-md">
                <span className="text-sm text-muted-foreground">移動距離の短縮</span>
                <span className="text-2xl font-bold text-primary">{distanceImprovement}km</span>
                <span className="text-sm text-green-600">-{improvementPercentage}%</span>
              </div>
              <div className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-md">
                <span className="text-sm text-muted-foreground">移動時間の短縮</span>
                <span className="text-2xl font-bold text-primary">{timeImprovement}分</span>
                <span className="text-sm text-green-600">
                  -{Math.round((timeImprovement / route.totalTravelTime) * 100)}%
                </span>
              </div>
              <div className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-md">
                <span className="text-sm text-muted-foreground">訪問順序の変更</span>
                <span className="text-2xl font-bold text-primary">
                  {route.schedules.length -
                    optimizedRoute.schedules.filter((s, i) => s.id === route.schedules[i].id).length}
                  件
                </span>
                <span className="text-sm text-blue-600">
                  {Math.round(
                    ((route.schedules.length -
                      optimizedRoute.schedules.filter((s, i) => s.id === route.schedules[i].id).length) /
                      route.schedules.length) *
                      100,
                  )}
                  %の変更
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>ルート情報を読み込み中...</CardTitle>
        </CardHeader>
        <CardContent className="h-48 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <div>
            <CardTitle>ルート最適化</CardTitle>
            <CardDescription>
              {format(currentDate, "yyyy年M月d日(E)", { locale: ja })} - {getStaffName(selectedStaffId)}
            </CardDescription>
          </div>
          <div className="flex items-center space-x-2">
            <Select value={selectedStaffId} onValueChange={setSelectedStaffId}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="スタッフを選択" />
              </SelectTrigger>
              <SelectContent>
                {mockStaff.map((staff) => (
                  <SelectItem key={staff.id} value={staff.id}>
                    {staff.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="current">現在のルート</TabsTrigger>
            <TabsTrigger value="optimized">最適化ルート</TabsTrigger>
            <TabsTrigger value="comparison">比較</TabsTrigger>
          </TabsList>
          <TabsContent value="current">{renderCurrentRoute()}</TabsContent>
          <TabsContent value="optimized">{renderOptimizedRoute()}</TabsContent>
          <TabsContent value="comparison">{renderRouteComparison()}</TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
