"use client"

import { useState } from "react"
import { Line, Bar } from "react-chartjs-2"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  type ChartOptions,
} from "chart.js"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

// ChartJSの登録
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend)

interface AssessmentData {
  date: string
  value: number
}

interface AssessmentChartProps {
  title: string
  description?: string
  data: AssessmentData[]
  unit?: string
  normalRange?: { min: number; max: number }
  type?: "line" | "bar"
  color?: string
  timeRanges?: { value: string; label: string }[]
}

export function AssessmentChart({
  title,
  description,
  data,
  unit = "",
  normalRange,
  type = "line",
  color = "rgb(59, 130, 246)",
  timeRanges = [
    { value: "1w", label: "1週間" },
    { value: "1m", label: "1ヶ月" },
    { value: "3m", label: "3ヶ月" },
    { value: "6m", label: "6ヶ月" },
    { value: "1y", label: "1年" },
    { value: "all", label: "すべて" },
  ],
}: AssessmentChartProps) {
  const [timeRange, setTimeRange] = useState("1m")
  const [chartType, setChartType] = useState<"line" | "bar">(type)

  // 時間範囲でデータをフィルタリング
  const filteredData = (() => {
    if (timeRange === "all") return data

    const now = new Date()
    let startDate: Date

    switch (timeRange) {
      case "1w":
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
        break
      case "1m":
        startDate = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate())
        break
      case "3m":
        startDate = new Date(now.getFullYear(), now.getMonth() - 3, now.getDate())
        break
      case "6m":
        startDate = new Date(now.getFullYear(), now.getMonth() - 6, now.getDate())
        break
      case "1y":
        startDate = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate())
        break
      default:
        startDate = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate())
    }

    return data.filter((item) => new Date(item.date) >= startDate)
  })()

  // チャートデータの作成
  const chartData = {
    labels: filteredData.map((item) => {
      const date = new Date(item.date)
      return `${date.getMonth() + 1}/${date.getDate()}`
    }),
    datasets: [
      {
        label: title,
        data: filteredData.map((item) => item.value),
        borderColor: color,
        backgroundColor: `${color}33`, // 透明度を追加
        borderWidth: 2,
        pointBackgroundColor: color,
        pointRadius: 3,
        pointHoverRadius: 5,
        fill: false,
        tension: 0.1,
      },
    ],
  }

  // 正常範囲がある場合は追加
  if (normalRange) {
    if (chartType === "line") {
      chartData.datasets.push({
        label: "下限",
        data: Array(filteredData.length).fill(normalRange.min),
        borderColor: "rgba(156, 163, 175, 0.5)",
        borderWidth: 1,
        borderDash: [5, 5],
        pointRadius: 0,
        fill: false,
      })

      chartData.datasets.push({
        label: "上限",
        data: Array(filteredData.length).fill(normalRange.max),
        borderColor: "rgba(156, 163, 175, 0.5)",
        borderWidth: 1,
        borderDash: [5, 5],
        pointRadius: 0,
        fill: "+1",
        backgroundColor: "rgba(156, 163, 175, 0.1)",
      })
    }
  }

  // チャートオプション
  const options: ChartOptions<"line" | "bar"> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context) => {
            return `${context.dataset.label}: ${context.parsed.y}${unit}`
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: false,
        title: {
          display: !!unit,
          text: unit,
        },
        ticks: {
          callback: (value) => `${value}${unit}`,
        },
      },
    },
  }

  // 正常範囲がある場合はY軸の範囲を調整
  if (normalRange) {
    const minValue = Math.min(...filteredData.map((item) => item.value), normalRange.min)
    const maxValue = Math.max(...filteredData.map((item) => item.value), normalRange.max)
    const padding = (maxValue - minValue) * 0.1

    options.scales = {
      ...options.scales,
      y: {
        ...options.scales?.y,
        min: Math.max(0, minValue - padding),
        max: maxValue + padding,
      },
    }
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>{title}</CardTitle>
            {description && <CardDescription>{description}</CardDescription>}
          </div>
          <div className="flex items-center gap-2">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[100px]">
                <SelectValue placeholder="期間" />
              </SelectTrigger>
              <SelectContent>
                {timeRanges.map((range) => (
                  <SelectItem key={range.value} value={range.value}>
                    {range.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Tabs value={chartType} onValueChange={(value) => setChartType(value as "line" | "bar")}>
              <TabsList className="h-8">
                <TabsTrigger value="line" className="h-7 px-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M3 3v18h18" />
                    <path d="m19 9-5 5-4-4-3 3" />
                  </svg>
                </TabsTrigger>
                <TabsTrigger value="bar" className="h-7 px-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect width="6" height="16" x="4" y="5" rx="2" />
                    <rect width="6" height="10" x="14" y="11" rx="2" />
                  </svg>
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          {chartType === "line" ? (
            <Line data={chartData} options={options} />
          ) : (
            <Bar
              data={{
                ...chartData,
                datasets: [
                  {
                    ...chartData.datasets[0],
                    backgroundColor: color,
                  },
                ],
              }}
              options={options}
            />
          )}
        </div>
      </CardContent>
    </Card>
  )
}
