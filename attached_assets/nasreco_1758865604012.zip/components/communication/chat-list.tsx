"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Search, Plus, Settings, MessageSquare, Users, Building } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/lib/auth/auth-context"
import type { ChatRoom, ChatType } from "@/lib/db/communication-schema"

// モックデータ
const mockChatRooms: ChatRoom[] = [
  {
    id: "chat-1",
    name: "チーム会議",
    type: "internal",
    createdAt: new Date("2025-03-25"),
    updatedAt: new Date("2025-03-28"),
    participants: ["user-1", "user-2", "user-3"],
    isArchived: false,
  },
  {
    id: "chat-2",
    name: "佐藤家族",
    type: "external",
    createdAt: new Date("2025-03-26"),
    updatedAt: new Date("2025-03-27"),
    participants: ["user-2"],
    isArchived: false,
    metadata: { lineGroupId: "line-123" },
  },
  {
    id: "chat-3",
    name: "田中医師連携",
    type: "multidisciplinary",
    createdAt: new Date("2025-03-20"),
    updatedAt: new Date("2025-03-26"),
    participants: ["user-1", "user-2"],
    isArchived: false,
    metadata: { mcsGroupId: "mcs-456" },
  },
]

// 最終メッセージのモックデータ
const mockLastMessages: Record<string, { text: string; time: string; unread: number }> = {
  "chat-1": { text: "明日の訪問予定を確認しました", time: "14:30", unread: 0 },
  "chat-2": { text: "本日の訪問ありがとうございました", time: "昨日", unread: 2 },
  "chat-3": { text: "次回の処方について相談があります", time: "3/26", unread: 1 },
}

export function ChatList() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState<ChatType | "all">("all")
  const router = useRouter()
  const { user } = useAuth()

  const filteredRooms = mockChatRooms
    .filter((room) => {
      // タブによるフィルタリング
      if (activeTab !== "all" && room.type !== activeTab) return false

      // 検索クエリによるフィルタリング
      if (searchQuery && !room.name.toLowerCase().includes(searchQuery.toLowerCase())) return false

      return true
    })
    .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime())

  const handleChatSelect = (chatId: string) => {
    router.push(`/communication/chat/${chatId}`)
  }

  const getChatIcon = (type: ChatType) => {
    switch (type) {
      case "internal":
        return <Users className="h-4 w-4" />
      case "external":
        return <MessageSquare className="h-4 w-4" />
      case "multidisciplinary":
        return <Building className="h-4 w-4" />
    }
  }

  return (
    <div className="flex h-full flex-col border-r">
      <div className="p-4 border-b">
        <h2 className="text-xl font-bold mb-4">メッセージ</h2>
        <div className="flex items-center space-x-2">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="検索..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button size="icon" variant="outline">
            <Plus className="h-4 w-4" />
          </Button>
          <Button size="icon" variant="outline">
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="flex-1 flex flex-col" onValueChange={(value) => setActiveTab(value as any)}>
        <TabsList className="mx-4 mt-2">
          <TabsTrigger value="all" className="flex-1">
            すべて
          </TabsTrigger>
          <TabsTrigger value="internal" className="flex-1">
            社内
          </TabsTrigger>
          <TabsTrigger value="external" className="flex-1">
            利用者
          </TabsTrigger>
          <TabsTrigger value="multidisciplinary" className="flex-1">
            多職種
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="flex-1 mt-0">
          <ScrollArea className="h-[calc(100vh-13rem)]">
            <div className="space-y-1 p-2">
              {filteredRooms.length > 0 ? (
                filteredRooms.map((room) => (
                  <button
                    key={room.id}
                    className="w-full flex items-start space-x-3 p-3 rounded-md hover:bg-accent text-left transition-colors"
                    onClick={() => handleChatSelect(room.id)}
                  >
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={`/placeholder-text.png?text=${room.name.charAt(0)}`} />
                      <AvatarFallback>{room.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span className="font-medium truncate">{room.name}</span>
                          <Badge variant="outline" className="h-5 flex items-center space-x-1">
                            {getChatIcon(room.type)}
                            <span className="text-xs">
                              {room.type === "internal" ? "社内" : room.type === "external" ? "利用者" : "多職種"}
                            </span>
                          </Badge>
                        </div>
                        <span className="text-xs text-muted-foreground">{mockLastMessages[room.id]?.time}</span>
                      </div>
                      <div className="flex items-center justify-between mt-1">
                        <p className="text-sm text-muted-foreground truncate">{mockLastMessages[room.id]?.text}</p>
                        {mockLastMessages[room.id]?.unread > 0 && (
                          <Badge className="ml-2 h-5 w-5 flex items-center justify-center rounded-full p-0">
                            {mockLastMessages[room.id].unread}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </button>
                ))
              ) : (
                <div className="p-4 text-center text-muted-foreground">該当するチャットがありません</div>
              )}
            </div>
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  )
}
