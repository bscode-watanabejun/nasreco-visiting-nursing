"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import type { AutoResponseSetting } from "@/lib/db/communication-schema"
import { Loader2 } from "lucide-react"

interface AutoResponseSettingsProps {
  roomId: string
  initialSettings?: AutoResponseSetting
}

export function AutoResponseSettings({ roomId, initialSettings }: AutoResponseSettingsProps) {
  const [settings, setSettings] = useState<AutoResponseSetting>(
    initialSettings || {
      roomId,
      isEnabled: false,
      message: "現在営業時間外です。緊急の場合は電話にてご連絡ください。",
      scheduleType: "outside_hours",
      startTime: "17:00",
      endTime: "09:00",
      daysOfWeek: [0, 6], // 日曜と土曜
    },
  )
  const [isSaving, setIsSaving] = useState(false)

  const handleSave = async () => {
    setIsSaving(true)
    // ここでAPIに保存する処理を実装
    await new Promise((resolve) => setTimeout(resolve, 1000)) // 保存処理のシミュレーション
    setIsSaving(false)
  }

  const daysOfWeek = [
    { id: 0, label: "日" },
    { id: 1, label: "月" },
    { id: 2, label: "火" },
    { id: 3, label: "水" },
    { id: 4, label: "木" },
    { id: 5, label: "金" },
    { id: 6, label: "土" },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>自動応答設定</CardTitle>
        <CardDescription>不在時や営業時間外の自動応答メッセージを設定します。</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <Label htmlFor="auto-response-enabled">自動応答を有効にする</Label>
          <Switch
            id="auto-response-enabled"
            checked={settings.isEnabled}
            onCheckedChange={(checked) => setSettings({ ...settings, isEnabled: checked })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="auto-response-message">自動応答メッセージ</Label>
          <Textarea
            id="auto-response-message"
            placeholder="自動応答メッセージを入力してください"
            value={settings.message}
            onChange={(e) => setSettings({ ...settings, message: e.target.value })}
            rows={3}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="schedule-type">応答スケジュール</Label>
          <Select
            value={settings.scheduleType}
            onValueChange={(value) => setSettings({ ...settings, scheduleType: value as any })}
          >
            <SelectTrigger id="schedule-type">
              <SelectValue placeholder="スケジュールタイプを選択" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="always">常に有効</SelectItem>
              <SelectItem value="outside_hours">営業時間外のみ</SelectItem>
              <SelectItem value="custom">カスタム設定</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {(settings.scheduleType === "outside_hours" || settings.scheduleType === "custom") && (
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="start-time">開始時間</Label>
              <Input
                id="start-time"
                type="time"
                value={settings.startTime}
                onChange={(e) => setSettings({ ...settings, startTime: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="end-time">終了時間</Label>
              <Input
                id="end-time"
                type="time"
                value={settings.endTime}
                onChange={(e) => setSettings({ ...settings, endTime: e.target.value })}
              />
            </div>
          </div>
        )}

        {settings.scheduleType === "custom" && (
          <div className="space-y-2">
            <Label>適用する曜日</Label>
            <div className="flex flex-wrap gap-4 mt-2">
              {daysOfWeek.map((day) => (
                <div key={day.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={`day-${day.id}`}
                    checked={settings.daysOfWeek?.includes(day.id)}
                    onCheckedChange={(checked) => {
                      const newDays = settings.daysOfWeek?.filter((d) => d !== day.id) || []
                      if (checked) {
                        newDays.push(day.id)
                      }
                      setSettings({ ...settings, daysOfWeek: newDays })
                    }}
                  />
                  <Label htmlFor={`day-${day.id}`}>{day.label}</Label>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="forward-to-user">緊急時の転送先</Label>
          <Select
            value={settings.forwardToUserId || ""}
            onValueChange={(value) => setSettings({ ...settings, forwardToUserId: value || undefined })}
          >
            <SelectTrigger id="forward-to-user">
              <SelectValue placeholder="転送先を選択（任意）" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">転送しない</SelectItem>
              <SelectItem value="user-1">管理者 太郎</SelectItem>
              <SelectItem value="user-2">山田 花子（オンコール担当）</SelectItem>
              <SelectItem value="user-3">鈴木 一郎</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-sm text-muted-foreground mt-1">
            緊急メッセージを特定のスタッフに転送する場合に設定します。
          </p>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSave} disabled={isSaving} className="ml-auto">
          {isSaving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              保存中...
            </>
          ) : (
            "設定を保存"
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
