"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Send, Paperclip, ImageIcon, MoreHorizontal, ArrowLeft, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useAuth } from "@/lib/auth/auth-context"
import type { Message, ChatRoom } from "@/lib/db/communication-schema"
import { formatDistanceToNow } from "date-fns"
import { ja } from "date-fns/locale"

interface ChatWindowProps {
  chatId: string
  onBack?: () => void
  isMobile?: boolean
}

// モックデータ
const mockChatRoom: ChatRoom = {
  id: "chat-1",
  name: "チーム会議",
  type: "internal",
  createdAt: new Date("2025-03-25"),
  updatedAt: new Date("2025-03-28"),
  participants: ["user-1", "user-2", "user-3"],
  isArchived: false,
}

const mockMessages: Message[] = [
  {
    id: "msg-1",
    roomId: "chat-1",
    senderId: "user-1",
    type: "text",
    content: "明日の訪問予定を確認しました。佐藤さんは10時、田中さんは14時です。",
    createdAt: new Date("2025-03-28T09:00:00"),
    status: "read",
    isDeleted: false,
  },
  {
    id: "msg-2",
    roomId: "chat-1",
    senderId: "user-2",
    type: "text",
    content: "了解しました。佐藤さんの血圧が高めだったので、明日も注意して測定します。",
    createdAt: new Date("2025-03-28T09:15:00"),
    status: "read",
    isDeleted: false,
  },
  {
    id: "msg-3",
    roomId: "chat-1",
    senderId: "user-3",
    type: "image",
    content: "佐藤さんの褥瘡の状態です。",
    attachmentUrl: "/generic-medical-scene.png",
    createdAt: new Date("2025-03-28T10:30:00"),
    status: "read",
    isDeleted: false,
  },
  {
    id: "msg-4",
    roomId: "chat-1",
    senderId: "user-1",
    type: "text",
    content: "ありがとうございます。前回より改善していますね。引き続き処置を継続しましょう。",
    createdAt: new Date("2025-03-28T10:45:00"),
    status: "read",
    isDeleted: false,
  },
]

const mockUsers = {
  "user-1": { name: "管理者 太郎", avatar: "/placeholder.svg?text=管" },
  "user-2": { name: "山田 花子", avatar: "/placeholder.svg?text=山" },
  "user-3": { name: "鈴木 一郎", avatar: "/placeholder.svg?text=鈴" },
}

export function ChatWindow({ chatId, onBack, isMobile = false }: ChatWindowProps) {
  const [newMessage, setNewMessage] = useState("")
  const [messages, setMessages] = useState<Message[]>(mockMessages)
  const [chatRoom, setChatRoom] = useState<ChatRoom | null>(mockChatRoom)
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const { user } = useAuth()

  // メッセージ送信処理
  const handleSendMessage = () => {
    if (!newMessage.trim() || !user) return

    const newMsg: Message = {
      id: `msg-${Date.now()}`,
      roomId: chatId,
      senderId: user.id,
      type: "text",
      content: newMessage,
      createdAt: new Date(),
      status: "sent",
      isDeleted: false,
    }

    setMessages([...messages, newMsg])
    setNewMessage("")
  }

  // Enter キーでメッセージ送信
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  // 新しいメッセージが追加されたらスクロールを一番下に移動
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // チャットルームとメッセージの読み込み（実際の実装ではAPIから取得）
  useEffect(() => {
    setIsLoading(true)
    // ここでAPIからデータを取得する処理を実装
    // 今回はモックデータを使用
    setTimeout(() => {
      setChatRoom(mockChatRoom)
      setMessages(mockMessages)
      setIsLoading(false)
    }, 500)
  }, [chatId])

  // メッセージの表示
  const renderMessage = (message: Message) => {
    const isSelf = message.senderId === user?.id
    const sender = mockUsers[message.senderId as keyof typeof mockUsers]
    const timeAgo = formatDistanceToNow(message.createdAt, { addSuffix: true, locale: ja })

    return (
      <div key={message.id} className={`flex ${isSelf ? "justify-end" : "justify-start"} mb-4`}>
        {!isSelf && (
          <Avatar className="h-8 w-8 mr-2">
            <AvatarImage src={sender?.avatar || "/placeholder.svg"} />
            <AvatarFallback>{sender?.name.charAt(0)}</AvatarFallback>
          </Avatar>
        )}
        <div className={`max-w-[70%] ${isSelf ? "order-1" : "order-2"}`}>
          {!isSelf && <div className="text-sm font-medium mb-1">{sender?.name}</div>}
          <div className="flex items-end gap-2">
            {isSelf && (
              <div className="text-xs text-muted-foreground self-end">
                {message.status === "sent" && "送信済み"}
                {message.status === "delivered" && "配信済み"}
                {message.status === "read" && "既読"}
              </div>
            )}
            <div className={`rounded-lg p-3 ${isSelf ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
              {message.type === "text" && <p>{message.content}</p>}
              {message.type === "image" && (
                <div>
                  <img
                    src={message.attachmentUrl || "/placeholder.svg"}
                    alt="添付画像"
                    className="rounded-md max-w-full"
                  />
                  <p className="mt-2">{message.content}</p>
                </div>
              )}
              {message.type === "video" && (
                <div>
                  <video src={message.attachmentUrl} controls className="rounded-md max-w-full" />
                  <p className="mt-2">{message.content}</p>
                </div>
              )}
            </div>
          </div>
          <div className="text-xs text-muted-foreground mt-1">{timeAgo}</div>
        </div>
      </div>
    )
  }

  if (!chatRoom) {
    return (
      <div className="flex items-center justify-center h-full">
        <p>チャットが見つかりません</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full">
      {/* ヘッダー */}
      <div className="p-4 border-b flex items-center justify-between">
        <div className="flex items-center">
          {isMobile && (
            <Button variant="ghost" size="icon" onClick={onBack} className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          )}
          <Avatar className="h-10 w-10 mr-3">
            <AvatarImage src={`/placeholder-text.png?text=${chatRoom.name.charAt(0)}`} />
            <AvatarFallback>{chatRoom.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div>
            <h3 className="font-medium">{chatRoom.name}</h3>
            <div className="flex items-center text-xs text-muted-foreground">
              <Badge variant="outline" className="h-5 mr-2">
                {chatRoom.type === "internal" ? "社内" : chatRoom.type === "external" ? "利用者" : "多職種"}
              </Badge>
              <span>{chatRoom.participants.length}人のメンバー</span>
            </div>
          </div>
        </div>
        <div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreHorizontal className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>メンバー管理</DropdownMenuItem>
              <DropdownMenuItem>通知設定</DropdownMenuItem>
              <DropdownMenuItem>自動応答設定</DropdownMenuItem>
              <DropdownMenuItem>チャット履歴のエクスポート</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* メッセージエリア */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map(renderMessage)}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      {/* 入力エリア */}
      <div className="p-4 border-t">
        <div className="flex items-end gap-2">
          <div className="flex-1">
            <Input
              placeholder="メッセージを入力..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyDown={handleKeyPress}
              className="min-h-[2.5rem]"
              multiline
            />
          </div>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon">
                  <Paperclip className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>ファイルを添付</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon">
                  <ImageIcon className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>画像を添付</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon">
                  <Clock className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>時間指定送信</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <Button onClick={handleSendMessage} disabled={!newMessage.trim()}>
            <Send className="h-4 w-4 mr-2" />
            送信
          </Button>
        </div>
      </div>
    </div>
  )
}
