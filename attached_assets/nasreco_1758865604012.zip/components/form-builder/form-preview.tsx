"use client"

import { useState } from "react"
import { ChevronDown, ChevronUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import type { FormTemplate, FormField, FormSection } from "@/lib/db/form-schema"

interface FormPreviewProps {
  template: FormTemplate
}

export function FormPreview({ template }: FormPreviewProps) {
  const [formData, setFormData] = useState<Record<string, any>>({})
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({})

  // セクションの折りたたみ状態を初期化
  useState(() => {
    const initialCollapsedState: Record<string, boolean> = {}
    template.sections.forEach((section) => {
      initialCollapsedState[section.id] = section.isCollapsed || false
    })
    setCollapsedSections(initialCollapsedState)
  })

  const toggleSection = (sectionId: string) => {
    setCollapsedSections({
      ...collapsedSections,
      [sectionId]: !collapsedSections[sectionId],
    })
  }

  const handleFieldChange = (fieldId: string, value: any) => {
    setFormData({
      ...formData,
      [fieldId]: value,
    })
  }

  const shouldShowField = (field: FormField): boolean => {
    if (field.isHidden) return false

    if (field.dependsOn) {
      const { field: dependsOnField, value: dependsOnValue } = field.dependsOn
      return formData[dependsOnField] === dependsOnValue
    }

    return true
  }

  const renderField = (field: FormField) => {
    if (!shouldShowField(field)) return null

    const fieldWidth = field.width || "full"
    const widthClass = {
      full: "col-span-12",
      half: "col-span-6",
      third: "col-span-4",
    }[fieldWidth]

    return (
      <div key={field.id} className={`${widthClass} space-y-2`}>
        <Label htmlFor={field.id}>
          {field.label}
          {field.isRequired && <span className="text-destructive ml-1">*</span>}
        </Label>

        {field.type === "text" && (
          <Input
            id={field.id}
            placeholder={field.placeholder}
            value={formData[field.id] || ""}
            onChange={(e) => handleFieldChange(field.id, e.target.value)}
            disabled={field.isReadOnly}
          />
        )}

        {field.type === "textarea" && (
          <Textarea
            id={field.id}
            placeholder={field.placeholder}
            value={formData[field.id] || ""}
            onChange={(e) => handleFieldChange(field.id, e.target.value)}
            disabled={field.isReadOnly}
            rows={4}
          />
        )}

        {field.type === "number" && (
          <Input
            id={field.id}
            type="number"
            placeholder={field.placeholder}
            value={formData[field.id] || ""}
            onChange={(e) => handleFieldChange(field.id, e.target.value)}
            disabled={field.isReadOnly}
          />
        )}

        {field.type === "select" && (
          <Select
            value={formData[field.id] || ""}
            onValueChange={(value) => handleFieldChange(field.id, value)}
            disabled={field.isReadOnly}
          >
            <SelectTrigger id={field.id}>
              <SelectValue placeholder={field.placeholder} />
            </SelectTrigger>
            <SelectContent>
              {(field.options || []).map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        {field.type === "checkbox" && (
          <div className="space-y-2">
            {(field.options || []).map((option) => {
              const checkboxId = `${field.id}-${option.value}`
              return (
                <div key={option.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={checkboxId}
                    checked={(formData[field.id] || []).includes(option.value)}
                    onCheckedChange={(checked) => {
                      const currentValues = formData[field.id] || []
                      const newValues = checked
                        ? [...currentValues, option.value]
                        : currentValues.filter((v: string) => v !== option.value)
                      handleFieldChange(field.id, newValues)
                    }}
                    disabled={field.isReadOnly}
                  />
                  <Label htmlFor={checkboxId}>{option.label}</Label>
                </div>
              )
            })}
          </div>
        )}

        {field.type === "radio" && (
          <RadioGroup
            value={formData[field.id] || ""}
            onValueChange={(value) => handleFieldChange(field.id, value)}
            disabled={field.isReadOnly}
          >
            {(field.options || []).map((option) => {
              const radioId = `${field.id}-${option.value}`
              return (
                <div key={option.value} className="flex items-center space-x-2">
                  <RadioGroupItem value={option.value} id={radioId} />
                  <Label htmlFor={radioId}>{option.label}</Label>
                </div>
              )
            })}
          </RadioGroup>
        )}

        {field.type === "date" && (
          <Input
            id={field.id}
            type="date"
            value={formData[field.id] || ""}
            onChange={(e) => handleFieldChange(field.id, e.target.value)}
            disabled={field.isReadOnly}
          />
        )}

        {field.type === "time" && (
          <Input
            id={field.id}
            type="time"
            value={formData[field.id] || ""}
            onChange={(e) => handleFieldChange(field.id, e.target.value)}
            disabled={field.isReadOnly}
          />
        )}

        {field.type === "scale" && (
          <div className="pt-4 pb-2">
            <Slider
              id={field.id}
              min={(field.metadata?.min as number) || 0}
              max={(field.metadata?.max as number) || 10}
              step={(field.metadata?.step as number) || 1}
              value={[formData[field.id] || (field.metadata?.min as number) || 0]}
              onValueChange={(value) => handleFieldChange(field.id, value[0])}
              disabled={field.isReadOnly}
            />
            <div className="flex justify-between mt-1 text-xs text-muted-foreground">
              <span>{field.metadata?.min || 0}</span>
              <span>{formData[field.id] || (field.metadata?.min as number) || 0}</span>
              <span>{field.metadata?.max || 10}</span>
            </div>
          </div>
        )}

        {field.type === "media" && (
          <div className="space-y-2">
            <div className="flex items-center justify-center w-full h-32 px-4 transition bg-muted border-2 border-dashed rounded-md appearance-none cursor-pointer hover:border-primary focus:outline-none">
              <span className="flex flex-col items-center space-y-2">
                <span className="font-medium text-muted-foreground">
                  ファイルをドロップするか、クリックしてアップロード
                </span>
                <span className="text-xs text-muted-foreground">画像または動画ファイル</span>
              </span>
            </div>
          </div>
        )}

        {field.type === "signature" && (
          <div className="h-40 border rounded-md bg-muted flex items-center justify-center">
            <span className="text-muted-foreground">ここに署名</span>
          </div>
        )}

        {field.helpText && <p className="text-xs text-muted-foreground">{field.helpText}</p>}
      </div>
    )
  }

  const renderSection = (section: FormSection) => {
    const isCollapsed = collapsedSections[section.id]

    return (
      <Card key={section.id} className="mb-4">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle>{section.title}</CardTitle>
            {section.isCollapsible && (
              <Button variant="ghost" size="icon" onClick={() => toggleSection(section.id)}>
                {isCollapsed ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
              </Button>
            )}
          </div>
          {section.description && <CardDescription>{section.description}</CardDescription>}
        </CardHeader>
        {!isCollapsed && (
          <CardContent>
            <div className="grid grid-cols-12 gap-4">{section.fields.map(renderField)}</div>
          </CardContent>
        )}
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>{template.name}</CardTitle>
          {template.description && <CardDescription>{template.description}</CardDescription>}
        </CardHeader>
        <CardContent>{template.sections.map(renderSection)}</CardContent>
        <CardFooter className="flex justify-end gap-2">
          <Button variant="outline">下書き保存</Button>
          <Button>送信</Button>
        </CardFooter>
      </Card>
    </div>
  )
}
