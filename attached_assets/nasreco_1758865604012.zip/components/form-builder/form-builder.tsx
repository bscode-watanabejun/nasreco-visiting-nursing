"use client"

import { useState } from "react"
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd"
import { Plus, Trash2, Copy, Settings, ChevronDown, ChevronUp, GripVertical } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { FormTemplate, FormSection, FormField, FieldType } from "@/lib/db/form-schema"
import { FieldSettings } from "./field-settings"
import { SectionSettings } from "./section-settings"
import { FormPreview } from "./form-preview"

interface FormBuilderProps {
  initialTemplate?: FormTemplate
  onSave: (template: FormTemplate) => void
}

const DEFAULT_SECTION: Omit<FormSection, "id"> = {
  title: "新しいセクション",
  description: "",
  fields: [],
  isCollapsible: true,
  isCollapsed: false,
  order: 0,
}

const DEFAULT_FIELD: Omit<FormField, "id" | "type" | "label"> = {
  placeholder: "",
  helpText: "",
  isRequired: false,
  isHidden: false,
  width: "full",
}

export function FormBuilder({ initialTemplate, onSave }: FormBuilderProps) {
  const [template, setTemplate] = useState<FormTemplate>(
    initialTemplate || {
      id: `template-${Date.now()}`,
      name: "新しいフォームテンプレート",
      description: "",
      type: "visit",
      sections: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      createdBy: "", // 実際の実装ではユーザーIDを設定
      isActive: true,
      tenantId: "", // 実際の実装ではテナントIDを設定
      version: 1,
    },
  )
  const [activeTab, setActiveTab] = useState<"editor" | "preview">("editor")
  const [selectedSectionId, setSelectedSectionId] = useState<string | null>(null)
  const [selectedFieldId, setSelectedFieldId] = useState<string | null>(null)
  const [showSectionSettings, setShowSectionSettings] = useState(false)
  const [showFieldSettings, setShowFieldSettings] = useState(false)

  // テンプレート基本情報の更新
  const updateTemplateInfo = (key: keyof FormTemplate, value: any) => {
    setTemplate({
      ...template,
      [key]: value,
      updatedAt: new Date(),
    })
  }

  // セクションの追加
  const addSection = () => {
    const newSection: FormSection = {
      ...DEFAULT_SECTION,
      id: `section-${Date.now()}`,
      order: template.sections.length,
      fields: [],
    }

    setTemplate({
      ...template,
      sections: [...template.sections, newSection],
      updatedAt: new Date(),
    })

    setSelectedSectionId(newSection.id)
    setSelectedFieldId(null)
    setShowSectionSettings(true)
    setShowFieldSettings(false)
  }

  // セクションの更新
  const updateSection = (sectionId: string, updates: Partial<FormSection>) => {
    setTemplate({
      ...template,
      sections: template.sections.map((section) => (section.id === sectionId ? { ...section, ...updates } : section)),
      updatedAt: new Date(),
    })
  }

  // セクションの削除
  const deleteSection = (sectionId: string) => {
    setTemplate({
      ...template,
      sections: template.sections.filter((section) => section.id !== sectionId),
      updatedAt: new Date(),
    })

    if (selectedSectionId === sectionId) {
      setSelectedSectionId(null)
      setShowSectionSettings(false)
    }
  }

  // セクションの複製
  const duplicateSection = (sectionId: string) => {
    const sectionToDuplicate = template.sections.find((section) => section.id === sectionId)

    if (sectionToDuplicate) {
      const newSection: FormSection = {
        ...sectionToDuplicate,
        id: `section-${Date.now()}`,
        title: `${sectionToDuplicate.title} (コピー)`,
        order: template.sections.length,
        fields: sectionToDuplicate.fields.map((field) => ({
          ...field,
          id: `field-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        })),
      }

      setTemplate({
        ...template,
        sections: [...template.sections, newSection],
        updatedAt: new Date(),
      })
    }
  }

  // フィールドの追加
  const addField = (sectionId: string, type: FieldType) => {
    const newField: FormField = {
      ...DEFAULT_FIELD,
      id: `field-${Date.now()}`,
      type,
      label: getDefaultLabelForType(type),
    }

    setTemplate({
      ...template,
      sections: template.sections.map((section) => {
        if (section.id === sectionId) {
          return {
            ...section,
            fields: [...section.fields, newField],
          }
        }
        return section
      }),
      updatedAt: new Date(),
    })

    setSelectedSectionId(sectionId)
    setSelectedFieldId(newField.id)
    setShowFieldSettings(true)
    setShowSectionSettings(false)
  }

  // フィールドの更新
  const updateField = (sectionId: string, fieldId: string, updates: Partial<FormField>) => {
    setTemplate({
      ...template,
      sections: template.sections.map((section) => {
        if (section.id === sectionId) {
          return {
            ...section,
            fields: section.fields.map((field) => (field.id === fieldId ? { ...field, ...updates } : field)),
          }
        }
        return section
      }),
      updatedAt: new Date(),
    })
  }

  // フィールドの削除
  const deleteField = (sectionId: string, fieldId: string) => {
    setTemplate({
      ...template,
      sections: template.sections.map((section) => {
        if (section.id === sectionId) {
          return {
            ...section,
            fields: section.fields.filter((field) => field.id !== fieldId),
          }
        }
        return section
      }),
      updatedAt: new Date(),
    })

    if (selectedFieldId === fieldId) {
      setSelectedFieldId(null)
      setShowFieldSettings(false)
    }
  }

  // フィールドの複製
  const duplicateField = (sectionId: string, fieldId: string) => {
    const section = template.sections.find((s) => s.id === sectionId)
    const fieldToDuplicate = section?.fields.find((f) => f.id === fieldId)

    if (fieldToDuplicate) {
      const newField: FormField = {
        ...fieldToDuplicate,
        id: `field-${Date.now()}`,
        label: `${fieldToDuplicate.label} (コピー)`,
      }

      setTemplate({
        ...template,
        sections: template.sections.map((section) => {
          if (section.id === sectionId) {
            return {
              ...section,
              fields: [...section.fields, newField],
            }
          }
          return section
        }),
        updatedAt: new Date(),
      })
    }
  }

  // ドラッグ&ドロップの処理
  const handleDragEnd = (result: any) => {
    const { source, destination, type } = result

    // ドロップ先がない場合は何もしない
    if (!destination) return

    // 同じ位置にドロップした場合は何もしない
    if (source.droppableId === destination.droppableId && source.index === destination.index) return

    // セクションの並べ替え
    if (type === "section") {
      const newSections = Array.from(template.sections)
      const [movedSection] = newSections.splice(source.index, 1)
      newSections.splice(destination.index, 0, movedSection)

      // order を更新
      const updatedSections = newSections.map((section, index) => ({
        ...section,
        order: index,
      }))

      setTemplate({
        ...template,
        sections: updatedSections,
        updatedAt: new Date(),
      })
      return
    }

    // フィールドの並べ替え
    if (type === "field") {
      // 同じセクション内での並べ替え
      if (source.droppableId === destination.droppableId) {
        const sectionId = source.droppableId
        const section = template.sections.find((s) => s.id === sectionId)

        if (section) {
          const newFields = Array.from(section.fields)
          const [movedField] = newFields.splice(source.index, 1)
          newFields.splice(destination.index, 0, movedField)

          setTemplate({
            ...template,
            sections: template.sections.map((s) => (s.id === sectionId ? { ...s, fields: newFields } : s)),
            updatedAt: new Date(),
          })
        }
      }
      // 異なるセクション間での並べ替え
      else {
        const sourceSectionId = source.droppableId
        const destSectionId = destination.droppableId

        const sourceSection = template.sections.find((s) => s.id === sourceSectionId)
        const destSection = template.sections.find((s) => s.id === destSectionId)

        if (sourceSection && destSection) {
          const sourceFields = Array.from(sourceSection.fields)
          const destFields = Array.from(destSection.fields)

          const [movedField] = sourceFields.splice(source.index, 1)
          destFields.splice(destination.index, 0, movedField)

          setTemplate({
            ...template,
            sections: template.sections.map((s) => {
              if (s.id === sourceSectionId) {
                return { ...s, fields: sourceFields }
              }
              if (s.id === destSectionId) {
                return { ...s, fields: destFields }
              }
              return s
            }),
            updatedAt: new Date(),
          })
        }
      }
    }
  }

  // フィールドタイプに応じたデフォルトラベルを取得
  const getDefaultLabelForType = (type: FieldType): string => {
    switch (type) {
      case "text":
        return "テキスト"
      case "textarea":
        return "テキストエリア"
      case "number":
        return "数値"
      case "select":
        return "選択リスト"
      case "multiselect":
        return "複数選択"
      case "checkbox":
        return "チェックボックス"
      case "radio":
        return "ラジオボタン"
      case "date":
        return "日付"
      case "time":
        return "時間"
      case "scale":
        return "スケール"
      case "media":
        return "メディア"
      case "signature":
        return "署名"
      default:
        return "新しいフィールド"
    }
  }

  // テンプレートの保存
  const handleSave = () => {
    onSave(template)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">フォームビルダー</h1>
          <p className="text-muted-foreground">カスタムフォームテンプレートを作成・編集します</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setActiveTab(activeTab === "editor" ? "preview" : "editor")}>
            {activeTab === "editor" ? "プレビュー" : "エディター"}
          </Button>
          <Button onClick={handleSave}>保存</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>テンプレート情報</CardTitle>
              <CardDescription>フォームテンプレートの基本情報を設定します</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="template-name">テンプレート名</Label>
                <Input
                  id="template-name"
                  value={template.name}
                  onChange={(e) => updateTemplateInfo("name", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="template-description">説明</Label>
                <Textarea
                  id="template-description"
                  value={template.description || ""}
                  onChange={(e) => updateTemplateInfo("description", e.target.value)}
                  rows={2}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="template-type">テンプレートタイプ</Label>
                <Select value={template.type} onValueChange={(value) => updateTemplateInfo("type", value)}>
                  <SelectTrigger id="template-type">
                    <SelectValue placeholder="タイプを選択" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="visit">訪問記録</SelectItem>
                    <SelectItem value="assessment">アセスメント</SelectItem>
                    <SelectItem value="plan">看護計画</SelectItem>
                    <SelectItem value="custom">カスタム</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="template-active"
                  checked={template.isActive}
                  onCheckedChange={(checked) => updateTemplateInfo("isActive", checked)}
                />
                <Label htmlFor="template-active">有効</Label>
              </div>
            </CardContent>
          </Card>

          <Tabs
            value={activeTab}
            onValueChange={(value) => setActiveTab(value as "editor" | "preview")}
            className="mt-6"
          >
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="editor">エディター</TabsTrigger>
              <TabsTrigger value="preview">プレビュー</TabsTrigger>
            </TabsList>
            <TabsContent value="editor" className="mt-4">
              <DragDropContext onDragEnd={handleDragEnd}>
                <Droppable droppableId="sections" type="section">
                  {(provided) => (
                    <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-4">
                      {template.sections.map((section, index) => (
                        <Draggable key={section.id} draggableId={section.id} index={index}>
                          {(provided) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              className={`border rounded-lg p-4 ${
                                selectedSectionId === section.id ? "border-primary" : "border-border"
                              }`}
                            >
                              <div className="flex items-center justify-between mb-4">
                                <div className="flex items-center gap-2">
                                  <div {...provided.dragHandleProps}>
                                    <GripVertical className="h-5 w-5 text-muted-foreground" />
                                  </div>
                                  <h3 className="font-medium">{section.title}</h3>
                                </div>
                                <div className="flex items-center gap-1">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => {
                                      setSelectedSectionId(section.id)
                                      setSelectedFieldId(null)
                                      setShowSectionSettings(true)
                                      setShowFieldSettings(false)
                                    }}
                                  >
                                    <Settings className="h-4 w-4" />
                                  </Button>
                                  <Button variant="ghost" size="icon" onClick={() => duplicateSection(section.id)}>
                                    <Copy className="h-4 w-4" />
                                  </Button>
                                  <Button variant="ghost" size="icon" onClick={() => deleteSection(section.id)}>
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => {
                                      updateSection(section.id, {
                                        isCollapsed: !section.isCollapsed,
                                      })
                                    }}
                                  >
                                    {section.isCollapsed ? (
                                      <ChevronDown className="h-4 w-4" />
                                    ) : (
                                      <ChevronUp className="h-4 w-4" />
                                    )}
                                  </Button>
                                </div>
                              </div>

                              {!section.isCollapsed && (
                                <>
                                  {section.description && (
                                    <p className="text-sm text-muted-foreground mb-4">{section.description}</p>
                                  )}

                                  <Droppable droppableId={section.id} type="field">
                                    {(provided) => (
                                      <div
                                        {...provided.droppableProps}
                                        ref={provided.innerRef}
                                        className="space-y-2 min-h-[50px]"
                                      >
                                        {section.fields.map((field, fieldIndex) => (
                                          <Draggable key={field.id} draggableId={field.id} index={fieldIndex}>
                                            {(provided) => (
                                              <div
                                                ref={provided.innerRef}
                                                {...provided.draggableProps}
                                                className={`border rounded p-3 bg-background ${
                                                  selectedFieldId === field.id ? "border-primary" : "border-border"
                                                }`}
                                              >
                                                <div className="flex items-center justify-between">
                                                  <div className="flex items-center gap-2">
                                                    <div {...provided.dragHandleProps}>
                                                      <GripVertical className="h-4 w-4 text-muted-foreground" />
                                                    </div>
                                                    <div>
                                                      <p className="font-medium">{field.label}</p>
                                                      <p className="text-xs text-muted-foreground">
                                                        {field.type}
                                                        {field.isRequired && " (必須)"}
                                                        {field.isHidden && " (非表示)"}
                                                      </p>
                                                    </div>
                                                  </div>
                                                  <div className="flex items-center gap-1">
                                                    <Button
                                                      variant="ghost"
                                                      size="icon"
                                                      onClick={() => {
                                                        setSelectedSectionId(section.id)
                                                        setSelectedFieldId(field.id)
                                                        setShowFieldSettings(true)
                                                        setShowSectionSettings(false)
                                                      }}
                                                    >
                                                      <Settings className="h-4 w-4" />
                                                    </Button>
                                                    <Button
                                                      variant="ghost"
                                                      size="icon"
                                                      onClick={() => duplicateField(section.id, field.id)}
                                                    >
                                                      <Copy className="h-4 w-4" />
                                                    </Button>
                                                    <Button
                                                      variant="ghost"
                                                      size="icon"
                                                      onClick={() => deleteField(section.id, field.id)}
                                                    >
                                                      <Trash2 className="h-4 w-4" />
                                                    </Button>
                                                  </div>
                                                </div>
                                              </div>
                                            )}
                                          </Draggable>
                                        ))}
                                        {provided.placeholder}
                                      </div>
                                    )}
                                  </Droppable>

                                  <div className="mt-4">
                                    <Select
                                      onValueChange={(value) => {
                                        if (value) {
                                          addField(section.id, value as FieldType)
                                        }
                                      }}
                                    >
                                      <SelectTrigger>
                                        <SelectValue placeholder="フィールドを追加" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="text">テキスト</SelectItem>
                                        <SelectItem value="textarea">テキストエリア</SelectItem>
                                        <SelectItem value="number">数値</SelectItem>
                                        <SelectItem value="select">選択リスト</SelectItem>
                                        <SelectItem value="multiselect">複数選択</SelectItem>
                                        <SelectItem value="checkbox">チェックボックス</SelectItem>
                                        <SelectItem value="radio">ラジオボタン</SelectItem>
                                        <SelectItem value="date">日付</SelectItem>
                                        <SelectItem value="time">時間</SelectItem>
                                        <SelectItem value="scale">スケール</SelectItem>
                                        <SelectItem value="media">メディア</SelectItem>
                                        <SelectItem value="signature">署名</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                </>
                              )}
                            </div>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              </DragDropContext>

              <Button onClick={addSection} className="mt-4">
                <Plus className="h-4 w-4 mr-2" />
                セクションを追加
              </Button>
            </TabsContent>
            <TabsContent value="preview" className="mt-4">
              <FormPreview template={template} />
            </TabsContent>
          </Tabs>
        </div>

        <div className="lg:col-span-1">
          {showSectionSettings && selectedSectionId && (
            <SectionSettings
              section={template.sections.find((s) => s.id === selectedSectionId)!}
              onUpdate={(updates) => updateSection(selectedSectionId, updates)}
            />
          )}

          {showFieldSettings && selectedSectionId && selectedFieldId && (
            <FieldSettings
              field={
                template.sections.find((s) => s.id === selectedSectionId)?.fields.find((f) => f.id === selectedFieldId)!
              }
              onUpdate={(updates) => updateField(selectedSectionId, selectedFieldId, updates)}
              allFields={template.sections.flatMap((s) => s.fields)}
            />
          )}

          {!showSectionSettings && !showFieldSettings && (
            <Card>
              <CardHeader>
                <CardTitle>設定</CardTitle>
                <CardDescription>セクションまたはフィールドを選択して設定を編集してください</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-center text-muted-foreground py-8">
                  左側のエディターからセクションまたはフィールドを選択すると、 ここに設定オプションが表示されます
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
