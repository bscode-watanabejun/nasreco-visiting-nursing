"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import type { FormSection } from "@/lib/db/form-schema"

interface SectionSettingsProps {
  section: FormSection
  onUpdate: (updates: Partial<FormSection>) => void
}

export function SectionSettings({ section, onUpdate }: SectionSettingsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>セクション設定</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="section-title">タイトル</Label>
          <Input id="section-title" value={section.title} onChange={(e) => onUpdate({ title: e.target.value })} />
        </div>

        <div className="space-y-2">
          <Label htmlFor="section-description">説明</Label>
          <Textarea
            id="section-description"
            value={section.description || ""}
            onChange={(e) => onUpdate({ description: e.target.value })}
            rows={3}
          />
        </div>

        <div className="flex items-center justify-between">
          <Label htmlFor="section-collapsible" className="cursor-pointer">
            折りたたみ可能
          </Label>
          <Switch
            id="section-collapsible"
            checked={section.isCollapsible || false}
            onCheckedChange={(checked) => onUpdate({ isCollapsible: checked })}
          />
        </div>

        {section.isCollapsible && (
          <div className="flex items-center justify-between">
            <Label htmlFor="section-collapsed" className="cursor-pointer">
              初期状態で折りたたむ
            </Label>
            <Switch
              id="section-collapsed"
              checked={section.isCollapsed || false}
              onCheckedChange={(checked) => onUpdate({ isCollapsed: checked })}
            />
          </div>
        )}
      </CardContent>
    </Card>
  )
}
