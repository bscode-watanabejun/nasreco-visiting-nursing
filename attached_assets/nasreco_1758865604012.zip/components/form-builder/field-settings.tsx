"use client"

import { useState } from "react"
import { Plus, Trash2 } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { FormField, ValidationRule } from "@/lib/db/form-schema"

interface FieldSettingsProps {
  field: FormField
  onUpdate: (updates: Partial<FormField>) => void
  allFields: FormField[]
}

export function FieldSettings({ field, onUpdate, allFields }: FieldSettingsProps) {
  const [showValidationOptions, setShowValidationOptions] = useState(false)

  const handleAddOption = () => {
    const options = field.options || []
    onUpdate({
      options: [...options, { label: `オプション ${options.length + 1}`, value: `option-${options.length + 1}` }],
    })
  }

  const handleUpdateOption = (index: number, key: "label" | "value", value: string) => {
    const options = [...(field.options || [])]
    options[index] = { ...options[index], [key]: value }
    onUpdate({ options })
  }

  const handleRemoveOption = (index: number) => {
    const options = [...(field.options || [])]
    options.splice(index, 1)
    onUpdate({ options })
  }

  const handleAddValidation = (type: ValidationRule["type"]) => {
    const validations = [...(field.validation || [])]
    const newRule: ValidationRule = {
      type,
      message: getDefaultMessageForValidationType(type),
    }

    if (type === "min" || type === "max") {
      newRule.value = type === "min" ? 1 : 100
    } else if (type === "pattern") {
      newRule.value = ".*"
    }

    onUpdate({ validation: [...validations, newRule] })
  }

  const handleUpdateValidation = (index: number, key: keyof ValidationRule, value: any) => {
    const validations = [...(field.validation || [])]
    validations[index] = { ...validations[index], [key]: value }
    onUpdate({ validation: validations })
  }

  const handleRemoveValidation = (index: number) => {
    const validations = [...(field.validation || [])]
    validations.splice(index, 1)
    onUpdate({ validation: validations })
  }

  const getDefaultMessageForValidationType = (type: ValidationRule["type"]): string => {
    switch (type) {
      case "required":
        return "この項目は必須です"
      case "min":
        return "最小値以上を入力してください"
      case "max":
        return "最大値以下を入力してください"
      case "pattern":
        return "正しい形式で入力してください"
      case "custom":
        return "入力値が無効です"
      default:
        return "入力値が無効です"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>フィールド設定</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="field-label">ラベル</Label>
          <Input id="field-label" value={field.label} onChange={(e) => onUpdate({ label: e.target.value })} />
        </div>

        <div className="space-y-2">
          <Label htmlFor="field-placeholder">プレースホルダー</Label>
          <Input
            id="field-placeholder"
            value={field.placeholder || ""}
            onChange={(e) => onUpdate({ placeholder: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="field-help-text">ヘルプテキスト</Label>
          <Textarea
            id="field-help-text"
            value={field.helpText || ""}
            onChange={(e) => onUpdate({ helpText: e.target.value })}
            rows={2}
          />
        </div>

        {(field.type === "select" ||
          field.type === "multiselect" ||
          field.type === "radio" ||
          field.type === "checkbox") && (
          <div className="space-y-2">
            <Label>選択肢</Label>
            <div className="space-y-2">
              {(field.options || []).map((option, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Input
                    value={option.label}
                    onChange={(e) => handleUpdateOption(index, "label", e.target.value)}
                    placeholder="ラベル"
                    className="flex-1"
                  />
                  <Input
                    value={option.value}
                    onChange={(e) => handleUpdateOption(index, "value", e.target.value)}
                    placeholder="値"
                    className="flex-1"
                  />
                  <Button variant="ghost" size="icon" onClick={() => handleRemoveOption(index)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Button variant="outline" size="sm" onClick={handleAddOption} className="w-full">
                <Plus className="h-4 w-4 mr-2" />
                選択肢を追加
              </Button>
            </div>
          </div>
        )}

        {field.type === "scale" && (
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="field-min">最小値</Label>
              <Input
                id="field-min"
                type="number"
                value={(field.metadata?.min as number) || 0}
                onChange={(e) =>
                  onUpdate({
                    metadata: { ...field.metadata, min: Number.parseInt(e.target.value) },
                  })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="field-max">最大値</Label>
              <Input
                id="field-max"
                type="number"
                value={(field.metadata?.max as number) || 10}
                onChange={(e) =>
                  onUpdate({
                    metadata: { ...field.metadata, max: Number.parseInt(e.target.value) },
                  })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="field-step">ステップ</Label>
              <Input
                id="field-step"
                type="number"
                value={(field.metadata?.step as number) || 1}
                onChange={(e) =>
                  onUpdate({
                    metadata: { ...field.metadata, step: Number.parseInt(e.target.value) },
                  })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="field-default">デフォルト値</Label>
              <Input
                id="field-default"
                type="number"
                value={(field.defaultValue as number) || 5}
                onChange={(e) =>
                  onUpdate({
                    defaultValue: Number.parseInt(e.target.value),
                  })
                }
              />
            </div>
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="field-width">幅</Label>
          <Select
            value={field.width || "full"}
            onValueChange={(value) => onUpdate({ width: value as "full" | "half" | "third" })}
          >
            <SelectTrigger id="field-width">
              <SelectValue placeholder="幅を選択" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="full">全幅</SelectItem>
              <SelectItem value="half">半分</SelectItem>
              <SelectItem value="third">1/3</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="field-mapping">標準項目マッピング</Label>
          <Input
            id="field-mapping"
            value={field.mappingKey || ""}
            onChange={(e) => onUpdate({ mappingKey: e.target.value })}
            placeholder="例: patient.bloodPressure"
          />
          <p className="text-xs text-muted-foreground">
            このフィールドを標準データモデルのどのフィールドにマッピングするかを指定します
          </p>
        </div>

        <div className="space-y-2">
          <Label>依存関係</Label>
          <Select
            value={field.dependsOn?.field || ""}
            onValueChange={(value) => {
              if (value) {
                onUpdate({
                  dependsOn: {
                    field: value,
                    value: field.dependsOn?.value || "",
                  },
                })
              } else {
                onUpdate({ dependsOn: undefined })
              }
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="依存するフィールドを選択" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">依存なし</SelectItem>
              {allFields
                .filter((f) => f.id !== field.id)
                .map((f) => (
                  <SelectItem key={f.id} value={f.id}>
                    {f.label}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
          {field.dependsOn?.field && (
            <Input
              value={field.dependsOn.value || ""}
              onChange={(e) =>
                onUpdate({
                  dependsOn: {
                    ...field.dependsOn,
                    value: e.target.value,
                  },
                })
              }
              placeholder="表示する条件の値"
              className="mt-2"
            />
          )}
          <p className="text-xs text-muted-foreground">このフィールドを表示する条件となる他のフィールドを指定します</p>
        </div>

        <div className="space-y-4 pt-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="field-required" className="cursor-pointer">
              必須項目
            </Label>
            <Switch
              id="field-required"
              checked={field.isRequired || false}
              onCheckedChange={(checked) => onUpdate({ isRequired: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="field-hidden" className="cursor-pointer">
              非表示
            </Label>
            <Switch
              id="field-hidden"
              checked={field.isHidden || false}
              onCheckedChange={(checked) => onUpdate({ isHidden: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="field-readonly" className="cursor-pointer">
              読み取り専用
            </Label>
            <Switch
              id="field-readonly"
              checked={field.isReadOnly || false}
              onCheckedChange={(checked) => onUpdate({ isReadOnly: checked })}
            />
          </div>
        </div>

        <div className="pt-2">
          <Button variant="outline" onClick={() => setShowValidationOptions(!showValidationOptions)} className="w-full">
            バリデーション設定 {showValidationOptions ? "▲" : "▼"}
          </Button>

          {showValidationOptions && (
            <div className="mt-4 space-y-4">
              <div className="space-y-2">
                <Label>バリデーションルール</Label>
                {(field.validation || []).map((rule, index) => (
                  <div key={index} className="flex items-start gap-2 mt-2">
                    <Select value={rule.type} onValueChange={(value) => handleUpdateValidation(index, "type", value)}>
                      <SelectTrigger className="w-[120px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="required">必須</SelectItem>
                        <SelectItem value="min">最小値</SelectItem>
                        <SelectItem value="max">最大値</SelectItem>
                        <SelectItem value="pattern">パターン</SelectItem>
                        <SelectItem value="custom">カスタム</SelectItem>
                      </SelectContent>
                    </Select>

                    {(rule.type === "min" || rule.type === "max") && (
                      <Input
                        type="number"
                        value={rule.value || ""}
                        onChange={(e) => handleUpdateValidation(index, "value", e.target.value)}
                        className="w-[100px]"
                      />
                    )}

                    {rule.type === "pattern" && (
                      <Input
                        value={rule.value || ""}
                        onChange={(e) => handleUpdateValidation(index, "value", e.target.value)}
                        placeholder="正規表現"
                        className="flex-1"
                      />
                    )}

                    <Input
                      value={rule.message}
                      onChange={(e) => handleUpdateValidation(index, "message", e.target.value)}
                      placeholder="エラーメッセージ"
                      className="flex-1"
                    />

                    <Button variant="ghost" size="icon" onClick={() => handleRemoveValidation(index)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}

                <div className="flex gap-2 mt-2">
                  <Button variant="outline" size="sm" onClick={() => handleAddValidation("required")}>
                    必須
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleAddValidation("min")}>
                    最小値
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleAddValidation("max")}>
                    最大値
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleAddValidation("pattern")}>
                    パターン
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
