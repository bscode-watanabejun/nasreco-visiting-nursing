"use client"

import type React from "react"

import { useState } from "react"
import { ChevronLeft, ChevronRight, X, Download, Maximize2, Minimize2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogTitle, DialogHeader, DialogFooter } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

export interface MediaItem {
  id: string
  url: string
  thumbnailUrl?: string
  type: "image" | "video" | "audio" | "document"
  filename: string
  filesize: number
  createdAt: Date
  metadata?: Record<string, any>
}

interface MediaGalleryProps {
  items: MediaItem[]
  onDelete?: (id: string) => void
  onDownload?: (item: MediaItem) => void
  readOnly?: boolean
  title?: string
  className?: string
}

export function MediaGallery({ items, onDelete, onDownload, readOnly = false, title, className }: MediaGalleryProps) {
  const [selectedItem, setSelectedItem] = useState<MediaItem | null>(null)
  const [fullscreen, setFullscreen] = useState(false)
  const [activeTab, setActiveTab] = useState<"all" | "images" | "videos" | "documents">("all")

  const filteredItems = items.filter((item) => {
    if (activeTab === "all") return true
    if (activeTab === "images") return item.type === "image"
    if (activeTab === "videos") return item.type === "video"
    if (activeTab === "documents") return item.type === "document" || item.type === "audio"
    return true
  })

  const handleDownload = (item: MediaItem) => {
    if (onDownload) {
      onDownload(item)
    } else {
      // デフォルトのダウンロード処理
      const link = document.createElement("a")
      link.href = item.url
      link.download = item.filename
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    }
  }

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  const getNextItem = (): MediaItem | null => {
    if (!selectedItem) return null
    const currentIndex = filteredItems.findIndex((item) => item.id === selectedItem.id)
    if (currentIndex === -1 || currentIndex === filteredItems.length - 1) return null
    return filteredItems[currentIndex + 1]
  }

  const getPrevItem = (): MediaItem | null => {
    if (!selectedItem) return null
    const currentIndex = filteredItems.findIndex((item) => item.id === selectedItem.id)
    if (currentIndex <= 0) return null
    return filteredItems[currentIndex - 1]
  }

  const handleNext = () => {
    const next = getNextItem()
    if (next) setSelectedItem(next)
  }

  const handlePrev = () => {
    const prev = getPrevItem()
    if (prev) setSelectedItem(prev)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowRight") handleNext()
    if (e.key === "ArrowLeft") handlePrev()
    if (e.key === "Escape") setSelectedItem(null)
  }

  return (
    <div className={cn("space-y-4", className)}>
      {title && <h3 className="text-lg font-medium">{title}</h3>}

      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
        <div className="flex justify-between items-center">
          <TabsList>
            <TabsTrigger value="all">すべて ({items.length})</TabsTrigger>
            <TabsTrigger value="images">画像 ({items.filter((item) => item.type === "image").length})</TabsTrigger>
            <TabsTrigger value="videos">動画 ({items.filter((item) => item.type === "video").length})</TabsTrigger>
            <TabsTrigger value="documents">
              書類 ({items.filter((item) => item.type === "document" || item.type === "audio").length})
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="all" className="mt-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="group relative border rounded-md overflow-hidden bg-muted/40 aspect-square cursor-pointer hover:opacity-90 transition-opacity"
                onClick={() => setSelectedItem(item)}
              >
                {item.type === "image" && (
                  <img src={item.thumbnailUrl || item.url} alt={item.filename} className="w-full h-full object-cover" />
                )}
                {item.type === "video" && (
                  <div className="w-full h-full flex items-center justify-center bg-black">
                    <video src={item.url} className="max-h-full max-w-full" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="rounded-full bg-black/60 p-3">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="24"
                          height="24"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="text-white"
                        >
                          <polygon points="5 3 19 12 5 21 5 3" />
                        </svg>
                      </div>
                    </div>
                  </div>
                )}
                {(item.type === "document" || item.type === "audio") && (
                  <div className="w-full h-full flex flex-col items-center justify-center p-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="40"
                      height="40"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mb-2"
                    >
                      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                      <polyline points="14 2 14 8 20 8" />
                    </svg>
                    <p className="text-xs text-center truncate w-full">{item.filename}</p>
                  </div>
                )}
                <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white p-1 text-xs truncate opacity-0 group-hover:opacity-100 transition-opacity">
                  {item.filename}
                </div>
              </div>
            ))}
          </div>
          {filteredItems.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">表示するメディアがありません</div>
          )}
        </TabsContent>

        <TabsContent value="images" className="mt-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="group relative border rounded-md overflow-hidden bg-muted/40 aspect-square cursor-pointer hover:opacity-90 transition-opacity"
                onClick={() => setSelectedItem(item)}
              >
                <img src={item.thumbnailUrl || item.url} alt={item.filename} className="w-full h-full object-cover" />
                <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white p-1 text-xs truncate opacity-0 group-hover:opacity-100 transition-opacity">
                  {item.filename}
                </div>
              </div>
            ))}
          </div>
          {filteredItems.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">表示する画像がありません</div>
          )}
        </TabsContent>

        <TabsContent value="videos" className="mt-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="group relative border rounded-md overflow-hidden bg-muted/40 aspect-square cursor-pointer hover:opacity-90 transition-opacity"
                onClick={() => setSelectedItem(item)}
              >
                <div className="w-full h-full flex items-center justify-center bg-black">
                  <video src={item.url} className="max-h-full max-w-full" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="rounded-full bg-black/60 p-3">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-white"
                      >
                        <polygon points="5 3 19 12 5 21 5 3" />
                      </svg>
                    </div>
                  </div>
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white p-1 text-xs truncate opacity-0 group-hover:opacity-100 transition-opacity">
                  {item.filename}
                </div>
              </div>
            ))}
          </div>
          {filteredItems.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">表示する動画がありません</div>
          )}
        </TabsContent>

        <TabsContent value="documents" className="mt-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="group relative border rounded-md overflow-hidden bg-muted/40 aspect-square cursor-pointer hover:opacity-90 transition-opacity"
                onClick={() => setSelectedItem(item)}
              >
                <div className="w-full h-full flex flex-col items-center justify-center p-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="40"
                    height="40"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="mb-2"
                  >
                    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                    <polyline points="14 2 14 8 20 8" />
                  </svg>
                  <p className="text-xs text-center truncate w-full">{item.filename}</p>
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white p-1 text-xs truncate opacity-0 group-hover:opacity-100 transition-opacity">
                  {item.filename}
                </div>
              </div>
            ))}
          </div>
          {filteredItems.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">表示する書類がありません</div>
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={!!selectedItem} onOpenChange={(open) => !open && setSelectedItem(null)}>
        <DialogContent
          className={cn("max-w-4xl p-0", fullscreen && "fixed inset-0 max-w-none w-screen h-screen rounded-none")}
          onKeyDown={handleKeyDown}
        >
          <DialogHeader className="p-4 flex flex-row items-center justify-between">
            <DialogTitle className="text-lg">{selectedItem?.filename}</DialogTitle>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={() => setFullscreen(!fullscreen)}>
                {fullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </Button>
              <Button variant="ghost" size="icon" onClick={() => setSelectedItem(null)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>

          <div
            className={cn(
              "relative flex items-center justify-center bg-black/5 p-4",
              fullscreen ? "flex-1 overflow-auto" : "min-h-[300px]",
            )}
          >
            {selectedItem?.type === "image" && (
              <img
                src={selectedItem.url || "/placeholder.svg"}
                alt={selectedItem.filename}
                className="max-h-full max-w-full object-contain"
              />
            )}
            {selectedItem?.type === "video" && (
              <video src={selectedItem.url} controls className="max-h-full max-w-full" autoPlay />
            )}
            {selectedItem?.type === "audio" && (
              <div className="w-full max-w-md">
                <audio src={selectedItem.url} controls className="w-full" autoPlay />
              </div>
            )}
            {selectedItem?.type === "document" && (
              <div className="flex flex-col items-center justify-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="64"
                  height="64"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mb-4"
                >
                  <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                  <polyline points="14 2 14 8 20 8" />
                </svg>
                <p className="text-center mb-4">{selectedItem.filename}</p>
                <Button onClick={() => handleDownload(selectedItem)}>
                  <Download className="mr-2 h-4 w-4" />
                  ダウンロード
                </Button>
              </div>
            )}

            {getPrevItem() && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/20 hover:bg-black/40 text-white rounded-full h-10 w-10"
                onClick={handlePrev}
              >
                <ChevronLeft className="h-6 w-6" />
              </Button>
            )}
            {getNextItem() && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/20 hover:bg-black/40 text-white rounded-full h-10 w-10"
                onClick={handleNext}
              >
                <ChevronRight className="h-6 w-6" />
              </Button>
            )}
          </div>

          <DialogFooter className="p-4 flex-row justify-between items-center">
            <div>
              <Badge variant="outline" className="mr-2">
                {selectedItem?.type === "image"
                  ? "画像"
                  : selectedItem?.type === "video"
                    ? "動画"
                    : selectedItem?.type === "audio"
                      ? "音声"
                      : "書類"}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {selectedItem && formatFileSize(selectedItem.filesize)}
              </span>
            </div>
            <div className="flex gap-2">
              {!readOnly && onDelete && selectedItem && (
                <Button
                  variant="destructive"
                  onClick={() => {
                    onDelete(selectedItem.id)
                    setSelectedItem(null)
                  }}
                >
                  削除
                </Button>
              )}
              {selectedItem && (
                <Button onClick={() => handleDownload(selectedItem)}>
                  <Download className="mr-2 h-4 w-4" />
                  ダウンロード
                </Button>
              )}
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
