"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Camera, Upload, X, ImageIcon, FileVideo, File, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface MediaUploaderProps {
  onUpload: (files: File[]) => void
  maxFiles?: number
  acceptedTypes?: string[]
  maxSizeMB?: number
  disabled?: boolean
}

export function MediaUploader({
  onUpload,
  maxFiles = 10,
  acceptedTypes = ["image/*", "video/*"],
  maxSizeMB = 50,
  disabled = false,
}: MediaUploaderProps) {
  const [dragActive, setDragActive] = useState(false)
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({})
  const [errors, setErrors] = useState<string[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)
  const cameraInputRef = useRef<HTMLInputElement>(null)

  const maxSizeBytes = maxSizeMB * 1024 * 1024

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const validateFiles = (files: File[]): { validFiles: File[]; errors: string[] } => {
    const validFiles: File[] = []
    const newErrors: string[] = []

    // 最大ファイル数のチェック
    if (selectedFiles.length + files.length > maxFiles) {
      newErrors.push(`アップロードできるファイルは最大${maxFiles}個までです`)
      return { validFiles, errors: newErrors }
    }

    for (const file of files) {
      // ファイルタイプのチェック
      const isValidType = acceptedTypes.some((type) => {
        if (type.endsWith("/*")) {
          const mainType = type.split("/")[0]
          return file.type.startsWith(`${mainType}/`)
        }
        return file.type === type
      })

      if (!isValidType) {
        newErrors.push(`${file.name}：サポートされていないファイル形式です`)
        continue
      }

      // ファイルサイズのチェック
      if (file.size > maxSizeBytes) {
        newErrors.push(`${file.name}：ファイルサイズが大きすぎます（最大${maxSizeMB}MB）`)
        continue
      }

      validFiles.push(file)
    }

    return { validFiles, errors: newErrors }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const filesArray = Array.from(e.dataTransfer.files)
      const { validFiles, errors } = validateFiles(filesArray)

      if (errors.length > 0) {
        setErrors(errors)
      }

      if (validFiles.length > 0) {
        handleFiles(validFiles)
      }
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const filesArray = Array.from(e.target.files)
      const { validFiles, errors } = validateFiles(filesArray)

      if (errors.length > 0) {
        setErrors(errors)
      }

      if (validFiles.length > 0) {
        handleFiles(validFiles)
      }
    }
  }

  const handleFiles = (files: File[]) => {
    setSelectedFiles((prev) => [...prev, ...files])

    // アップロード進捗のモック
    files.forEach((file) => {
      const fileId = `${file.name}-${Date.now()}`
      setUploadProgress((prev) => ({ ...prev, [fileId]: 0 }))

      // 進捗をシミュレート
      let progress = 0
      const interval = setInterval(() => {
        progress += Math.random() * 10
        if (progress >= 100) {
          progress = 100
          clearInterval(interval)

          // 実際の実装ではここでアップロード完了後の処理
          setTimeout(() => {
            onUpload(files)
          }, 500)
        }
        setUploadProgress((prev) => ({ ...prev, [fileId]: progress }))
      }, 200)
    })
  }

  const removeFile = (index: number) => {
    setSelectedFiles((prev) => {
      const newFiles = [...prev]
      newFiles.splice(index, 1)
      return newFiles
    })
  }

  const clearErrors = () => {
    setErrors([])
  }

  const getFileIcon = (file: File) => {
    if (file.type.startsWith("image/")) {
      return <ImageIcon className="h-5 w-5" />
    } else if (file.type.startsWith("video/")) {
      return <FileVideo className="h-5 w-5" />
    } else {
      return <File className="h-5 w-5" />
    }
  }

  const getFilePreview = (file: File) => {
    if (file.type.startsWith("image/")) {
      return URL.createObjectURL(file)
    }
    return null
  }

  return (
    <div className="space-y-4">
      <Tabs defaultValue="upload">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="upload">ファイルアップロード</TabsTrigger>
          <TabsTrigger value="camera">カメラ撮影</TabsTrigger>
        </TabsList>
        <TabsContent value="upload" className="pt-4">
          <div
            className={`border-2 border-dashed rounded-lg p-6 transition-colors ${
              dragActive ? "border-primary bg-primary/5" : "border-muted-foreground/25"
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <Upload className="h-10 w-10 text-muted-foreground" />
              <div>
                <p className="font-medium">ファイルをドラッグ＆ドロップ</p>
                <p className="text-sm text-muted-foreground">または</p>
              </div>
              <Button
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                disabled={disabled || selectedFiles.length >= maxFiles}
              >
                ファイルを選択
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept={acceptedTypes.join(",")}
                onChange={handleFileChange}
                className="hidden"
                disabled={disabled || selectedFiles.length >= maxFiles}
              />
              <p className="text-xs text-muted-foreground">
                {acceptedTypes.join(", ")} • 最大{maxSizeMB}MB • 最大{maxFiles}ファイル
              </p>
            </div>
          </div>
        </TabsContent>
        <TabsContent value="camera" className="pt-4">
          <div className="border-2 border-dashed rounded-lg p-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <Camera className="h-10 w-10 text-muted-foreground" />
              <div>
                <p className="font-medium">カメラで撮影</p>
                <p className="text-sm text-muted-foreground">写真または動画を撮影してアップロード</p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    if (cameraInputRef.current) {
                      cameraInputRef.current.accept = "image/*"
                      cameraInputRef.current.click()
                    }
                  }}
                  disabled={disabled || selectedFiles.length >= maxFiles}
                >
                  写真を撮影
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    if (cameraInputRef.current) {
                      cameraInputRef.current.accept = "video/*"
                      cameraInputRef.current.click()
                    }
                  }}
                  disabled={disabled || selectedFiles.length >= maxFiles}
                >
                  動画を撮影
                </Button>
              </div>
              <input
                ref={cameraInputRef}
                type="file"
                capture="environment"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
                disabled={disabled || selectedFiles.length >= maxFiles}
              />
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {errors.length > 0 && (
        <div className="bg-destructive/10 border border-destructive rounded-md p-3">
          <div className="flex items-start">
            <div className="flex-1">
              <p className="font-medium text-destructive">エラーが発生しました</p>
              <ul className="list-disc list-inside text-sm text-destructive space-y-1 mt-1">
                {errors.map((error, index) => (
                  <li key={index}>{error}</li>
                ))}
              </ul>
            </div>
            <Button variant="ghost" size="icon" onClick={clearErrors} className="h-6 w-6">
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {selectedFiles.length > 0 && (
        <div className="space-y-2">
          <p className="text-sm font-medium">
            選択されたファイル ({selectedFiles.length}/{maxFiles})
          </p>
          <div className="space-y-2">
            {selectedFiles.map((file, index) => {
              const fileId = `${file.name}-${Date.now()}`
              const progress = uploadProgress[fileId] || 0
              const isComplete = progress === 100
              const preview = getFilePreview(file)

              return (
                <div key={index} className="flex items-center gap-2 p-2 border rounded-md bg-background">
                  <div className="flex-shrink-0 h-10 w-10 rounded-md overflow-hidden bg-muted flex items-center justify-center">
                    {preview ? (
                      <img src={preview || "/placeholder.svg"} alt={file.name} className="h-full w-full object-cover" />
                    ) : (
                      getFileIcon(file)
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{file.name}</p>
                    <div className="flex items-center gap-2">
                      <Progress value={progress} className="h-1 flex-1" />
                      <span className="text-xs text-muted-foreground whitespace-nowrap">
                        {isComplete ? (
                          <span className="text-green-600 flex items-center">
                            <Check className="h-3 w-3 mr-1" />
                            完了
                          </span>
                        ) : (
                          `${Math.round(progress)}%`
                        )}
                      </span>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeFile(index)}
                    className="h-8 w-8 flex-shrink-0"
                    disabled={disabled}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
