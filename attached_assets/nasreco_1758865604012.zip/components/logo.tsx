import Link from "next/link"
import { Heart } from "lucide-react"

interface LogoProps {
  variant?: "default" | "icon"
  size?: "sm" | "md" | "lg"
}

export function Logo({ variant = "default", size = "md" }: LogoProps) {
  const sizeClasses = {
    sm: "h-8",
    md: "h-10",
    lg: "h-12",
  }

  if (variant === "icon") {
    return (
      <div className="flex items-center justify-center">
        <div className={`${sizeClasses[size]} aspect-square flex items-center justify-center rounded-full bg-primary`}>
          <Heart
            className={`${size === "sm" ? "h-4 w-4" : size === "md" ? "h-5 w-5" : "h-6 w-6"} text-primary-foreground`}
          />
        </div>
      </div>
    )
  }

  return (
    <Link href="/" className="flex items-center gap-2">
      <div className={`${sizeClasses[size]} aspect-square flex items-center justify-center rounded-full bg-primary`}>
        <Heart
          className={`${size === "sm" ? "h-4 w-4" : size === "md" ? "h-5 w-5" : "h-6 w-6"} text-primary-foreground`}
        />
      </div>
      <span className={`font-bold ${size === "sm" ? "text-xl" : size === "md" ? "text-2xl" : "text-3xl"}`}>
        NASRECO
      </span>
    </Link>
  )
}
