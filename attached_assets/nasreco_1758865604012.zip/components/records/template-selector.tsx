"use client"

import { useState } from "react"
import { Search, Plus, Clock, Star, Users, Settings } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { RecordTemplate, RecordType } from "@/lib/db/record-schema"

// モックデータ
const mockTemplates: RecordTemplate[] = [
  {
    id: "template-1",
    name: "訪問看護基本テンプレート",
    description: "一般的な訪問看護記録用のテンプレート",
    type: "system",
    createdById: "system",
    createdAt: new Date("2025-01-01"),
    updatedAt: new Date("2025-01-01"),
    recordType: "visit",
    content: {
      subjective: "本日の体調：\n気になる症状：\n睡眠状態：\n食事摂取状況：",
      objective: "バイタルサイン：\n全身状態：\n処置部位の状態：",
      assessment: "問題点：\n改善点：\n継続観察が必要な点：",
      plan: "次回の訪問予定：\n実施予定の処置：\n指導内容：",
    },
    tags: ["基本", "訪問看護"],
    isDefault: true,
    isDeleted: false,
  },
  {
    id: "template-2",
    name: "糖尿病患者訪問テンプレート",
    description: "糖尿病患者の訪問看護記録用",
    type: "team",
    createdById: "user-1",
    createdAt: new Date("2025-02-01"),
    updatedAt: new Date("2025-02-01"),
    recordType: "visit",
    content: {
      subjective: "自覚症状：\n低血糖症状の有無：\n食事摂取状況：\n運動状況：",
      objective: "血糖値：\nHbA1c：\n体重：\n足部の状態：\nインスリン注射部位：",
      assessment: "血糖コントロール状態：\n合併症リスク評価：\n自己管理能力：",
      plan: "食事指導内容：\n運動指導内容：\n次回検査予定：",
    },
    tags: ["糖尿病", "慢性疾患"],
    isDeleted: false,
  },
  {
    id: "template-3",
    name: "褥瘡ケアテンプレート",
    description: "褥瘡のある患者の記録用",
    type: "team",
    createdById: "user-2",
    createdAt: new Date("2025-02-15"),
    updatedAt: new Date("2025-02-15"),
    recordType: "treatment",
    content: {
      subjective: "疼痛の有無と程度：\n不快感：",
      objective:
        "褥瘡の部位：\nサイズ（縦×横×深さ）：\n肉芽形成状態：\n浸出液の性状と量：\n周囲の皮膚状態：\nDESIGN-R評価：",
      assessment: "治癒過程の評価：\n悪化因子の有無：\n栄養状態との関連：",
      plan: "処置内容：\n体位変換計画：\n栄養サポート：\n次回の評価予定：",
    },
    tags: ["褥瘡", "創傷ケア"],
    isDeleted: false,
  },
  {
    id: "template-4",
    name: "呼吸器疾患テンプレート",
    description: "COPD等の呼吸器疾患患者用",
    type: "personal",
    createdById: "user-2",
    createdAt: new Date("2025-03-01"),
    updatedAt: new Date("2025-03-01"),
    recordType: "visit",
    content: {
      subjective: "呼吸困難の有無：\n咳嗽の性状と頻度：\n痰の性状と量：\n日常生活活動状況：",
      objective: "呼吸数：\nSpO2：\n聴診所見：\n呼吸パターン：\n補助筋の使用：\n在宅酸素使用状況：",
      assessment: "呼吸状態の評価：\n酸素化の状態：\n日常生活活動への影響：",
      plan: "呼吸リハビリ内容：\n酸素療法の調整：\n環境調整：\n緊急時の対応確認：",
    },
    tags: ["呼吸器", "COPD", "在宅酸素"],
    isDeleted: false,
  },
]

interface TemplateSelectorProps {
  onSelectTemplate: (template: RecordTemplate) => void
  recordType?: RecordType
}

export function TemplateSelector({ onSelectTemplate, recordType }: TemplateSelectorProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState<"all" | "personal" | "team" | "system" | "recent">("all")
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [newTemplate, setNewTemplate] = useState<Partial<RecordTemplate>>({
    name: "",
    description: "",
    recordType: recordType || "visit",
    content: {
      subjective: "",
      objective: "",
      assessment: "",
      plan: "",
    },
    tags: [],
  })

  // フィルタリングされたテンプレート
  const filteredTemplates = mockTemplates
    .filter((template) => {
      // レコードタイプによるフィルタリング
      if (recordType && template.recordType !== recordType) return false

      // タブによるフィルタリング
      if (activeTab !== "all" && activeTab !== "recent" && template.type !== activeTab) return false

      // 検索クエリによるフィルタリング
      if (
        searchQuery &&
        !template.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !template.tags?.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      )
        return false

      return true
    })
    .sort((a, b) => {
      // デフォルトテンプレートを先頭に
      if (a.isDefault && !b.isDefault) return -1
      if (!a.isDefault && b.isDefault) return 1

      // それ以外は更新日時の降順
      return b.updatedAt.getTime() - a.updatedAt.getTime()
    })

  // 新しいテンプレートの作成
  const handleCreateTemplate = () => {
    // 実際の実装ではAPIを呼び出してテンプレートを保存
    console.log("新しいテンプレートを作成:", newTemplate)
    setIsCreateDialogOpen(false)
    // テンプレート作成後の処理
  }

  return (
    <div className="flex flex-col h-full border rounded-lg">
      <div className="p-4 border-b">
        <h2 className="text-xl font-bold mb-4">記録テンプレート</h2>
        <div className="flex items-center space-x-2">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="テンプレートを検索..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                新規作成
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>新しいテンプレートを作成</DialogTitle>
                <DialogDescription>
                  繰り返し使用する記録のテンプレートを作成します。個人用または共有用に設定できます。
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="template-name" className="text-right">
                    テンプレート名
                  </Label>
                  <Input
                    id="template-name"
                    value={newTemplate.name}
                    onChange={(e) => setNewTemplate({ ...newTemplate, name: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="template-description" className="text-right">
                    説明
                  </Label>
                  <Input
                    id="template-description"
                    value={newTemplate.description}
                    onChange={(e) => setNewTemplate({ ...newTemplate, description: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="template-type" className="text-right">
                    記録タイプ
                  </Label>
                  <Select
                    value={newTemplate.recordType}
                    onValueChange={(value) => setNewTemplate({ ...newTemplate, recordType: value as RecordType })}
                  >
                    <SelectTrigger id="template-type" className="col-span-3">
                      <SelectValue placeholder="記録タイプを選択" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="visit">訪問看護記録</SelectItem>
                      <SelectItem value="vital">バイタル測定</SelectItem>
                      <SelectItem value="medication">服薬管理</SelectItem>
                      <SelectItem value="treatment">処置記録</SelectItem>
                      <SelectItem value="assessment">アセスメント</SelectItem>
                      <SelectItem value="plan">看護計画</SelectItem>
                      <SelectItem value="other">その他</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="template-sharing" className="text-right">
                    共有設定
                  </Label>
                  <Select defaultValue="personal">
                    <SelectTrigger id="template-sharing" className="col-span-3">
                      <SelectValue placeholder="共有設定を選択" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="personal">個人用</SelectItem>
                      <SelectItem value="team">チーム共有</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 gap-4">
                  <Label htmlFor="template-subjective" className="text-right">
                    主観的情報(S)
                  </Label>
                  <Textarea
                    id="template-subjective"
                    value={newTemplate.content?.subjective || ""}
                    onChange={(e) =>
                      setNewTemplate({
                        ...newTemplate,
                        content: { ...newTemplate.content, subjective: e.target.value },
                      })
                    }
                    className="col-span-3"
                    rows={3}
                  />
                </div>
                <div className="grid grid-cols-4 gap-4">
                  <Label htmlFor="template-objective" className="text-right">
                    客観的情報(O)
                  </Label>
                  <Textarea
                    id="template-objective"
                    value={newTemplate.content?.objective || ""}
                    onChange={(e) =>
                      setNewTemplate({
                        ...newTemplate,
                        content: { ...newTemplate.content, objective: e.target.value },
                      })
                    }
                    className="col-span-3"
                    rows={3}
                  />
                </div>
                <div className="grid grid-cols-4 gap-4">
                  <Label htmlFor="template-assessment" className="text-right">
                    アセスメント(A)
                  </Label>
                  <Textarea
                    id="template-assessment"
                    value={newTemplate.content?.assessment || ""}
                    onChange={(e) =>
                      setNewTemplate({
                        ...newTemplate,
                        content: { ...newTemplate.content, assessment: e.target.value },
                      })
                    }
                    className="col-span-3"
                    rows={3}
                  />
                </div>
                <div className="grid grid-cols-4 gap-4">
                  <Label htmlFor="template-plan" className="text-right">
                    計画(P)
                  </Label>
                  <Textarea
                    id="template-plan"
                    value={newTemplate.content?.plan || ""}
                    onChange={(e) =>
                      setNewTemplate({
                        ...newTemplate,
                        content: { ...newTemplate.content, plan: e.target.value },
                      })
                    }
                    className="col-span-3"
                    rows={3}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="template-tags" className="text-right">
                    タグ
                  </Label>
                  <Input
                    id="template-tags"
                    placeholder="カンマ区切りでタグを入力"
                    className="col-span-3"
                    onChange={(e) =>
                      setNewTemplate({
                        ...newTemplate,
                        tags: e.target.value.split(",").map((tag) => tag.trim()),
                      })
                    }
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  キャンセル
                </Button>
                <Button onClick={handleCreateTemplate}>テンプレートを保存</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="all" className="flex-1 flex flex-col" onValueChange={(value) => setActiveTab(value as any)}>
        <TabsList className="mx-4 mt-2">
          <TabsTrigger value="all" className="flex-1">
            すべて
          </TabsTrigger>
          <TabsTrigger value="personal" className="flex-1">
            個人用
          </TabsTrigger>
          <TabsTrigger value="team" className="flex-1">
            チーム
          </TabsTrigger>
          <TabsTrigger value="recent" className="flex-1">
            最近使用
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="flex-1 mt-0">
          <ScrollArea className="h-[calc(100vh-15rem)]">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
              {filteredTemplates.length > 0 ? (
                filteredTemplates.map((template) => (
                  <Card
                    key={template.id}
                    className={`cursor-pointer hover:border-primary transition-colors ${
                      template.isDefault ? "border-primary" : ""
                    }`}
                    onClick={() => onSelectTemplate(template)}
                  >
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{template.name}</CardTitle>
                        {template.isDefault && <Star className="h-4 w-4 text-primary" />}
                      </div>
                      <CardDescription>{template.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <div className="flex flex-wrap gap-1 mb-2">
                        {template.tags?.map((tag) => (
                          <Badge key={tag} variant="secondary">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      <div className="text-xs text-muted-foreground flex items-center">
                        {template.type === "personal" ? (
                          <Star className="h-3 w-3 mr-1" />
                        ) : template.type === "team" ? (
                          <Users className="h-3 w-3 mr-1" />
                        ) : (
                          <Settings className="h-3 w-3 mr-1" />
                        )}
                        {template.type === "personal" ? "個人用" : template.type === "team" ? "チーム共有" : "システム"}
                        <Clock className="h-3 w-3 ml-2 mr-1" />
                        {template.updatedAt.toLocaleDateString()}
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="col-span-2 p-4 text-center text-muted-foreground">該当するテンプレートがありません</div>
              )}
            </div>
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  )
}
