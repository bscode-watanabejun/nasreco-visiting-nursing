"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Thermometer, Heart, TreesIcon as Lungs, Activity, Droplet, Gauge, Scale, AlertTriangle } from "lucide-react"
import type { VitalSigns } from "@/lib/db/record-schema"

interface VitalSignsInputProps {
  initialValues?: Partial<VitalSigns>
  onSave: (vitalSigns: VitalSigns) => void
}

export function VitalSignsInput({ initialValues, onSave }: VitalSignsInputProps) {
  const [vitalSigns, setVitalSigns] = useState<Partial<VitalSigns>>(
    initialValues || {
      bodyTemperature: undefined,
      pulseRate: undefined,
      respiratoryRate: undefined,
      bloodPressureSystolic: undefined,
      bloodPressureDiastolic: undefined,
      oxygenSaturation: undefined,
      bloodGlucose: undefined,
      painScale: 0,
      consciousnessLevel: "清明",
      weight: undefined,
    },
  )

  // 入力値の変更ハンドラ
  const handleChange = (field: keyof VitalSigns, value: any) => {
    setVitalSigns((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  // 数値入力のハンドラ
  const handleNumberChange = (field: keyof VitalSigns, value: string) => {
    const numValue = value === "" ? undefined : Number.parseFloat(value)
    handleChange(field, numValue)
  }

  // 保存ハンドラ
  const handleSave = () => {
    onSave(vitalSigns as VitalSigns)
  }

  // バイタルサインの異常値チェック
  const isAbnormal = (field: keyof VitalSigns): boolean => {
    const value = vitalSigns[field]
    if (value === undefined) return false

    switch (field) {
      case "bodyTemperature":
        return value < 36.0 || value > 37.5
      case "pulseRate":
        return value < 60 || value > 100
      case "respiratoryRate":
        return value < 12 || value > 20
      case "bloodPressureSystolic":
        return value < 90 || value > 140
      case "bloodPressureDiastolic":
        return value < 60 || value > 90
      case "oxygenSaturation":
        return value < 95
      case "bloodGlucose":
        return value < 70 || value > 180
      default:
        return false
    }
  }

  // 異常値の警告メッセージ
  const getAbnormalMessage = (field: keyof VitalSigns): string => {
    const value = vitalSigns[field]
    if (value === undefined) return ""

    switch (field) {
      case "bodyTemperature":
        return value < 36.0 ? "低体温" : value > 37.5 ? "発熱" : ""
      case "pulseRate":
        return value < 60 ? "徐脈" : value > 100 ? "頻脈" : ""
      case "respiratoryRate":
        return value < 12 ? "呼吸数減少" : value > 20 ? "呼吸数増加" : ""
      case "bloodPressureSystolic":
        return value < 90 ? "低血圧" : value > 140 ? "高血圧" : ""
      case "bloodPressureDiastolic":
        return value < 60 ? "低血圧" : value > 90 ? "高血圧" : ""
      case "oxygenSaturation":
        return value < 95 ? "低酸素血症" : ""
      case "bloodGlucose":
        return value < 70 ? "低血糖" : value > 180 ? "高血糖" : ""
      default:
        return ""
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Activity className="mr-2 h-5 w-5" />
          バイタルサイン
        </CardTitle>
        <CardDescription>患者のバイタルサインを記録します。</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* 体温 */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="body-temperature" className="flex items-center">
                <Thermometer className="mr-1 h-4 w-4" />
                体温
              </Label>
              {isAbnormal("bodyTemperature") && (
                <Badge variant="destructive" className="flex items-center">
                  <AlertTriangle className="mr-1 h-3 w-3" />
                  {getAbnormalMessage("bodyTemperature")}
                </Badge>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <Input
                id="body-temperature"
                type="number"
                step="0.1"
                min="30"
                max="45"
                value={vitalSigns.bodyTemperature?.toString() || ""}
                onChange={(e) => handleNumberChange("bodyTemperature", e.target.value)}
                className={isAbnormal("bodyTemperature") ? "border-red-500" : ""}
              />
              <span>℃</span>
            </div>
          </div>

          {/* 脈拍 */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="pulse-rate" className="flex items-center">
                <Heart className="mr-1 h-4 w-4" />
                脈拍
              </Label>
              {isAbnormal("pulseRate") && (
                <Badge variant="destructive" className="flex items-center">
                  <AlertTriangle className="mr-1 h-3 w-3" />
                  {getAbnormalMessage("pulseRate")}
                </Badge>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <Input
                id="pulse-rate"
                type="number"
                min="30"
                max="200"
                value={vitalSigns.pulseRate?.toString() || ""}
                onChange={(e) => handleNumberChange("pulseRate", e.target.value)}
                className={isAbnormal("pulseRate") ? "border-red-500" : ""}
              />
              <span>回/分</span>
            </div>
          </div>

          {/* 呼吸数 */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="respiratory-rate" className="flex items-center">
                <Lungs className="mr-1 h-4 w-4" />
                呼吸数
              </Label>
              {isAbnormal("respiratoryRate") && (
                <Badge variant="destructive" className="flex items-center">
                  <AlertTriangle className="mr-1 h-3 w-3" />
                  {getAbnormalMessage("respiratoryRate")}
                </Badge>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <Input
                id="respiratory-rate"
                type="number"
                min="5"
                max="60"
                value={vitalSigns.respiratoryRate?.toString() || ""}
                onChange={(e) => handleNumberChange("respiratoryRate", e.target.value)}
                className={isAbnormal("respiratoryRate") ? "border-red-500" : ""}
              />
              <span>回/分</span>
            </div>
          </div>

          {/* 血圧 */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="blood-pressure" className="flex items-center">
                <Activity className="mr-1 h-4 w-4" />
                血圧
              </Label>
              {(isAbnormal("bloodPressureSystolic") || isAbnormal("bloodPressureDiastolic")) && (
                <Badge variant="destructive" className="flex items-center">
                  <AlertTriangle className="mr-1 h-3 w-3" />
                  {getAbnormalMessage("bloodPressureSystolic") || getAbnormalMessage("bloodPressureDiastolic")}
                </Badge>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <Input
                id="blood-pressure-systolic"
                type="number"
                min="60"
                max="250"
                value={vitalSigns.bloodPressureSystolic?.toString() || ""}
                onChange={(e) => handleNumberChange("bloodPressureSystolic", e.target.value)}
                className={isAbnormal("bloodPressureSystolic") ? "border-red-500" : ""}
              />
              <span>/</span>
              <Input
                id="blood-pressure-diastolic"
                type="number"
                min="30"
                max="150"
                value={vitalSigns.bloodPressureDiastolic?.toString() || ""}
                onChange={(e) => handleNumberChange("bloodPressureDiastolic", e.target.value)}
                className={isAbnormal("bloodPressureDiastolic") ? "border-red-500" : ""}
              />
              <span>mmHg</span>
            </div>
          </div>

          {/* SpO2 */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="oxygen-saturation" className="flex items-center">
                <Droplet className="mr-1 h-4 w-4" />
                SpO2
              </Label>
              {isAbnormal("oxygenSaturation") && (
                <Badge variant="destructive" className="flex items-center">
                  <AlertTriangle className="mr-1 h-3 w-3" />
                  {getAbnormalMessage("oxygenSaturation")}
                </Badge>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <Input
                id="oxygen-saturation"
                type="number"
                min="70"
                max="100"
                value={vitalSigns.oxygenSaturation?.toString() || ""}
                onChange={(e) => handleNumberChange("oxygenSaturation", e.target.value)}
                className={isAbnormal("oxygenSaturation") ? "border-red-500" : ""}
              />
              <span>%</span>
            </div>
          </div>

          {/* 血糖値 */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="blood-glucose" className="flex items-center">
                <Gauge className="mr-1 h-4 w-4" />
                血糖値
              </Label>
              {isAbnormal("bloodGlucose") && (
                <Badge variant="destructive" className="flex items-center">
                  <AlertTriangle className="mr-1 h-3 w-3" />
                  {getAbnormalMessage("bloodGlucose")}
                </Badge>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <Input
                id="blood-glucose"
                type="number"
                min="20"
                max="600"
                value={vitalSigns.bloodGlucose?.toString() || ""}
                onChange={(e) => handleNumberChange("bloodGlucose", e.target.value)}
                className={isAbnormal("bloodGlucose") ? "border-red-500" : ""}
              />
              <span>mg/dL</span>
            </div>
          </div>

          {/* 体重 */}
          <div className="space-y-2">
            <Label htmlFor="weight" className="flex items-center">
              <Scale className="mr-1 h-4 w-4" />
              体重
            </Label>
            <div className="flex items-center space-x-2">
              <Input
                id="weight"
                type="number"
                step="0.1"
                min="20"
                max="200"
                value={vitalSigns.weight?.toString() || ""}
                onChange={(e) => handleNumberChange("weight", e.target.value)}
              />
              <span>kg</span>
            </div>
          </div>

          {/* 意識レベル */}
          <div className="space-y-2">
            <Label htmlFor="consciousness-level">意識レベル</Label>
            <Select
              value={vitalSigns.consciousnessLevel || ""}
              onValueChange={(value) => handleChange("consciousnessLevel", value)}
            >
              <SelectTrigger id="consciousness-level">
                <SelectValue placeholder="意識レベルを選択" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="清明">清明</SelectItem>
                <SelectItem value="JCS I-1">JCS I-1（見当識あるが意識清明でない）</SelectItem>
                <SelectItem value="JCS I-2">JCS I-2（見当識障害あり）</SelectItem>
                <SelectItem value="JCS I-3">JCS I-3（自分の名前・生年月日が言えない）</SelectItem>
                <SelectItem value="JCS II-10">JCS II-10（普通の呼びかけで開眼する）</SelectItem>
                <SelectItem value="JCS II-20">JCS II-20（大きな声または体を揺さぶることで開眼する）</SelectItem>
                <SelectItem value="JCS II-30">JCS II-30（痛み刺激で辛うじて開眼する）</SelectItem>
                <SelectItem value="JCS III-100">JCS III-100（痛み刺激に反応あり、払いのける動作あり）</SelectItem>
                <SelectItem value="JCS III-200">JCS III-200（痛み刺激で少し手足を動かしたり顔をしかめる）</SelectItem>
                <SelectItem value="JCS III-300">JCS III-300（痛み刺激に全く反応しない）</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* 疼痛スケール */}
          <div className="space-y-2 col-span-1 md:col-span-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="pain-scale">疼痛スケール (0-10)</Label>
              <span className="font-bold">{vitalSigns.painScale}</span>
            </div>
            <Slider
              id="pain-scale"
              min={0}
              max={10}
              step={1}
              value={[vitalSigns.painScale || 0]}
              onValueChange={(value) => handleChange("painScale", value[0])}
              className="py-4"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>痛みなし</span>
              <span>軽度</span>
              <span>中等度</span>
              <span>重度</span>
              <span>最大の痛み</span>
            </div>
          </div>
        </div>

        <Button onClick={handleSave} className="mt-6 w-full">
          バイタルサインを保存
        </Button>
      </CardContent>
    </Card>
  )
}
