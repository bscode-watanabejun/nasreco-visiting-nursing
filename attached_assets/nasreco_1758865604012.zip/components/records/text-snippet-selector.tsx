"use client"

import { useState } from "react"
import { Search, Plus, Copy } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import type { TextSnippet } from "@/lib/db/record-schema"

// モックデータ
const mockSnippets: TextSnippet[] = [
  {
    id: "snippet-1",
    userId: "user-1",
    category: "バイタルサイン",
    title: "正常バイタル",
    content: "バイタルサイン安定。体温36.5℃、脈拍72回/分、呼吸数18回/分、血圧124/78mmHg、SpO2 98%。",
    createdAt: new Date("2025-01-15"),
    updatedAt: new Date("2025-01-15"),
    usageCount: 42,
    isDeleted: false,
  },
  {
    id: "snippet-2",
    userId: "user-1",
    category: "食事摂取",
    title: "食事良好",
    content: "食事摂取良好。3食とも8割程度摂取。水分摂取量約1500ml/日。",
    createdAt: new Date("2025-02-01"),
    updatedAt: new Date("2025-02-01"),
    usageCount: 28,
    isDeleted: false,
  },
  {
    id: "snippet-3",
    userId: "user-2",
    category: "処置",
    title: "褥瘡処置",
    content:
      "仙骨部の褥瘡処置実施。サイズ2.0×1.5cm、深さ0.3cm。肉芽形成良好で浸出液少量。周囲の皮膚発赤なし。洗浄後、ハイドロコロイド材貼付。",
    createdAt: new Date("2025-02-15"),
    updatedAt: new Date("2025-02-15"),
    usageCount: 15,
    isDeleted: false,
  },
  {
    id: "snippet-4",
    userId: "user-1",
    category: "リハビリ",
    title: "歩行訓練",
    content: "歩行訓練実施。室内を歩行器使用し10m×3セット実施。ふらつきなく安定した歩行ができている。",
    createdAt: new Date("2025-03-01"),
    updatedAt: new Date("2025-03-01"),
    usageCount: 12,
    isDeleted: false,
  },
  {
    id: "snippet-5",
    userId: "user-1",
    category: "服薬管理",
    title: "服薬状況",
    content: "服薬管理良好。一包化された薬剤を自己管理にて内服できている。残薬なし。副作用の訴えなし。",
    createdAt: new Date("2025-03-10"),
    updatedAt: new Date("2025-03-10"),
    usageCount: 20,
    isDeleted: false,
  },
]

interface TextSnippetSelectorProps {
  onSelectSnippet: (snippet: TextSnippet) => void
}

export function TextSnippetSelector({ onSelectSnippet }: TextSnippetSelectorProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState<"all" | "frequent" | "recent">("all")
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [newSnippet, setNewSnippet] = useState<Partial<TextSnippet>>({
    category: "",
    title: "",
    content: "",
  })

  // フィルタリングされた定型文
  const filteredSnippets = mockSnippets
    .filter((snippet) => {
      // 検索クエリによるフィルタリング
      if (
        searchQuery &&
        !snippet.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !snippet.category.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !snippet.content.toLowerCase().includes(searchQuery.toLowerCase())
      )
        return false

      return true
    })
    .sort((a, b) => {
      // タブに応じたソート
      if (activeTab === "frequent") {
        return b.usageCount - a.usageCount
      } else if (activeTab === "recent") {
        return b.updatedAt.getTime() - a.updatedAt.getTime()
      }
      // デフォルトはカテゴリでグループ化
      if (a.category !== b.category) {
        return a.category.localeCompare(b.category)
      }
      return b.usageCount - a.usageCount
    })

  // 新しい定型文の作成
  const handleCreateSnippet = () => {
    // 実際の実装ではAPIを呼び出して定型文を保存
    console.log("新しい定型文を作成:", newSnippet)
    setIsCreateDialogOpen(false)
    // 定型文作成後の処理
  }

  // カテゴリでグループ化
  const groupedSnippets: Record<string, TextSnippet[]> = {}
  if (activeTab === "all") {
    filteredSnippets.forEach((snippet) => {
      if (!groupedSnippets[snippet.category]) {
        groupedSnippets[snippet.category] = []
      }
      groupedSnippets[snippet.category].push(snippet)
    })
  }

  return (
    <div className="flex flex-col h-full border rounded-lg">
      <div className="p-4 border-b">
        <h2 className="text-xl font-bold mb-4">定型文</h2>
        <div className="flex items-center space-x-2">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="定型文を検索..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                新規作成
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>新しい定型文を作成</DialogTitle>
                <DialogDescription>繰り返し使用するテキストを定型文として保存します。</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="snippet-category" className="text-right">
                    カテゴリ
                  </Label>
                  <Input
                    id="snippet-category"
                    value={newSnippet.category}
                    onChange={(e) => setNewSnippet({ ...newSnippet, category: e.target.value })}
                    className="col-span-3"
                    placeholder="バイタルサイン、処置、リハビリなど"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="snippet-title" className="text-right">
                    タイトル
                  </Label>
                  <Input
                    id="snippet-title"
                    value={newSnippet.title}
                    onChange={(e) => setNewSnippet({ ...newSnippet, title: e.target.value })}
                    className="col-span-3"
                    placeholder="わかりやすい短いタイトル"
                  />
                </div>
                <div className="grid grid-cols-4 gap-4">
                  <Label htmlFor="snippet-content" className="text-right">
                    内容
                  </Label>
                  <Textarea
                    id="snippet-content"
                    value={newSnippet.content}
                    onChange={(e) => setNewSnippet({ ...newSnippet, content: e.target.value })}
                    className="col-span-3"
                    rows={5}
                    placeholder="定型文の内容を入力してください"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  キャンセル
                </Button>
                <Button onClick={handleCreateSnippet}>保存</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="all" className="flex-1 flex flex-col" onValueChange={(value) => setActiveTab(value as any)}>
        <TabsList className="mx-4 mt-2">
          <TabsTrigger value="all" className="flex-1">
            カテゴリ別
          </TabsTrigger>
          <TabsTrigger value="frequent" className="flex-1">
            よく使う
          </TabsTrigger>
          <TabsTrigger value="recent" className="flex-1">
            最近使用
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="flex-1 mt-0">
          <ScrollArea className="h-[calc(100vh-15rem)]">
            {activeTab === "all" ? (
              <div className="p-4 space-y-6">
                {Object.keys(groupedSnippets).length > 0 ? (
                  Object.entries(groupedSnippets).map(([category, snippets]) => (
                    <div key={category}>
                      <h3 className="text-sm font-medium mb-2 px-2">{category}</h3>
                      <div className="space-y-2">
                        {snippets.map((snippet) => (
                          <Card
                            key={snippet.id}
                            className="cursor-pointer hover:border-primary transition-colors"
                            onClick={() => onSelectSnippet(snippet)}
                          >
                            <CardHeader className="py-3">
                              <div className="flex justify-between items-center">
                                <CardTitle className="text-sm">{snippet.title}</CardTitle>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    onSelectSnippet(snippet)
                                  }}
                                >
                                  <Copy className="h-4 w-4" />
                                </Button>
                              </div>
                            </CardHeader>
                            <CardContent className="py-0 pb-3">
                              <p className="text-sm text-muted-foreground line-clamp-2">{snippet.content}</p>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-4 text-center text-muted-foreground">該当する定型文がありません</div>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-2 p-4">
                {filteredSnippets.length > 0 ? (
                  filteredSnippets.map((snippet) => (
                    <Card
                      key={snippet.id}
                      className="cursor-pointer hover:border-primary transition-colors"
                      onClick={() => onSelectSnippet(snippet)}
                    >
                      <CardHeader className="py-3">
                        <div className="flex justify-between items-center">
                          <div>
                            <CardTitle className="text-sm">{snippet.title}</CardTitle>
                            <CardDescription className="text-xs">{snippet.category}</CardDescription>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation()
                              onSelectSnippet(snippet)
                            }}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent className="py-0 pb-3">
                        <p className="text-sm text-muted-foreground line-clamp-2">{snippet.content}</p>
                        <div className="flex justify-between items-center mt-2 text-xs text-muted-foreground">
                          <span>使用回数: {snippet.usageCount}回</span>
                          <span>更新: {snippet.updatedAt.toLocaleDateString()}</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <div className="p-4 text-center text-muted-foreground">該当する定型文がありません</div>
                )}
              </div>
            )}
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  )
}
