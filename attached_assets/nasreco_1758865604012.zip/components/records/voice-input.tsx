"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Mic, MicOff, Loader2, Save, Trash } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface VoiceInputProps {
  onTranscriptReady: (transcript: string) => void
  placeholder?: string
  initialText?: string
}

export function VoiceInput({ onTranscriptReady, placeholder, initialText = "" }: VoiceInputProps) {
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState(initialText)
  const [tempTranscript, setTempTranscript] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [autoSave, setAutoSave] = useState(true)
  const [language, setLanguage] = useState("ja-JP")
  const recognitionRef = useRef<any>(null)

  // ブラウザの音声認識APIをセットアップ
  useEffect(() => {
    if (typeof window !== "undefined") {
      // @ts-ignore - SpeechRecognition is not in the TypeScript types
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition()
        recognitionRef.current.continuous = true
        recognitionRef.current.interimResults = true
        recognitionRef.current.lang = language

        recognitionRef.current.onresult = (event: any) => {
          let interimTranscript = ""
          let finalTranscript = ""

          for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
              finalTranscript += event.results[i][0].transcript
            } else {
              interimTranscript += event.results[i][0].transcript
            }
          }

          if (finalTranscript) {
            setTranscript((prev) => prev + finalTranscript + " ")
            if (autoSave) {
              onTranscriptReady(transcript + finalTranscript + " ")
            }
          }
          setTempTranscript(interimTranscript)
        }

        recognitionRef.current.onerror = (event: any) => {
          console.error("Speech recognition error", event.error)
          setError(`音声認識エラー: ${event.error}`)
          setIsListening(false)
        }

        recognitionRef.current.onend = () => {
          if (isListening) {
            // 自動的に再開（continuous=trueでも途切れることがあるため）
            try {
              recognitionRef.current.start()
            } catch (e) {
              console.log("Recognition already started")
            }
          }
        }
      } else {
        setError("お使いのブラウザは音声認識をサポートしていません。")
      }
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop()
        } catch (e) {
          console.log("Recognition already stopped")
        }
      }
    }
  }, [language, autoSave, transcript, onTranscriptReady])

  // 音声認識の開始/停止
  const toggleListening = () => {
    if (!recognitionRef.current) {
      setError("音声認識を利用できません。")
      return
    }

    if (isListening) {
      recognitionRef.current.stop()
      setIsListening(false)
      setTempTranscript("")
    } else {
      setError(null)
      try {
        recognitionRef.current.start()
        setIsListening(true)
      } catch (e) {
        console.error("Failed to start speech recognition:", e)
        setError("音声認識の開始に失敗しました。")
      }
    }
  }

  // テキストの保存
  const handleSave = () => {
    onTranscriptReady(transcript)
  }

  // テキストのクリア
  const handleClear = () => {
    setTranscript("")
    setTempTranscript("")
    onTranscriptReady("")
  }

  // 手動でテキストを編集
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setTranscript(e.target.value)
  }

  // 言語変更時の処理
  useEffect(() => {
    if (recognitionRef.current) {
      const wasListening = isListening
      if (wasListening) {
        recognitionRef.current.stop()
        setIsListening(false)
      }
      recognitionRef.current.lang = language
      if (wasListening) {
        setTimeout(() => {
          try {
            recognitionRef.current.start()
            setIsListening(true)
          } catch (e) {
            console.error("Failed to restart speech recognition:", e)
          }
        }, 100)
      }
    }
  }, [language, isListening])

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  onClick={toggleListening}
                  variant={isListening ? "default" : "outline"}
                  className={isListening ? "bg-red-500 hover:bg-red-600" : ""}
                >
                  {isListening ? <MicOff className="mr-2 h-4 w-4" /> : <Mic className="mr-2 h-4 w-4" />}
                  {isListening ? "停止" : "音声入力"}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{isListening ? "音声入力を停止" : "音声入力を開始"}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <div className="flex items-center space-x-2">
            <Label htmlFor="auto-save" className="text-sm">
              自動保存
            </Label>
            <Switch id="auto-save" checked={autoSave} onCheckedChange={setAutoSave} />
          </div>

          <Select value={language} onValueChange={setLanguage}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="言語を選択" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ja-JP">日本語</SelectItem>
              <SelectItem value="en-US">英語 (US)</SelectItem>
              <SelectItem value="zh-CN">中国語</SelectItem>
              <SelectItem value="ko-KR">韓国語</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center space-x-2">
          <Button variant="outline" size="icon" onClick={handleClear}>
            <Trash className="h-4 w-4" />
          </Button>
          <Button size="icon" onClick={handleSave} disabled={!transcript.trim()}>
            <Save className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {isListening && (
        <div className="flex items-center space-x-2">
          <div className="relative h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
          </div>
          <span className="text-sm">音声を認識中...</span>
          {tempTranscript && <Badge variant="outline">{tempTranscript}</Badge>}
        </div>
      )}

      {error && <div className="text-sm text-red-500">{error}</div>}

      <Textarea
        value={transcript}
        onChange={handleTextChange}
        placeholder={placeholder || "音声入力または直接テキストを入力してください..."}
        className="min-h-[150px]"
      />

      {isProcessing && (
        <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span>処理中...</span>
        </div>
      )}
    </div>
  )
}
