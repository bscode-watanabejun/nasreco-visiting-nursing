"use client"

import type React from "react"

import { useState } from "react"
import { Camera, Upload, RefreshCw, AlertCircle, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface WoundAssessmentResult {
  stage: string
  area: number
  depth: number
  exudate: string
  tissue: string
  infection: boolean
  healing: "improving" | "stable" | "worsening"
  confidence: number
  recommendations: string[]
}

interface AIWoundAssessmentProps {
  onResult?: (result: WoundAssessmentResult) => void
  previousResults?: WoundAssessmentResult[]
  previousImages?: string[]
}

export function AIWoundAssessment({ onResult, previousResults = [], previousImages = [] }: AIWoundAssessmentProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [previewImage, setPreviewImage] = useState<string | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [result, setResult] = useState<WoundAssessmentResult | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0]
      if (file.type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = () => {
          setPreviewImage(reader.result as string)
          setSelectedImage(reader.result as string)
          setResult(null)
          setError(null)
        }
        reader.readAsDataURL(file)
      } else {
        setError("画像ファイルを選択してください")
      }
    }
  }

  const handleCameraCapture = () => {
    const input = document.createElement("input")
    input.type = "file"
    input.accept = "image/*"
    input.capture = "environment"
    input.onchange = (e) => handleFileChange(e as React.ChangeEvent<HTMLInputElement>)
    input.click()
  }

  const analyzeImage = () => {
    if (!selectedImage) return

    setIsAnalyzing(true)
    setProgress(0)
    setError(null)

    // 実際の実装ではAI APIを呼び出す
    // ここではモックデータを使用
    const interval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + Math.random() * 10
        if (newProgress >= 100) {
          clearInterval(interval)
          setTimeout(() => {
            // モック結果
            const mockResult: WoundAssessmentResult = {
              stage: "D3",
              area: 4.2,
              depth: 0.5,
              exudate: "moderate",
              tissue: "granulation",
              infection: false,
              healing: "improving",
              confidence: 0.87,
              recommendations: [
                "創部の洗浄を継続",
                "ハイドロコロイド材の使用を継続",
                "3日ごとの処置を推奨",
                "栄養状態の改善を検討",
              ],
            }
            setResult(mockResult)
            if (onResult) onResult(mockResult)
            setIsAnalyzing(false)
          }, 500)
          return 100
        }
        return newProgress
      })
    }, 200)
  }

  const resetAnalysis = () => {
    setSelectedImage(null)
    setPreviewImage(null)
    setResult(null)
    setError(null)
  }

  const getStageColor = (stage: string) => {
    switch (stage) {
      case "d1":
      case "d2":
        return "bg-yellow-100 text-yellow-800"
      case "D3":
      case "D4":
        return "bg-orange-100 text-orange-800"
      case "D5":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getHealingStatusColor = (status: string) => {
    switch (status) {
      case "improving":
        return "bg-green-100 text-green-800"
      case "stable":
        return "bg-blue-100 text-blue-800"
      case "worsening":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getHealingStatusText = (status: string) => {
    switch (status) {
      case "improving":
        return "改善傾向"
      case "stable":
        return "安定"
      case "worsening":
        return "悪化傾向"
      default:
        return status
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>褥瘡AI判定</CardTitle>
        <CardDescription>褥瘡の画像をアップロードして自動評価を行います</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="upload">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="upload">画像アップロード</TabsTrigger>
            <TabsTrigger value="history">履歴</TabsTrigger>
          </TabsList>
          <TabsContent value="upload" className="space-y-4 pt-4">
            {!selectedImage && !isAnalyzing && (
              <div className="grid grid-cols-2 gap-4">
                <div
                  className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer hover:bg-muted/50 transition-colors"
                  onClick={() => {
                    const input = document.createElement("input")
                    input.type = "file"
                    input.accept = "image/*"
                    input.onchange = (e) => handleFileChange(e as React.ChangeEvent<HTMLInputElement>)
                    input.click()
                  }}
                >
                  <Upload className="h-10 w-10 text-muted-foreground mb-2" />
                  <p className="font-medium">画像をアップロード</p>
                  <p className="text-sm text-muted-foreground">または画像をドラッグ＆ドロップ</p>
                </div>
                <div
                  className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer hover:bg-muted/50 transition-colors"
                  onClick={handleCameraCapture}
                >
                  <Camera className="h-10 w-10 text-muted-foreground mb-2" />
                  <p className="font-medium">カメラで撮影</p>
                  <p className="text-sm text-muted-foreground">デバイスのカメラを使用</p>
                </div>
              </div>
            )}

            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>エラー</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {previewImage && (
              <div className="space-y-4">
                <div className="relative aspect-square max-h-[400px] overflow-hidden rounded-md border bg-muted">
                  <img
                    src={previewImage || "/placeholder.svg"}
                    alt="褥瘡画像"
                    className="h-full w-full object-contain"
                  />
                </div>

                {isAnalyzing ? (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">分析中...</span>
                      <span className="text-sm text-muted-foreground">{Math.round(progress)}%</span>
                    </div>
                    <Progress value={progress} />
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <Button onClick={resetAnalysis} variant="outline" className="flex-1">
                      <RefreshCw className="mr-2 h-4 w-4" />
                      リセット
                    </Button>
                    <Button onClick={analyzeImage} className="flex-1" disabled={!selectedImage}>
                      分析開始
                    </Button>
                  </div>
                )}
              </div>
            )}

            {result && (
              <div className="space-y-4 mt-6">
                <Separator />
                <h3 className="text-lg font-medium">分析結果</h3>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">DESIGN-R分類</p>
                    <div className="flex items-center">
                      <Badge className={getStageColor(result.stage)}>{result.stage}</Badge>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-6 w-6 ml-1">
                              <Info className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>DESIGN-R分類は褥瘡の重症度を示します</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">治癒状態</p>
                    <Badge className={getHealingStatusColor(result.healing)}>
                      {getHealingStatusText(result.healing)}
                    </Badge>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">面積</p>
                    <p className="font-medium">{result.area} cm²</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">深さ</p>
                    <p className="font-medium">{result.depth} cm</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">浸出液</p>
                    <p className="font-medium">
                      {result.exudate === "none"
                        ? "なし"
                        : result.exudate === "minimal"
                          ? "少量"
                          : result.exudate === "moderate"
                            ? "中等量"
                            : "多量"}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">組織タイプ</p>
                    <p className="font-medium">
                      {result.tissue === "granulation"
                        ? "肉芽組織"
                        : result.tissue === "necrotic"
                          ? "壊死組織"
                          : result.tissue === "slough"
                            ? "壊死組織（湿潤）"
                            : result.tissue === "epithelial"
                              ? "上皮組織"
                              : result.tissue}
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">推奨事項</p>
                  <ul className="list-disc list-inside space-y-1">
                    {result.recommendations.map((rec, index) => (
                      <li key={index} className="text-sm">
                        {rec}
                      </li>
                    ))}
                  </ul>
                </div>

                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertTitle>注意</AlertTitle>
                  <AlertDescription>
                    このAI判定は参考情報です。最終的な判断は医療専門家が行ってください。
                    <div className="mt-1 text-xs text-muted-foreground">
                      信頼度: {Math.round(result.confidence * 100)}%
                    </div>
                  </AlertDescription>
                </Alert>
              </div>
            )}
          </TabsContent>
          <TabsContent value="history" className="pt-4">
            {previousResults.length > 0 ? (
              <div className="space-y-4">
                {previousResults.map((prevResult, index) => (
                  <Card key={index}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-base">
                          {new Date(
                            Date.now() - (previousResults.length - index) * 7 * 24 * 60 * 60 * 1000,
                          ).toLocaleDateString()}
                        </CardTitle>
                        <Badge className={getStageColor(prevResult.stage)}>{prevResult.stage}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <div className="flex gap-4">
                        {previousImages[index] && (
                          <div className="w-24 h-24 rounded-md overflow-hidden border">
                            <img
                              src={previousImages[index] || "/placeholder.svg"}
                              alt={`褥瘡画像 ${index + 1}`}
                              className="w-full h-full object-cover"
                            />
                          </div>
                        )}
                        <div className="flex-1 space-y-2">
                          <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                            <div className="text-sm">
                              <span className="text-muted-foreground">面積:</span> {prevResult.area} cm²
                            </div>
                            <div className="text-sm">
                              <span className="text-muted-foreground">深さ:</span> {prevResult.depth} cm
                            </div>
                            <div className="text-sm">
                              <span className="text-muted-foreground">状態:</span>{" "}
                              <Badge className={getHealingStatusColor(prevResult.healing)} variant="outline">
                                {getHealingStatusText(prevResult.healing)}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">履歴がありません</div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <p className="text-sm text-muted-foreground">
          AI判定は医療専門家の判断を補助するものであり、代替するものではありません
        </p>
      </CardFooter>
    </Card>
  )
}
