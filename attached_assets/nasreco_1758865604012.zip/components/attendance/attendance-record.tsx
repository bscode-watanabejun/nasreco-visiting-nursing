"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Clock, CheckCircle2, XCircle, FileText, ChevronRight } from "lucide-react"
import type { AttendanceRecord } from "@/lib/db/shift-schema"

// モックデータ（実際の実装ではAPIから取得）
const mockAttendanceRecords: AttendanceRecord[] = [
  {
    id: "att1",
    userId: "user1",
    date: new Date(2025, 3, 1), // 2025-04-01
    clockInTime: new Date(2025, 3, 1, 8, 30), // 8:30
    clockOutTime: new Date(2025, 3, 1, 17, 15), // 17:15
    breakTime: 60,
    totalWorkMinutes: 525, // 8時間45分
    overtimeMinutes: 15,
    status: "approved",
    createdAt: new Date(),
    updatedAt: new Date(),
    approvedAt: new Date(),
    approvedBy: "admin",
  },
  {
    id: "att2",
    userId: "user1",
    date: new Date(2025, 3, 2), // 2025-04-02
    clockInTime: new Date(2025, 3, 2, 8, 45), // 8:45
    clockOutTime: new Date(2025, 3, 2, 18, 30), // 18:30
    breakTime: 60,
    totalWorkMinutes: 585, // 9時間45分
    overtimeMinutes: 75,
    status: "approved",
    createdAt: new Date(),
    updatedAt: new Date(),
    approvedAt: new Date(),
    approvedBy: "admin",
  },
  {
    id: "att3",
    userId: "user1",
    date: new Date(2025, 3, 3), // 2025-04-03
    clockInTime: new Date(2025, 3, 3, 8, 30), // 8:30
    clockOutTime: new Date(2025, 3, 3, 17, 0), // 17:00
    breakTime: 60,
    totalWorkMinutes: 510, // 8時間30分
    overtimeMinutes: 0,
    status: "pending",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]

// 現在のユーザー（モック）
const currentUser = {
  id: "user1",
  name: "山田 花子",
}

interface AttendanceRecordComponentProps {
  userId?: string
  date?: Date
  viewMode?: "day" | "list"
}

export function AttendanceRecordComponent({
  userId = currentUser.id,
  date = new Date(),
  viewMode = "day",
}: AttendanceRecordComponentProps) {
  const [records, setRecords] = useState<AttendanceRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [clockedIn, setClockedIn] = useState(false)
  const [currentRecord, setCurrentRecord] = useState<AttendanceRecord | null>(null)
  const [note, setNote] = useState("")

  // データ取得（モック）
  useEffect(() => {
    // 実際の実装ではAPIからデータを取得
    setLoading(true)

    // モックデータをセット（タイムアウトを短くして即時表示）
    const timer = setTimeout(() => {
      const filteredRecords = mockAttendanceRecords.filter((record) => record.userId === userId)
      setRecords(filteredRecords)

      // 今日の記録があるかチェック
      const today = new Date().toISOString().split("T")[0]
      const todayRecord = filteredRecords.find((record) => {
        const recordDate = new Date(record.date).toISOString().split("T")[0]
        return recordDate === today
      })

      if (todayRecord) {
        setClockedIn(true)
        setCurrentRecord(todayRecord)
        setNote(todayRecord.note || "")
      }

      setLoading(false)
    }, 300) // タイムアウトを500msから300msに短縮

    // クリーンアップ関数
    return () => clearTimeout(timer)
  }, [userId])

  // 出勤打刻
  const handleClockIn = () => {
    // 実際の実装ではAPIを呼び出して打刻
    const now = new Date()

    // モックデータを更新（実際の実装では不要）
    const newRecord: AttendanceRecord = {
      id: `att${mockAttendanceRecords.length + 1}`,
      userId,
      date: new Date(now.getFullYear(), now.getMonth(), now.getDate()),
      clockInTime: now,
      status: "pending",
      createdAt: now,
      updatedAt: now,
    }

    mockAttendanceRecords.push(newRecord)
    setRecords([...records, newRecord])
    setCurrentRecord(newRecord)
    setClockedIn(true)

    console.log("出勤打刻:", now)
  }

  // 退勤打刻
  const handleClockOut = () => {
    if (!currentRecord) return

    // 実際の実装ではAPIを呼び出して打刻
    const now = new Date()

    // 労働時間計算（分）
    const clockInTime = currentRecord.clockInTime
    const totalMinutes = Math.floor((now.getTime() - clockInTime.getTime()) / 60000)
    const breakTime = 60 // 休憩時間（仮）
    const workMinutes = totalMinutes - breakTime

    // 残業時間計算（8時間 = 480分を超える部分）
    const overtimeMinutes = Math.max(0, workMinutes - 480)

    // モックデータを更新（実際の実装では不要）
    const updatedRecord: AttendanceRecord = {
      ...currentRecord,
      clockOutTime: now,
      breakTime,
      totalWorkMinutes: workMinutes,
      overtimeMinutes,
      note,
      updatedAt: now,
    }

    const recordIndex = mockAttendanceRecords.findIndex((r) => r.id === currentRecord.id)
    if (recordIndex >= 0) {
      mockAttendanceRecords[recordIndex] = updatedRecord
    }

    setCurrentRecord(updatedRecord)
    setRecords(records.map((r) => (r.id === currentRecord.id ? updatedRecord : r)))

    console.log("退勤打刻:", now)
  }

  // 勤務時間のフォーマット（分→時間:分）
  const formatWorkTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return `${hours}時間${mins > 0 ? `${mins}分` : ""}`
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>勤怠記録を読み込み中...</CardTitle>
        </CardHeader>
        <CardContent className="h-48 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    )
  }

  if (viewMode === "day") {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Clock className="mr-2 h-5 w-5 text-primary" />
            勤怠記録
          </CardTitle>
          <CardDescription>
            {new Date().toLocaleDateString("ja-JP", { year: "numeric", month: "long", day: "numeric" })}
            の勤怠を記録します
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="flex flex-col space-y-2 sm:flex-row sm:space-y-0 sm:space-x-4">
              <div className="flex-1 rounded-lg border p-4">
                <div className="text-sm font-medium text-muted-foreground">出勤時間</div>
                <div className="mt-1 flex items-center">
                  {clockedIn ? (
                    <>
                      <CheckCircle2 className="mr-2 h-5 w-5 text-green-500" />
                      <span className="text-xl font-bold">
                        {currentRecord?.clockInTime.toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </>
                  ) : (
                    <>
                      <XCircle className="mr-2 h-5 w-5 text-muted-foreground" />
                      <span className="text-xl font-bold text-muted-foreground">--:--</span>
                    </>
                  )}
                </div>
              </div>

              <div className="flex-1 rounded-lg border p-4">
                <div className="text-sm font-medium text-muted-foreground">退勤時間</div>
                <div className="mt-1 flex items-center">
                  {currentRecord?.clockOutTime ? (
                    <>
                      <CheckCircle2 className="mr-2 h-5 w-5 text-green-500" />
                      <span className="text-xl font-bold">
                        {currentRecord.clockOutTime.toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </>
                  ) : (
                    <>
                      <XCircle className="mr-2 h-5 w-5 text-muted-foreground" />
                      <span className="text-xl font-bold text-muted-foreground">--:--</span>
                    </>
                  )}
                </div>
              </div>
            </div>

            {currentRecord?.clockOutTime && currentRecord.totalWorkMinutes && (
              <div className="rounded-lg border p-4">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">総労働時間</div>
                    <div className="mt-1 text-lg font-bold">{formatWorkTime(currentRecord.totalWorkMinutes)}</div>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">休憩時間</div>
                    <div className="mt-1 text-lg font-bold">
                      {currentRecord.breakTime ? `${currentRecord.breakTime}分` : "--"}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">残業時間</div>
                    <div className="mt-1 text-lg font-bold">
                      {currentRecord.overtimeMinutes ? formatWorkTime(currentRecord.overtimeMinutes) : "--"}
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="note">備考</Label>
              <Textarea
                id="note"
                placeholder="備考を入力してください"
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => console.log("勤怠履歴へ")}>
            勤怠履歴
          </Button>
          <div>
            {!clockedIn ? (
              <Button onClick={handleClockIn}>
                <Clock className="mr-2 h-4 w-4" />
                出勤打刻
              </Button>
            ) : !currentRecord?.clockOutTime ? (
              <Button onClick={handleClockOut}>
                <Clock className="mr-2 h-4 w-4" />
                退勤打刻
              </Button>
            ) : (
              <Button disabled>
                <CheckCircle2 className="mr-2 h-4 w-4" />
                打刻完了
              </Button>
            )}
          </div>
        </CardFooter>
      </Card>
    )
  }

  // リスト表示モード
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <FileText className="mr-2 h-5 w-5 text-primary" />
          勤怠履歴
        </CardTitle>
        <CardDescription>{currentUser.name}さんの勤怠記録一覧</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>日付</TableHead>
              <TableHead>出勤</TableHead>
              <TableHead>退勤</TableHead>
              <TableHead>勤務時間</TableHead>
              <TableHead>残業</TableHead>
              <TableHead>状態</TableHead>
              <TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {records.map((record) => (
              <TableRow key={record.id}>
                <TableCell>{record.date.toLocaleDateString("ja-JP", { month: "numeric", day: "numeric" })}</TableCell>
                <TableCell>
                  {record.clockInTime.toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit" })}
                </TableCell>
                <TableCell>
                  {record.clockOutTime
                    ? record.clockOutTime.toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit" })
                    : "--:--"}
                </TableCell>
                <TableCell>{record.totalWorkMinutes ? formatWorkTime(record.totalWorkMinutes) : "--"}</TableCell>
                <TableCell>{record.overtimeMinutes ? formatWorkTime(record.overtimeMinutes) : "--"}</TableCell>
                <TableCell>
                  <Badge
                    variant={
                      record.status === "approved"
                        ? "default"
                        : record.status === "rejected"
                          ? "destructive"
                          : "outline"
                    }
                  >
                    {record.status === "approved" ? "承認済" : record.status === "rejected" ? "却下" : "未承認"}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Button variant="ghost" size="sm" className="float-right">
                    詳細 <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}
