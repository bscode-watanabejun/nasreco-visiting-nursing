"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Plus, Edit, Trash2, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Checkbox } from "@/components/ui/checkbox"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import type { InsuranceInfo, InsuranceType } from "@/lib/db/insurance-schema"

// モックデータ
const mockInsuranceData: InsuranceInfo[] = [
  {
    id: "ins-1",
    patientId: "patient-1",
    insuranceType: "medical",
    insuranceNumber: "12345678",
    insuranceName: "全国健康保険協会",
    insuredPerson: "佐藤 一郎",
    relationship: "本人",
    validFrom: new Date("2024-04-01"),
    validUntil: new Date("2025-03-31"),
    copayRate: 0.3, // 3割負担
    isPublicExpense: false,
    isActive: true,
    createdAt: new Date("2024-04-01"),
    updatedAt: new Date("2024-04-01"),
  },
  {
    id: "ins-2",
    patientId: "patient-1",
    insuranceType: "nursing_care",
    insuranceNumber: "87654321",
    insuranceName: "介護保険",
    insuredPerson: "佐藤 一郎",
    relationship: "本人",
    validFrom: new Date("2024-04-01"),
    validUntil: new Date("2025-03-31"),
    copayRate: 0.1, // 1割負担
    isPublicExpense: false,
    isActive: true,
    createdAt: new Date("2024-04-01"),
    updatedAt: new Date("2024-04-01"),
  },
  {
    id: "ins-3",
    patientId: "patient-2",
    insuranceType: "medical",
    insuranceNumber: "23456789",
    insuranceName: "国民健康保険",
    insuredPerson: "田中 正男",
    relationship: "本人",
    validFrom: new Date("2024-04-01"),
    validUntil: new Date("2025-03-31"),
    copayRate: 0.3, // 3割負担
    isPublicExpense: true,
    publicExpenseType: "高齢者医療",
    publicExpenseNumber: "98765",
    publicExpenseRate: 0.2, // 2割公費負担
    isActive: true,
    createdAt: new Date("2024-04-01"),
    updatedAt: new Date("2024-04-01"),
  },
]

// モックデータ - 患者情報
const mockPatients = [
  { id: "patient-1", name: "佐藤 一郎", age: 68 },
  { id: "patient-2", name: "田中 正男", age: 75 },
  { id: "patient-3", name: "鈴木 良子", age: 82 },
  { id: "patient-4", name: "佐藤 花子", age: 45 },
  { id: "patient-5", name: "高橋 健太", age: 58 },
]

// 保険種別の表示名マッピング
const insuranceTypeLabels: Record<InsuranceType, string> = {
  medical: "医療保険",
  nursing_care: "介護保険",
  self_pay: "自費",
  other: "その他",
}

interface InsuranceManagerProps {
  patientId?: string
  readOnly?: boolean
}

export function InsuranceManager({ patientId, readOnly = false }: InsuranceManagerProps) {
  const router = useRouter()
  const [insuranceData, setInsuranceData] = useState<InsuranceInfo[]>([])
  const [filteredInsuranceData, setFilteredInsuranceData] = useState<InsuranceInfo[]>([])
  const [selectedPatientId, setSelectedPatientId] = useState<string>(patientId || "")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [selectedInsurance, setSelectedInsurance] = useState<InsuranceInfo | null>(null)
  const [formData, setFormData] = useState<Partial<InsuranceInfo>>({
    insuranceType: "medical",
    copayRate: 0.3,
    isPublicExpense: false,
    isActive: true,
    validFrom: new Date(),
  })
  const [validationErrors, setValidationErrors] = useState<string[]>([])

  // 初期データの読み込み
  useEffect(() => {
    // 実際の実装ではAPIからデータを取得
    setInsuranceData(mockInsuranceData)
  }, [])

  // 患者IDが変更されたときのフィルタリング
  useEffect(() => {
    if (selectedPatientId) {
      setFilteredInsuranceData(insuranceData.filter((ins) => ins.patientId === selectedPatientId))
    } else {
      setFilteredInsuranceData(insuranceData)
    }
  }, [selectedPatientId, insuranceData])

  // 保険情報の追加ダイアログを開く
  const handleOpenAddDialog = () => {
    setFormData({
      insuranceType: "medical",
      copayRate: 0.3,
      isPublicExpense: false,
      isActive: true,
      validFrom: new Date(),
      patientId: selectedPatientId,
    })
    setValidationErrors([])
    setIsAddDialogOpen(true)
  }

  // 保険情報の編集ダイアログを開く
  const handleOpenEditDialog = (insurance: InsuranceInfo) => {
    setSelectedInsurance(insurance)
    setFormData({
      ...insurance,
      validFrom: new Date(insurance.validFrom),
      validUntil: insurance.validUntil ? new Date(insurance.validUntil) : undefined,
    })
    setValidationErrors([])
    setIsEditDialogOpen(true)
  }

  // 保険情報の削除ダイアログを開く
  const handleOpenDeleteDialog = (insurance: InsuranceInfo) => {
    setSelectedInsurance(insurance)
    setIsDeleteDialogOpen(true)
  }

  // フォームデータの変更ハンドラ
  const handleFormChange = (field: keyof InsuranceInfo, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  // バリデーション
  const validateForm = (): boolean => {
    const errors: string[] = []

    if (!formData.insuranceType) {
      errors.push("保険種別を選択してください")
    }

    if (!formData.patientId) {
      errors.push("患者を選択してください")
    }

    if (formData.insuranceType !== "self_pay" && !formData.insuranceNumber) {
      errors.push("保険証番号を入力してください")
    }

    if (!formData.validFrom) {
      errors.push("有効期間（開始）を入力してください")
    }

    if (formData.validFrom && formData.validUntil && formData.validFrom > formData.validUntil) {
      errors.push("有効期間の開始日は終了日より前である必要があります")
    }

    if (formData.copayRate === undefined || formData.copayRate < 0 || formData.copayRate > 1) {
      errors.push("自己負担割合は0から1の間で入力してください")
    }

    if (formData.isPublicExpense) {
      if (!formData.publicExpenseType) {
        errors.push("公費負担の種類を入力してください")
      }
      if (!formData.publicExpenseNumber) {
        errors.push("公費負担者番号を入力してください")
      }
      if (
        formData.publicExpenseRate === undefined ||
        formData.publicExpenseRate < 0 ||
        formData.publicExpenseRate > 1
      ) {
        errors.push("公費負担割合は0から1の間で入力してください")
      }
    }

    setValidationErrors(errors)
    return errors.length === 0
  }

  // 保険情報の追加
  const handleAddInsurance = () => {
    if (!validateForm()) return

    const newInsurance: InsuranceInfo = {
      id: `ins-${Date.now()}`,
      patientId: formData.patientId!,
      insuranceType: formData.insuranceType as InsuranceType,
      insuranceNumber: formData.insuranceNumber,
      insuranceName: formData.insuranceName,
      insuredPerson: formData.insuredPerson,
      relationship: formData.relationship,
      validFrom: formData.validFrom!,
      validUntil: formData.validUntil,
      copayRate: formData.copayRate!,
      isPublicExpense: formData.isPublicExpense,
      publicExpenseType: formData.publicExpenseType,
      publicExpenseNumber: formData.publicExpenseNumber,
      publicExpenseRate: formData.publicExpenseRate,
      isActive: formData.isActive ?? true,
      note: formData.note,
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    // 実際の実装ではAPIを呼び出して保存
    setInsuranceData([...insuranceData, newInsurance])
    setIsAddDialogOpen(false)
  }

  // 保険情報の更新
  const handleUpdateInsurance = () => {
    if (!validateForm() || !selectedInsurance) return

    const updatedInsurance: InsuranceInfo = {
      ...selectedInsurance,
      insuranceType: formData.insuranceType as InsuranceType,
      insuranceNumber: formData.insuranceNumber,
      insuranceName: formData.insuranceName,
      insuredPerson: formData.insuredPerson,
      relationship: formData.relationship,
      validFrom: formData.validFrom!,
      validUntil: formData.validUntil,
      copayRate: formData.copayRate!,
      isPublicExpense: formData.isPublicExpense,
      publicExpenseType: formData.publicExpenseType,
      publicExpenseNumber: formData.publicExpenseNumber,
      publicExpenseRate: formData.publicExpenseRate,
      isActive: formData.isActive ?? true,
      note: formData.note,
      updatedAt: new Date(),
    }

    // 実際の実装ではAPIを呼び出して保存
    setInsuranceData(insuranceData.map((ins) => (ins.id === selectedInsurance.id ? updatedInsurance : ins)))
    setIsEditDialogOpen(false)
  }

  // 保険情報の削除
  const handleDeleteInsurance = () => {
    if (!selectedInsurance) return

    // 実際の実装ではAPIを呼び出して削除
    setInsuranceData(insuranceData.filter((ins) => ins.id !== selectedInsurance.id))
    setIsDeleteDialogOpen(false)
  }

  // 保険情報の有効期限チェック
  const isInsuranceExpired = (insurance: InsuranceInfo): boolean => {
    if (!insurance.validUntil) return false
    return new Date() > new Date(insurance.validUntil)
  }

  // 保険情報の有効期限が近いかチェック
  const isInsuranceExpiringSoon = (insurance: InsuranceInfo): boolean => {
    if (!insurance.validUntil) return false
    const validUntil = new Date(insurance.validUntil)
    const today = new Date()
    const diffTime = validUntil.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays > 0 && diffDays <= 30 // 30日以内に有効期限が切れる
  }

  return (
    <div className="space-y-6">
      {!patientId && (
        <div className="flex items-center space-x-4">
          <div className="flex-1">
            <Label htmlFor="patient-select">患者選択</Label>
            <Select value={selectedPatientId} onValueChange={setSelectedPatientId}>
              <SelectTrigger id="patient-select">
                <SelectValue placeholder="患者を選択してください" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">すべての患者</SelectItem>
                {mockPatients.map((patient) => (
                  <SelectItem key={patient.id} value={patient.id}>
                    {patient.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {!readOnly && (
            <Button onClick={handleOpenAddDialog} className="mt-6">
              <Plus className="mr-2 h-4 w-4" />
              保険情報追加
            </Button>
          )}
        </div>
      )}

      {selectedPatientId && filteredInsuranceData.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-10">
            <p className="text-muted-foreground mb-4">保険情報が登録されていません</p>
            {!readOnly && (
              <Button onClick={handleOpenAddDialog}>
                <Plus className="mr-2 h-4 w-4" />
                保険情報を追加
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        {filteredInsuranceData.map((insurance) => (
          <Card
            key={insurance.id}
            className={`${!insurance.isActive ? "opacity-60" : ""} ${
              isInsuranceExpired(insurance) ? "border-destructive" : ""
            }`}
          >
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{insuranceTypeLabels[insurance.insuranceType]}</CardTitle>
                <div className="flex items-center space-x-2">
                  {!insurance.isActive && <Badge variant="outline">無効</Badge>}
                  {isInsuranceExpired(insurance) && <Badge variant="destructive">期限切れ</Badge>}
                  {isInsuranceExpiringSoon(insurance) && !isInsuranceExpired(insurance) && (
                    <Badge variant="secondary">
                      <AlertTriangle className="mr-1 h-3 w-3" />
                      期限間近
                    </Badge>
                  )}
                  <Badge>{`${insurance.copayRate * 100}%負担`}</Badge>
                </div>
              </div>
              <CardDescription>
                {insurance.insuranceName || ""} {insurance.insuranceNumber ? `#${insurance.insuranceNumber}` : ""}
              </CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="space-y-1 text-sm">
                {insurance.insuredPerson && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">被保険者:</span>
                    <span>
                      {insurance.insuredPerson}
                      {insurance.relationship && insurance.relationship !== "本人" && ` (${insurance.relationship})`}
                    </span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">有効期間:</span>
                  <span>
                    {format(new Date(insurance.validFrom), "yyyy/MM/dd", { locale: ja })}
                    {insurance.validUntil &&
                      ` 〜 ${format(new Date(insurance.validUntil), "yyyy/MM/dd", { locale: ja })}`}
                  </span>
                </div>
                {insurance.isPublicExpense && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">公費負担:</span>
                      <span>{insurance.publicExpenseType}</span>
                    </div>
                    {insurance.publicExpenseNumber && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">公費番号:</span>
                        <span>{insurance.publicExpenseNumber}</span>
                      </div>
                    )}
                    {insurance.publicExpenseRate !== undefined && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">公費負担割合:</span>
                        <span>{insurance.publicExpenseRate * 100}%</span>
                      </div>
                    )}
                  </>
                )}
                {insurance.note && (
                  <div className="mt-2 text-muted-foreground">
                    <p>備考: {insurance.note}</p>
                  </div>
                )}
              </div>
            </CardContent>
            {!readOnly && (
              <CardFooter className="flex justify-end pt-2">
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={() => handleOpenEditDialog(insurance)}>
                    <Edit className="mr-2 h-4 w-4" />
                    編集
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleOpenDeleteDialog(insurance)}>
                    <Trash2 className="mr-2 h-4 w-4" />
                    削除
                  </Button>
                </div>
              </CardFooter>
            )}
          </Card>
        ))}
      </div>

      {/* 保険情報追加ダイアログ */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>保険情報の追加</DialogTitle>
            <DialogDescription>患者の保険情報を登録します</DialogDescription>
          </DialogHeader>

          {validationErrors.length > 0 && (
            <Alert variant="destructive" className="mt-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>入力エラー</AlertTitle>
              <AlertDescription>
                <ul className="list-disc list-inside">
                  {validationErrors.map((error, index) => (
                    <li key={index}>{error}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="patient">患者</Label>
                <Select
                  value={formData.patientId || ""}
                  onValueChange={(value) => handleFormChange("patientId", value)}
                  disabled={!!patientId}
                >
                  <SelectTrigger id="patient">
                    <SelectValue placeholder="患者を選択してください" />
                  </SelectTrigger>
                  <SelectContent>
                    {mockPatients.map((patient) => (
                      <SelectItem key={patient.id} value={patient.id}>
                        {patient.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="insurance-type">保険種別</Label>
                <Select
                  value={formData.insuranceType || ""}
                  onValueChange={(value) => handleFormChange("insuranceType", value)}
                >
                  <SelectTrigger id="insurance-type">
                    <SelectValue placeholder="保険種別を選択してください" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(insuranceTypeLabels).map(([value, label]) => (
                      <SelectItem key={value} value={value}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {formData.insuranceType !== "self_pay" && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="insurance-number">保険証番号</Label>
                    <Input
                      id="insurance-number"
                      value={formData.insuranceNumber || ""}
                      onChange={(e) => handleFormChange("insuranceNumber", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="insurance-name">保険者名</Label>
                    <Input
                      id="insurance-name"
                      value={formData.insuranceName || ""}
                      onChange={(e) => handleFormChange("insuranceName", e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="insured-person">被保険者名</Label>
                    <Input
                      id="insured-person"
                      value={formData.insuredPerson || ""}
                      onChange={(e) => handleFormChange("insuredPerson", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="relationship">続柄</Label>
                    <Select
                      value={formData.relationship || ""}
                      onValueChange={(value) => handleFormChange("relationship", value)}
                    >
                      <SelectTrigger id="relationship">
                        <SelectValue placeholder="続柄を選択してください" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="本人">本人</SelectItem>
                        <SelectItem value="配偶者">配偶者</SelectItem>
                        <SelectItem value="子">子</SelectItem>
                        <SelectItem value="父">父</SelectItem>
                        <SelectItem value="母">母</SelectItem>
                        <SelectItem value="その他">その他</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="valid-from">有効期間（開始）</Label>
                <Input
                  id="valid-from"
                  type="date"
                  value={formData.validFrom ? format(new Date(formData.validFrom), "yyyy-MM-dd") : ""}
                  onChange={(e) => handleFormChange("validFrom", e.target.value ? new Date(e.target.value) : undefined)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="valid-until">有効期間（終了）</Label>
                <Input
                  id="valid-until"
                  type="date"
                  value={formData.validUntil ? format(new Date(formData.validUntil), "yyyy-MM-dd") : ""}
                  onChange={(e) =>
                    handleFormChange("validUntil", e.target.value ? new Date(e.target.value) : undefined)
                  }
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="copay-rate">自己負担割合</Label>
                <Select
                  value={formData.copayRate?.toString() || ""}
                  onValueChange={(value) => handleFormChange("copayRate", Number.parseFloat(value))}
                >
                  <SelectTrigger id="copay-rate">
                    <SelectValue placeholder="自己負担割合を選択してください" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">0%</SelectItem>
                    <SelectItem value="0.1">10%</SelectItem>
                    <SelectItem value="0.2">20%</SelectItem>
                    <SelectItem value="0.3">30%</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center space-x-2 pt-8">
                <Checkbox
                  id="is-active"
                  checked={formData.isActive}
                  onCheckedChange={(checked) => handleFormChange("isActive", checked)}
                />
                <Label htmlFor="is-active">有効</Label>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="is-public-expense"
                checked={formData.isPublicExpense}
                onCheckedChange={(checked) => handleFormChange("isPublicExpense", checked)}
              />
              <Label htmlFor="is-public-expense">公費負担あり</Label>
            </div>

            {formData.isPublicExpense && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="public-expense-type">公費負担の種類</Label>
                  <Select
                    value={formData.publicExpenseType || ""}
                    onValueChange={(value) => handleFormChange("publicExpenseType", value)}
                  >
                    <SelectTrigger id="public-expense-type">
                      <SelectValue placeholder="公費負担の種類を選択してください" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="高齢者医療">高齢者医療</SelectItem>
                      <SelectItem value="障害者医療">障害者医療</SelectItem>
                      <SelectItem value="生活保護">生活保護</SelectItem>
                      <SelectItem value="その他">その他</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="public-expense-number">公費負担者番号</Label>
                  <Input
                    id="public-expense-number"
                    value={formData.publicExpenseNumber || ""}
                    onChange={(e) => handleFormChange("publicExpenseNumber", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="public-expense-rate">公費負担割合</Label>
                  <Select
                    value={formData.publicExpenseRate?.toString() || ""}
                    onValueChange={(value) => handleFormChange("publicExpenseRate", Number.parseFloat(value))}
                  >
                    <SelectTrigger id="public-expense-rate">
                      <SelectValue placeholder="公費負担割合を選択してください" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0.1">10%</SelectItem>
                      <SelectItem value="0.2">20%</SelectItem>
                      <SelectItem value="0.3">30%</SelectItem>
                      <SelectItem value="0.5">50%</SelectItem>
                      <SelectItem value="0.7">70%</SelectItem>
                      <SelectItem value="0.8">80%</SelectItem>
                      <SelectItem value="0.9">90%</SelectItem>
                      <SelectItem value="1">100%</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="note">備考</Label>
              <Input id="note" value={formData.note || ""} onChange={(e) => handleFormChange("note", e.target.value)} />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              キャンセル
            </Button>
            <Button onClick={handleAddInsurance}>保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 保険情報編集ダイアログ */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>保険情報の編集</DialogTitle>
            <DialogDescription>保険情報を更新します</DialogDescription>
          </DialogHeader>

          {validationErrors.length > 0 && (
            <Alert variant="destructive" className="mt-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>入力エラー</AlertTitle>
              <AlertDescription>
                <ul className="list-disc list-inside">
                  {validationErrors.map((error, index) => (
                    <li key={index}>{error}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-patient">患者</Label>
                <Input
                  id="edit-patient"
                  value={mockPatients.find((p) => p.id === formData.patientId)?.name || ""}
                  disabled
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-insurance-type">保険種別</Label>
                <Select
                  value={formData.insuranceType || ""}
                  onValueChange={(value) => handleFormChange("insuranceType", value)}
                >
                  <SelectTrigger id="edit-insurance-type">
                    <SelectValue placeholder="保険種別を選択してください" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(insuranceTypeLabels).map(([value, label]) => (
                      <SelectItem key={value} value={value}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {formData.insuranceType !== "self_pay" && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-insurance-number">保険証番号</Label>
                    <Input
                      id="edit-insurance-number"
                      value={formData.insuranceNumber || ""}
                      onChange={(e) => handleFormChange("insuranceNumber", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="edit-insurance-name">保険者名</Label>
                    <Input
                      id="edit-insurance-name"
                      value={formData.insuranceName || ""}
                      onChange={(e) => handleFormChange("insuranceName", e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-insured-person">被保険者名</Label>
                    <Input
                      id="edit-insured-person"
                      value={formData.insuredPerson || ""}
                      onChange={(e) => handleFormChange("insuredPerson", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="edit-relationship">続柄</Label>
                    <Select
                      value={formData.relationship || ""}
                      onValueChange={(value) => handleFormChange("relationship", value)}
                    >
                      <SelectTrigger id="edit-relationship">
                        <SelectValue placeholder="続柄を選択してください" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="本人">本人</SelectItem>
                        <SelectItem value="配偶者">配偶者</SelectItem>
                        <SelectItem value="子">子</SelectItem>
                        <SelectItem value="父">父</SelectItem>
                        <SelectItem value="母">母</SelectItem>
                        <SelectItem value="その他">その他</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-valid-from">有効期間（開始）</Label>
                <Input
                  id="edit-valid-from"
                  type="date"
                  value={formData.validFrom ? format(new Date(formData.validFrom), "yyyy-MM-dd") : ""}
                  onChange={(e) => handleFormChange("validFrom", e.target.value ? new Date(e.target.value) : undefined)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-valid-until">有効期間（終了）</Label>
                <Input
                  id="edit-valid-until"
                  type="date"
                  value={formData.validUntil ? format(new Date(formData.validUntil), "yyyy-MM-dd") : ""}
                  onChange={(e) =>
                    handleFormChange("validUntil", e.target.value ? new Date(e.target.value) : undefined)
                  }
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-copay-rate">自己負担割合</Label>
                <Select
                  value={formData.copayRate?.toString() || ""}
                  onValueChange={(value) => handleFormChange("copayRate", Number.parseFloat(value))}
                >
                  <SelectTrigger id="edit-copay-rate">
                    <SelectValue placeholder="自己負担割合を選択してください" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">0%</SelectItem>
                    <SelectItem value="0.1">10%</SelectItem>
                    <SelectItem value="0.2">20%</SelectItem>
                    <SelectItem value="0.3">30%</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center space-x-2 pt-8">
                <Checkbox
                  id="edit-is-active"
                  checked={formData.isActive}
                  onCheckedChange={(checked) => handleFormChange("isActive", checked)}
                />
                <Label htmlFor="edit-is-active">有効</Label>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="edit-is-public-expense"
                checked={formData.isPublicExpense}
                onCheckedChange={(checked) => handleFormChange("isPublicExpense", checked)}
              />
              <Label htmlFor="edit-is-public-expense">公費負担あり</Label>
            </div>

            {formData.isPublicExpense && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-public-expense-type">公費負担の種類</Label>
                  <Select
                    value={formData.publicExpenseType || ""}
                    onValueChange={(value) => handleFormChange("publicExpenseType", value)}
                  >
                    <SelectTrigger id="edit-public-expense-type">
                      <SelectValue placeholder="公費負担の種類を選択してください" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="高齢者医療">高齢者医療</SelectItem>
                      <SelectItem value="障害者医療">障害者医療</SelectItem>
                      <SelectItem value="生活保護">生活保護</SelectItem>
                      <SelectItem value="その他">その他</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-public-expense-number">公費負担者番号</Label>
                  <Input
                    id="edit-public-expense-number"
                    value={formData.publicExpenseNumber || ""}
                    onChange={(e) => handleFormChange("publicExpenseNumber", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-public-expense-rate">公費負担割合</Label>
                  <Select
                    value={formData.publicExpenseRate?.toString() || ""}
                    onValueChange={(value) => handleFormChange("publicExpenseRate", Number.parseFloat(value))}
                  >
                    <SelectTrigger id="edit-public-expense-rate">
                      <SelectValue placeholder="公費負担割合を選択してください" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0.1">10%</SelectItem>
                      <SelectItem value="0.2">20%</SelectItem>
                      <SelectItem value="0.3">30%</SelectItem>
                      <SelectItem value="0.5">50%</SelectItem>
                      <SelectItem value="0.7">70%</SelectItem>
                      <SelectItem value="0.8">80%</SelectItem>
                      <SelectItem value="0.9">90%</SelectItem>
                      <SelectItem value="1">100%</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="edit-note">備考</Label>
              <Input
                id="edit-note"
                value={formData.note || ""}
                onChange={(e) => handleFormChange("note", e.target.value)}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              キャンセル
            </Button>
            <Button onClick={handleUpdateInsurance}>更新</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 保険情報削除確認ダイアログ */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>保険情報の削除</DialogTitle>
            <DialogDescription>この保険情報を削除してもよろしいですか？</DialogDescription>
          </DialogHeader>
          {selectedInsurance && (
            <div className="py-4">
              <p className="font-medium">{insuranceTypeLabels[selectedInsurance.insuranceType]}</p>
              <p className="text-sm text-muted-foreground">
                {selectedInsurance.insuranceName || ""}{" "}
                {selectedInsurance.insuranceNumber ? `#${selectedInsurance.insuranceNumber}` : ""}
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                有効期間: {format(new Date(selectedInsurance.validFrom), "yyyy/MM/dd", { locale: ja })}
                {selectedInsurance.validUntil &&
                  ` 〜 ${format(new Date(selectedInsurance.validUntil), "yyyy/MM/dd", {
                    locale: ja,
                  })}`}
              </p>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              キャンセル
            </Button>
            <Button variant="destructive" onClick={handleDeleteInsurance}>
              削除
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
