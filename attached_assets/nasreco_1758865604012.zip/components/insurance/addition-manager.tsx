"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Plus, Edit, Trash2, AlertTriangle, Check, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import type { AdditionItem, InsuranceType, PatientAddition } from "@/lib/db/insurance-schema"

// モックデータ - 加算項目
const mockAdditionItems: AdditionItem[] = [
  {
    id: "add-1",
    code: "A001",
    name: "緊急時訪問看護加算",
    description: "緊急時の訪問に対する加算",
    insuranceType: ["medical", "nursing_care"],
    unitPrice: 5400,
    calculationType: "per_month",
    requiresApproval: true,
    requiresDocument: true,
    requiredDocumentType: "緊急時訪問看護加算同意書",
    conditions: ["24時間連絡体制の確保", "緊急時訪問看護の体制確保"],
    isActive: true,
    validFrom: new Date("2024-04-01"),
    createdAt: new Date("2024-04-01"),
    updatedAt: new Date("2024-04-01"),
  },
  {
    id: "add-2",
    code: "A002",
    name: "特別管理加算",
    description: "特別な管理を必要とする患者に対する加算",
    insuranceType: ["medical", "nursing_care"],
    unitPrice: 5000,
    calculationType: "per_month",
    requiresApproval: true,
    requiresDocument: true,
    requiredDocumentType: "特別管理加算算定同意書",
    conditions: ["特別な管理を必要とする状態", "24時間連絡体制の確保"],
    isActive: true,
    validFrom: new Date("2024-04-01"),
    createdAt: new Date("2024-04-01"),
    updatedAt: new Date("2024-04-01"),
  },
  {
    id: "add-3",
    code: "A003",
    name: "夜間・早朝訪問看護加算",
    description: "夜間または早朝の時間帯に訪問した場合の加算",
    insuranceType: ["medical", "nursing_care"],
    unitPrice: 2500,
    calculationType: "per_visit",
    requiresApproval: false,
    requiresDocument: false,
    conditions: ["夜間（18時〜22時）または早朝（6時〜8時）の時間帯に訪問"],
    isActive: true,
    validFrom: new Date("2024-04-01"),
    createdAt: new Date("2024-04-01"),
    updatedAt: new Date("2024-04-01"),
  },
  {
    id: "add-4",
    code: "A004",
    name: "深夜訪問看護加算",
    description: "深夜の時間帯に訪問した場合の加算",
    insuranceType: ["medical", "nursing_care"],
    unitPrice: 5000,
    calculationType: "per_visit",
    requiresApproval: false,
    requiresDocument: false,
    conditions: ["深夜（22時〜6時）の時間帯に訪問"],
    isActive: true,
    validFrom: new Date("2024-04-01"),
    createdAt: new Date("2024-04-01"),
    updatedAt: new Date("2024-04-01"),
  },
  {
    id: "add-5",
    code: "A005",
    name: "長時間訪問看護加算",
    description: "1回の訪問看護の時間が長時間に及ぶ場合の加算",
    insuranceType: ["medical", "nursing_care"],
    unitPrice: 3000,
    calculationType: "per_visit",
    requiresApproval: true,
    requiresDocument: false,
    conditions: ["1回の訪問看護の時間が90分を超える場合"],
    isActive: true,
    validFrom: new Date("2024-04-01"),
    createdAt: new Date("2024-04-01"),
    updatedAt: new Date("2024-04-01"),
  },
]

// モックデータ - 患者の加算適用情報
const mockPatientAdditions: PatientAddition[] = [
  {
    id: "pa-1",
    patientId: "patient-1",
    additionId: "add-1",
    isApplied: true,
    appliedFrom: new Date("2024-04-01"),
    approvedBy: "user-1",
    approvedAt: new Date("2024-04-01"),
    documentId: "doc-1",
    createdAt: new Date("2024-04-01"),
    updatedAt: new Date("2024-04-01"),
  },
  {
    id: "pa-2",
    patientId: "patient-1",
    additionId: "add-2",
    isApplied: true,
    appliedFrom: new Date("2024-04-01"),
    approvedBy: "user-1",
    approvedAt: new Date("2024-04-01"),
    documentId: "doc-2",
    createdAt: new Date("2024-04-01"),
    updatedAt: new Date("2024-04-01"),
  },
  {
    id: "pa-3",
    patientId: "patient-2",
    additionId: "add-1",
    isApplied: true,
    appliedFrom: new Date("2024-04-01"),
    approvedBy: "user-1",
    approvedAt: new Date("2024-04-01"),
    documentId: "doc-3",
    createdAt: new Date("2024-04-01"),
    updatedAt: new Date("2024-04-01"),
  },
]

// モックデータ - 患者情報
const mockPatients = [
  { id: "patient-1", name: "佐藤 一郎", age: 68 },
  { id: "patient-2", name: "田中 正男", age: 75 },
  { id: "patient-3", name: "鈴木 良子", age: 82 },
  { id: "patient-4", name: "佐藤 花子", age: 45 },
  { id: "patient-5", name: "高橋 健太", age: 58 },
]

// 保険種別の表示名マッピング
const insuranceTypeLabels: Record<InsuranceType, string> = {
  medical: "医療保険",
  nursing_care: "介護保険",
  self_pay: "自費",
  other: "その他",
}

// 計算方法の表示名マッピング
const calculationTypeLabels: Record<string, string> = {
  per_visit: "訪問ごと",
  per_month: "月ごと",
  per_hour: "時間ごと",
  per_procedure: "処置ごと",
}

interface AdditionManagerProps {
  patientId?: string
  readOnly?: boolean
  mode?: "master" | "patient" // master: 加算マスタ管理, patient: 患者ごとの加算管理
}

export function AdditionManager({ patientId, readOnly = false, mode = "master" }: AdditionManagerProps) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<"all" | "medical" | "nursing_care">("all")
  const [additionItems, setAdditionItems] = useState<AdditionItem[]>([])
  const [filteredAdditionItems, setFilteredAdditionItems] = useState<AdditionItem[]>([])
  const [patientAdditions, setPatientAdditions] = useState<PatientAddition[]>([])
  const [selectedPatientId, setSelectedPatientId] = useState<string>(patientId || "")
  const [searchQuery, setSearchQuery] = useState("")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isApplyDialogOpen, setIsApplyDialogOpen] = useState(false)
  const [selectedAddition, setSelectedAddition] = useState<AdditionItem | null>(null)
  const [selectedPatientAddition, setSelectedPatientAddition] = useState<PatientAddition | null>(null)
  const [formData, setFormData] = useState<Partial<AdditionItem>>({
    insuranceType: ["medical"],
    calculationType: "  = useState<Partial<AdditionItem>>({
    insuranceType: ["medical"],
    calculationType: "per_visit",
    requiresApproval: false,
    requiresDocument: false,
    isActive: true,
    validFrom: new Date(),
  })
  const [patientAdditionForm, setPatientAdditionForm] = useState<Partial<PatientAddition>>({
    isApplied: true,
    appliedFrom: new Date(),
  })
  const [validationErrors, setValidationErrors] = useState<string[]>([])

  // 初期データの読み込み
  useEffect(() => {
    // 実際の実装ではAPIからデータを取得
    setAdditionItems(mockAdditionItems)
    setPatientAdditions(mockPatientAdditions)
  }, [])

  // タブ切り替えとフィルタリング
  useEffect(() => {
    let filtered = [...additionItems]

    // 保険種別でフィルタリング
    if (activeTab !== "all") {
      \
      filtered = filtered.filter((item) => item.insuranceType.includes(activeTab as InsuranceType))
    }

    // 検索クエリでフィルタリング
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (item) =>
          item.name.toLowerCase().includes(query) ||
          item.code.toLowerCase().includes(query) ||
          item.description?.toLowerCase().includes(query),
      )
    }

    setFilteredAdditionItems(filtered)
  }, [additionItems, activeTab, searchQuery])

  // 加算項目の追加ダイアログを開く
  const handleOpenAddDialog = () => {
    setFormData({
      insuranceType: ["medical"],
      calculationType: "per_visit",
      requiresApproval: false,
      requiresDocument: false,
      isActive: true,
      validFrom: new Date(),
    })
    setValidationErrors([])
    setIsAddDialogOpen(true)
  }

  // 加算項目の編集ダイアログを開く
  const handleOpenEditDialog = (addition: AdditionItem) => {
    setSelectedAddition(addition)
    setFormData({
      ...addition,
      validFrom: new Date(addition.validFrom),
      validUntil: addition.validUntil ? new Date(addition.validUntil) : undefined,
    })
    setValidationErrors([])
    setIsEditDialogOpen(true)
  }

  // 加算項目の削除ダイアログを開く
  const handleOpenDeleteDialog = (addition: AdditionItem) => {
    setSelectedAddition(addition)
    setIsDeleteDialogOpen(true)
  }

  // 患者への加算適用ダイアログを開く
  const handleOpenApplyDialog = (addition: AdditionItem) => {
    setSelectedAddition(addition)

    // 既存の適用情報があれば取得
    const existingAddition = patientAdditions.find(
      (pa) => pa.patientId === selectedPatientId && pa.additionId === addition.id,
    )

    if (existingAddition) {
      setPatientAdditionForm({
        ...existingAddition,
        appliedFrom: new Date(existingAddition.appliedFrom),
        appliedUntil: existingAddition.appliedUntil ? new Date(existingAddition.appliedUntil) : undefined,
      })
      setSelectedPatientAddition(existingAddition)
    } else {
      setPatientAdditionForm({
        isApplied: true,
        appliedFrom: new Date(),
      })
      setSelectedPatientAddition(null)
    }

    setValidationErrors([])
    setIsApplyDialogOpen(true)
  }

  // フォームデータの変更ハンドラ
  const handleFormChange = (field: keyof AdditionItem, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  // 保険種別の選択ハンドラ
  const handleInsuranceTypeChange = (type: InsuranceType, checked: boolean) => {
    setFormData((prev) => {
      const currentTypes = prev.insuranceType || []
      if (checked) {
        return { ...prev, insuranceType: [...currentTypes, type] }
      } else {
        return { ...prev, insuranceType: currentTypes.filter((t) => t !== type) }
      }
    })
  }

  // 患者加算フォームの変更ハンドラ
  const handlePatientAdditionFormChange = (field: keyof PatientAddition, value: any) => {
    setPatientAdditionForm((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  // バリデーション
  const validateForm = (): boolean => {
    const errors: string[] = []

    if (!formData.code?.trim()) {
      errors.push("加算コードを入力してください")
    }

    if (!formData.name?.trim()) {
      errors.push("加算名を入力してください")
    }

    if (!formData.insuranceType || formData.insuranceType.length === 0) {
      errors.push("保険種別を選択してください")
    }

    if (formData.unitPrice === undefined || formData.unitPrice < 0) {
      errors.push("単価を入力してください")
    }

    if (!formData.calculationType) {
      errors.push("計算方法を選択してください")
    }

    if (!formData.validFrom) {
      errors.push("有効期間（開始）を入力してください")
    }

    if (formData.validFrom && formData.validUntil && formData.validFrom > formData.validUntil) {
      errors.push("有効期間の開始日は終了日より前である必要があります")
    }

    if (formData.requiresDocument && !formData.requiredDocumentType?.trim()) {
      errors.push("必要書類の種類を入力してください")
    }

    setValidationErrors(errors)
    return errors.length === 0
  }

  // 患者加算フォームのバリデーション
  const validatePatientAdditionForm = (): boolean => {
    const errors: string[] = []

    if (!selectedPatientId) {
      errors.push("患者を選択してください")
    }

    if (!selectedAddition) {
      errors.push("加算項目を選択してください")
    }

    if (!patientAdditionForm.appliedFrom) {
      errors.push("適用開始日を入力してください")
    }

    if (
      patientAdditionForm.appliedFrom &&
      patientAdditionForm.appliedUntil &&
      patientAdditionForm.appliedFrom > patientAdditionForm.appliedUntil
    ) {
      errors.push("適用開始日は終了日より前である必要があります")
    }

    setValidationErrors(errors)
    return errors.length === 0
  }

  // 加算項目の追加
  const handleAddAddition = () => {
    if (!validateForm()) return

    const newAddition: AdditionItem = {
      id: `add-${Date.now()}`,
      code: formData.code!,
      name: formData.name!,
      description: formData.description,
      insuranceType: formData.insuranceType as InsuranceType[],
      unitPrice: formData.unitPrice!,
      calculationType: formData.calculationType as "per_visit" | "per_month" | "per_hour" | "per_procedure",
      requiresApproval: formData.requiresApproval || false,
      requiresDocument: formData.requiresDocument || false,
      requiredDocumentType: formData.requiredDocumentType,
      maxTimesPerDay: formData.maxTimesPerDay,
      maxTimesPerMonth: formData.maxTimesPerMonth,
      conditions: formData.conditions,
      isActive: formData.isActive || true,
      validFrom: formData.validFrom!,
      validUntil: formData.validUntil,
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    // 実際の実装ではAPIを呼び出して保存
    setAdditionItems([...additionItems, newAddition])
    setIsAddDialogOpen(false)
  }

  // 加算項目の更新
  const handleUpdateAddition = () => {
    if (!validateForm() || !selectedAddition) return

    const updatedAddition: AdditionItem = {
      ...selectedAddition,
      code: formData.code!,
      name: formData.name!,
      description: formData.description,
      insuranceType: formData.insuranceType as InsuranceType[],
      unitPrice: formData.unitPrice!,
      calculationType: formData.calculationType as "per_visit" | "per_month" | "per_hour" | "per_procedure",
      requiresApproval: formData.requiresApproval || false,
      requiresDocument: formData.requiresDocument || false,
      requiredDocumentType: formData.requiredDocumentType,
      maxTimesPerDay: formData.maxTimesPerDay,
      maxTimesPerMonth: formData.maxTimesPerMonth,
      conditions: formData.conditions,
      isActive: formData.isActive || true,
      validFrom: formData.validFrom!,
      validUntil: formData.validUntil,
      updatedAt: new Date(),
    }

    // 実際の実装ではAPIを呼び出して保存
    setAdditionItems(additionItems.map((item) => (item.id === selectedAddition.id ? updatedAddition : item)))
    setIsEditDialogOpen(false)
  }

  // 加算項目の削除
  const handleDeleteAddition = () => {
    if (!selectedAddition) return

    // 実際の実装ではAPIを呼び出して削除
    setAdditionItems(additionItems.filter((item) => item.id !== selectedAddition.id))
    setIsDeleteDialogOpen(false)
  }

  // 患者への加算適用
  const handleApplyAddition = () => {
    if (!validatePatientAdditionForm() || !selectedAddition) return

    if (selectedPatientAddition) {
      // 既存の適用情報を更新
      const updatedPatientAddition: PatientAddition = {
        ...selectedPatientAddition,
        isApplied: patientAdditionForm.isApplied || false,
        appliedFrom: patientAdditionForm.appliedFrom!,
        appliedUntil: patientAdditionForm.appliedUntil,
        approvedBy: "current-user", // 実際の実装では現在のユーザーIDを使用
        approvedAt: new Date(),
        documentId: patientAdditionForm.documentId,
        note: patientAdditionForm.note,
        updatedAt: new Date(),
      }

      // 実際の実装ではAPIを呼び出して保存
      setPatientAdditions(
        patientAdditions.map((item) => (item.id === selectedPatientAddition.id ? updatedPatientAddition : item)),
      )
    } else {
      // 新規の適用情報を作成
      const newPatientAddition: PatientAddition = {
        id: `pa-${Date.now()}`,
        patientId: selectedPatientId,
        additionId: selectedAddition.id,
        isApplied: patientAdditionForm.isApplied || false,
        appliedFrom: patientAdditionForm.appliedFrom!,
        appliedUntil: patientAdditionForm.appliedUntil,
        approvedBy: "current-user", // 実際の実装では現在のユーザーIDを使用
        approvedAt: new Date(),
        documentId: patientAdditionForm.documentId,
        note: patientAdditionForm.note,
        createdAt: new Date(),
        updatedAt: new Date(),
      }

      // 実際の実装ではAPIを呼び出して保存
      setPatientAdditions([...patientAdditions, newPatientAddition])
    }

    setIsApplyDialogOpen(false)
  }

  // 加算項目の有効期限チェック
  const isAdditionExpired = (addition: AdditionItem): boolean => {
    if (!addition.validUntil) return false
    return new Date() > new Date(addition.validUntil)
  }

  // 患者に適用されている加算かどうかチェック
  const isAppliedToPatient = (additionId: string): boolean => {
    return patientAdditions.some(
      (pa) => pa.patientId === selectedPatientId && pa.additionId === additionId && pa.isApplied,
    )
  }

  // 患者加算の有効期限チェック
  const isPatientAdditionExpired = (patientAddition: PatientAddition): boolean => {
    if (!patientAddition.appliedUntil) return false
    return new Date() > new Date(patientAddition.appliedUntil)
  }

  return (
    <div className="space-y-6">
      {mode === "master" ? (
        // 加算マスタ管理モード
        <>
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">加算項目管理</h2>
              <p className="text-muted-foreground">加算項目の登録・管理を行います</p>
            </div>
            {!readOnly && (
              <Button onClick={handleOpenAddDialog}>
                <Plus className="mr-2 h-4 w-4" />
                加算項目追加
              </Button>
            )}
          </div>

          <div className="flex items-center space-x-4">
            <div className="relative flex-1">
              <Input
                placeholder="加算項目を検索..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
              <TabsList>
                <TabsTrigger value="all">すべて</TabsTrigger>
                <TabsTrigger value="medical">医療保険</TabsTrigger>
                <TabsTrigger value="nursing_care">介護保険</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredAdditionItems.map((addition) => (
              <Card
                key={addition.id}
                className={`${!addition.isActive ? "opacity-60" : ""} ${
                  isAdditionExpired(addition) ? "border-destructive" : ""
                }`}
              >
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">
                      {addition.code}: {addition.name}
                    </CardTitle>
                    <div className="flex items-center space-x-2">
                      {!addition.isActive && <Badge variant="outline">無効</Badge>}
                      {isAdditionExpired(addition) && <Badge variant="destructive">期限切れ</Badge>}
                    </div>
                  </div>
                  <CardDescription>{addition.description}</CardDescription>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">単価:</span>
                      <span>{addition.unitPrice.toLocaleString()}円</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">計算方法:</span>
                      <span>{calculationTypeLabels[addition.calculationType]}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">保険種別:</span>
                      <span>{addition.insuranceType.map((type) => insuranceTypeLabels[type]).join(", ")}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">有効期間:</span>
                      <span>
                        {format(new Date(addition.validFrom), "yyyy/MM/dd", { locale: ja })}
                        {addition.validUntil &&
                          ` 〜 ${format(new Date(addition.validUntil), "yyyy/MM/dd", {
                            locale: ja,
                          })}`}
                      </span>
                    </div>
                    {addition.requiresApproval && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">承認必要:</span>
                        <span>あり</span>
                      </div>
                    )}
                    {addition.requiresDocument && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">必要書類:</span>
                        <span>{addition.requiredDocumentType}</span>
                      </div>
                    )}
                    {(addition.maxTimesPerDay || addition.maxTimesPerMonth) && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">算定上限:</span>
                        <span>
                          {addition.maxTimesPerDay && `${addition.maxTimesPerDay}回/日`}
                          {addition.maxTimesPerDay && addition.maxTimesPerMonth && ", "}
                          {addition.maxTimesPerMonth && `${addition.maxTimesPerMonth}回/月`}
                        </span>
                      </div>
                    )}
                  </div>
                  {addition.conditions && addition.conditions.length > 0 && (
                    <div className="mt-2">
                      <p className="text-sm font-medium">算定条件:</p>
                      <ul className="text-sm text-muted-foreground list-disc list-inside">
                        {addition.conditions.map((condition, index) => (
                          <li key={index}>{condition}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
                {!readOnly && (
                  <CardFooter className="flex justify-end pt-2">
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" onClick={() => handleOpenEditDialog(addition)}>
                        <Edit className="mr-2 h-4 w-4" />
                        編集
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleOpenDeleteDialog(addition)}>
                        <Trash2 className="mr-2 h-4 w-4" />
                        削除
                      </Button>
                    </div>
                  </CardFooter>
                )}
              </Card>
            ))}
          </div>

          {filteredAdditionItems.length === 0 && (
            <div className="text-center py-10">
              <p className="text-muted-foreground">加算項目が見つかりません</p>
            </div>
          )}
        </>
      ) : (
        // 患者ごとの加算管理モード
        <>
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">患者加算管理</h2>
              <p className="text-muted-foreground">
                {selectedPatientId
                  ? `${mockPatients.find((p) => p.id === selectedPatientId)?.name}さんの加算管理`
                  : "患者ごとの加算適用状況を管理します"}
              </p>
            </div>
          </div>

          {!patientId && (
            <div className="flex items-center space-x-4 mb-6">
              <div className="flex-1">
                <Label htmlFor="patient-select">患者選択</Label>
                <Select value={selectedPatientId} onValueChange={setSelectedPatientId}>
                  <SelectTrigger id="patient-select">
                    <SelectValue placeholder="患者を選択してください" />
                  </SelectTrigger>
                  <SelectContent>
                    {mockPatients.map((patient) => (
                      <SelectItem key={patient.id} value={patient.id}>
                        {patient.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {selectedPatientId && (
            <>
              <div className="flex items-center space-x-4">
                <div className="relative flex-1">
                  <Input
                    placeholder="加算項目を検索..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
                  <TabsList>
                    <TabsTrigger value="all">すべて</TabsTrigger>
                    <TabsTrigger value="medical">医療保険</TabsTrigger>
                    <TabsTrigger value="nursing_care">介護保険</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredAdditionItems.map((addition) => {
                  const patientAddition = patientAdditions.find(
                    (pa) => pa.patientId === selectedPatientId && pa.additionId === addition.id,
                  )
                  const isApplied = patientAddition?.isApplied || false
                  const isExpired = patientAddition ? isPatientAdditionExpired(patientAddition) : false

                  return (
                    <Card
                      key={addition.id}
                      className={`${!addition.isActive ? "opacity-60" : ""} ${
                        isAdditionExpired(addition) ? "border-destructive" : ""
                      } ${isApplied ? "border-primary" : ""}`}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">
                            {addition.code}: {addition.name}
                          </CardTitle>
                          <div className="flex items-center space-x-2">
                            {isApplied && !isExpired && <Badge>適用中</Badge>}
                            {isApplied && isExpired && <Badge variant="destructive">期限切れ</Badge>}
                            {!isApplied && <Badge variant="outline">未適用</Badge>}
                          </div>
                        </div>
                        <CardDescription>{addition.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <div className="space-y-1 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">単価:</span>
                            <span>{addition.unitPrice.toLocaleString()}円</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">計算方法:</span>
                            <span>{calculationTypeLabels[addition.calculationType]}</span>
                          </div>
                          {patientAddition && (
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">適用期間:</span>
                              <span>
                                {format(new Date(patientAddition.appliedFrom), "yyyy/MM/dd", { locale: ja })}
                                {patientAddition.appliedUntil &&
                                  ` 〜 ${format(new Date(patientAddition.appliedUntil), "yyyy/MM/dd", {
                                    locale: ja,
                                  })}`}
                              </span>
                            </div>
                          )}
                          {addition.requiresDocument && (
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">必要書類:</span>
                              <span className="flex items-center">
                                {addition.requiredDocumentType}
                                {patientAddition?.documentId ? (
                                  <Check className="ml-1 h-4 w-4 text-green-500" />
                                ) : (
                                  <AlertTriangle className="ml-1 h-4 w-4 text-amber-500" />
                                )}
                              </span>
                            </div>
                          )}
                        </div>
                        {patientAddition?.note && (
                          <div className="mt-2 text-sm text-muted-foreground">
                            <p>備考: {patientAddition.note}</p>
                          </div>
                        )}
                      </CardContent>
                      {!readOnly && (
                        <CardFooter className="flex justify-end pt-2">
                          <Button
                            variant={isApplied ? "default" : "outline"}
                            size="sm"
                            onClick={() => handleOpenApplyDialog(addition)}
                          >
                            {isApplied ? "適用設定変更" : "適用設定"}
                          </Button>
                        </CardFooter>
                      )}
                    </Card>
                  )
                })}
              </div>

              {filteredAdditionItems.length === 0 && (
                <div className="text-center py-10">
                  <p className="text-muted-foreground">加算項目が見つかりません</p>
                </div>
              )}
            </>
          )}
        </>
      )}

      {/* 加算項目追加ダイアログ */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>加算項目の追加</DialogTitle>
            <DialogDescription>新しい加算項目を登録します</DialogDescription>
          </DialogHeader>

          {validationErrors.length > 0 && (
            <Alert variant="destructive" className="mt-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>入力エラー</AlertTitle>
              <AlertDescription>
                <ul className="list-disc list-inside">
                  {validationErrors.map((error, index) => (
                    <li key={index}>{error}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="code">加算コード</Label>
                <Input
                  id="code"
                  value={formData.code || ""}
                  onChange={(e) => handleFormChange("code", e.target.value)}
                  placeholder="例: A001"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">加算名</Label>
                <Input
                  id="name"
                  value={formData.name || ""}
                  onChange={(e) => handleFormChange("name", e.target.value)}
                  placeholder="例: 緊急時訪問看護加算"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">説明</Label>
              <Textarea
                id="description"
                value={formData.description || ""}
                onChange={(e) => handleFormChange("description", e.target.value)}
                placeholder="加算の説明を入力してください"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="unit-price">単価（円）</Label>
                <Input
                  id="unit-price"
                  type="number"
                  value={formData.unitPrice || ""}
                  onChange={(e) => handleFormChange("unitPrice", Number(e.target.value))}
                  placeholder="例: 5400"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="calculation-type">計算方法</Label>
                <Select
                  value={formData.calculationType || ""}
                  onValueChange={(value) => handleFormChange("calculationType", value)}
                >
                  <SelectTrigger id="calculation-type">
                    <SelectValue placeholder="計算方法を選択してください" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(calculationTypeLabels).map(([value, label]) => (
                      <SelectItem key={value} value={value}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>保険種別（複数選択可）</Label>
              <div className="flex space-x-4">
                {Object.entries(insuranceTypeLabels).map(([value, label]) => (
                  <div key={value} className="flex items-center space-x-2">
                    <Checkbox
                      id={`insurance-type-${value}`}
                      checked={(formData.insuranceType || []).includes(value as InsuranceType)}
                      onCheckedChange={(checked) => handleInsuranceTypeChange(value as InsuranceType, checked === true)}
                    />
                    <Label htmlFor={`insurance-type-${value}`}>{label}</Label>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="valid-from">有効期間（開始）</Label>
                <Input
                  id="valid-from"
                  type="date"
                  value={formData.validFrom ? format(new Date(formData.validFrom), "yyyy-MM-dd") : ""}
                  onChange={(e) => handleFormChange("validFrom", e.target.value ? new Date(e.target.value) : undefined)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="valid-until">有効期間（終了）</Label>
                <Input
                  id="valid-until"
                  type="date"
                  value={formData.validUntil ? format(new Date(formData.validUntil), "yyyy-MM-dd") : ""}
                  onChange={(e) =>
                    handleFormChange("validUntil", e.target.value ? new Date(e.target.value) : undefined)
                  }
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="max-times-per-day">1日あたりの最大回数</Label>
                <Input
                  id="max-times-per-day"
                  type="number"
                  value={formData.maxTimesPerDay || ""}
                  onChange={(e) =>
                    handleFormChange("maxTimesPerDay", e.target.value ? Number(e.target.value) : undefined)
                  }
                  placeholder="例: 1"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="max-times-per-month">月あたりの最大回数</Label>
                <Input
                  id="max-times-per-month"
                  type="number"
                  value={formData.maxTimesPerMonth || ""}
                  onChange={(e) =>
                    handleFormChange("maxTimesPerMonth", e.target.value ? Number(e.target.value) : undefined)
                  }
                  placeholder="例: 4"
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="requires-approval"
                checked={formData.requiresApproval}
                onCheckedChange={(checked) => handleFormChange("requiresApproval", checked)}
              />
              <Label htmlFor="requires-approval">承認が必要</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="requires-document"
                checked={formData.requiresDocument}
                onCheckedChange={(checked) => handleFormChange("requiresDocument", checked)}
              />
              <Label htmlFor="requires-document">書類が必要</Label>
            </div>

            {formData.requiresDocument && (
              <div className="space-y-2">
                <Label htmlFor="required-document-type">必要書類の種類</Label>
                <Input
                  id="required-document-type"
                  value={formData.requiredDocumentType || ""}
                  onChange={(e) => handleFormChange("requiredDocumentType", e.target.value)}
                  placeholder="例: 緊急時訪問看護加算同意書"
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="conditions">算定条件（1行に1つ）</Label>
              <Textarea
                id="conditions"
                value={(formData.conditions || []).join("\n")}
                onChange={(e) => handleFormChange("conditions", e.target.value.split("\n").filter(Boolean))}
                placeholder="例: 24時間連絡体制の確保"
                rows={3}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="is-active"
                checked={formData.isActive}
                onCheckedChange={(checked) => handleFormChange("isActive", checked)}
              />
              <Label htmlFor="is-active">有効</Label>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              キャンセル
            </Button>
            <Button onClick={handleAddAddition}>保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 加算項目編集ダイアログ */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>加算項目の編集</DialogTitle>
            <DialogDescription>加算項目情報を更新します</DialogDescription>
          </DialogHeader>

          {validationErrors.length > 0 && (
            <Alert variant="destructive" className="mt-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>入力エラー</AlertTitle>
              <AlertDescription>
                <ul className="list-disc list-inside">
                  {validationErrors.map((error, index) => (
                    <li key={index}>{error}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-code">加算コード</Label>
                <Input
                  id="edit-code"
                  value={formData.code || ""}
                  onChange={(e) => handleFormChange("code", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-name">加算名</Label>
                <Input
                  id="edit-name"
                  value={formData.name || ""}
                  onChange={(e) => handleFormChange("name", e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-description">説明</Label>
              <Textarea
                id="edit-description"
                value={formData.description || ""}
                onChange={(e) => handleFormChange("description", e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-unit-price">単価（円）</Label>
                <Input
                  id="edit-unit-price"
                  type="number"
                  value={formData.unitPrice || ""}
                  onChange={(e) => handleFormChange("unitPrice", Number(e.target.value))}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-calculation-type">計算方法</Label>
                <Select
                  value={formData.calculationType || ""}
                  onValueChange={(value) => handleFormChange("calculationType", value)}
                >
                  <SelectTrigger id="edit-calculation-type">
                    <SelectValue placeholder="計算方法を選択してください" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(calculationTypeLabels).map(([value, label]) => (
                      <SelectItem key={value} value={value}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>保険種別（複数選択可）</Label>
              <div className="flex space-x-4">
                {Object.entries(insuranceTypeLabels).map(([value, label]) => (
                  <div key={value} className="flex items-center space-x-2">
                    <Checkbox
                      id={`edit-insurance-type-${value}`}
                      checked={(formData.insuranceType || []).includes(value as InsuranceType)}
                      onCheckedChange={(checked) => handleInsuranceTypeChange(value as InsuranceType, checked === true)}
                    />
                    <Label htmlFor={`edit-insurance-type-${value}`}>{label}</Label>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-valid-from">有効期間（開始）</Label>
                <Input
                  id="edit-valid-from"
                  type="date"
                  value={formData.validFrom ? format(new Date(formData.validFrom), "yyyy-MM-dd") : ""}
                  onChange={(e) => handleFormChange("validFrom", e.target.value ? new Date(e.target.value) : undefined)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-valid-until">有効期間（終了）</Label>
                <Input
                  id="edit-valid-until"
                  type="date"
                  value={formData.validUntil ? format(new Date(formData.validUntil), "yyyy-MM-dd") : ""}
                  onChange={(e) =>
                    handleFormChange("validUntil", e.target.value ? new Date(e.target.value) : undefined)
                  }
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-max-times-per-day">1日あたりの最大回数</Label>
                <Input
                  id="edit-max-times-per-day"
                  type="number"
                  value={formData.maxTimesPerDay || ""}
                  onChange={(e) =>
                    handleFormChange("maxTimesPerDay", e.target.value ? Number(e.target.value) : undefined)
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-max-times-per-month">月あたりの最大回数</Label>
                <Input
                  id="edit-max-times-per-month"
                  type="number"
                  value={formData.maxTimesPerMonth || ""}
                  onChange={(e) =>
                    handleFormChange("maxTimesPerMonth", e.target.value ? Number(e.target.value) : undefined)
                  }
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="edit-requires-approval"
                checked={formData.requiresApproval}
                onCheckedChange={(checked) => handleFormChange("requiresApproval", checked)}
              />
              <Label htmlFor="edit-requires-approval">承認が必要</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="edit-requires-document"
                checked={formData.requiresDocument}
                onCheckedChange={(checked) => handleFormChange("requiresDocument", checked)}
              />
              <Label htmlFor="edit-requires-document">書類が必要</Label>
            </div>

            {formData.requiresDocument && (
              <div className="space-y-2">
                <Label htmlFor="edit-required-document-type">必要書類の種類</Label>
                <Input
                  id="edit-required-document-type"
                  value={formData.requiredDocumentType || ""}
                  onChange={(e) => handleFormChange("requiredDocumentType", e.target.value)}
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="edit-conditions">算定条件（1行に1つ）</Label>
              <Textarea
                id="edit-conditions"
                value={(formData.conditions || []).join("\n")}
                onChange={(e) => handleFormChange("conditions", e.target.value.split("\n").filter(Boolean))}
                rows={3}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="edit-is-active"
                checked={formData.isActive}
                onCheckedChange={(checked) => handleFormChange("isActive", checked)}
              />
              <Label htmlFor="edit-is-active">有効</Label>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              キャンセル
            </Button>
            <Button onClick={handleUpdateAddition}>更新</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 加算項目削除確認ダイアログ */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>加算項目の削除</DialogTitle>
            <DialogDescription>この加算項目を削除してもよろしいですか？</DialogDescription>
          </DialogHeader>
          {selectedAddition && (
            <div className="py-4">
              <p className="font-medium">
                {selectedAddition.code}: {selectedAddition.name}
              </p>
              <p className="text-sm text-muted-foreground">{selectedAddition.description}</p>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              キャンセル
            </Button>
            <Button variant="destructive" onClick={handleDeleteAddition}>
              削除
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 患者への加算適用ダイアログ */}
      <Dialog open={isApplyDialogOpen} onOpenChange={setIsApplyDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>加算適用設定</DialogTitle>
            <DialogDescription>患者への加算適用状況を設定します</DialogDescription>
          </DialogHeader>

          {validationErrors.length > 0 && (
            <Alert variant="destructive" className="mt-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>入力エラー</AlertTitle>
              <AlertDescription>
                <ul className="list-disc list-inside">
                  {validationErrors.map((error, index) => (
                    <li key={index}>{error}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          {selectedAddition && (
            <div className="py-4 space-y-4">
              <div>
                <p className="font-medium">
                  {selectedAddition.code}: {selectedAddition.name}
                </p>
                <p className="text-sm text-muted-foreground">{selectedAddition.description}</p>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="is-applied"
                  checked={patientAdditionForm.isApplied}
                  onCheckedChange={(checked) => handlePatientAdditionFormChange("isApplied", checked)}
                />
                <Label htmlFor="is-applied">この加算を適用する</Label>
              </div>

              {patientAdditionForm.isApplied && (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="applied-from">適用開始日</Label>
                      <Input
                        id="applied-from"
                        type="date"
                        value={
                          patientAdditionForm.appliedFrom
                            ? format(new Date(patientAdditionForm.appliedFrom), "yyyy-MM-dd")
                            : ""
                        }
                        onChange={(e) =>
                          handlePatientAdditionFormChange(
                            "appliedFrom",
                            e.target.value ? new Date(e.target.value) : undefined,
                          )
                        }
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="applied-until">適用終了日</Label>
                      <Input
                        id="applied-until"
                        type="date"
                        value={
                          patientAdditionForm.appliedUntil
                            ? format(new Date(patientAdditionForm.appliedUntil), "yyyy-MM-dd")
                            : ""
                        }
                        onChange={(e) =>
                          handlePatientAdditionFormChange(
                            "appliedUntil",
                            e.target.value ? new Date(e.target.value) : undefined,
                          )
                        }
                      />
                    </div>
                  </div>

                  {selectedAddition.requiresDocument && (
                    <div className="space-y-2">
                      <Label htmlFor="document-id">書類ID</Label>
                      <div className="flex space-x-2">
                        <Input
                          id="document-id"
                          value={patientAdditionForm.documentId || ""}
                          onChange={(e) => handlePatientAdditionFormChange("documentId", e.target.value)}
                          placeholder={`${selectedAddition.requiredDocumentType}のID`}
                        />
                        <Button variant="outline" size="sm">
                          <Search className="mr-2 h-4 w-4" />
                          検索
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground">必要書類: {selectedAddition.requiredDocumentType}</p>
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="note">備考</Label>
                    <Textarea
                      id="note"
                      value={patientAdditionForm.note || ""}
                      onChange={(e) => handlePatientAdditionFormChange("note", e.target.value)}
                      placeholder="備考があれば入力してください"
                    />
                  </div>
                </>
              )}
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsApplyDialogOpen(false)}>
              キャンセル
            </Button>
            <Button onClick={handleApplyAddition}>保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
