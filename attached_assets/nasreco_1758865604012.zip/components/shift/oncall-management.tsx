"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, Phone, Calendar, Clock, User, ChevronRight, AlertTriangle } from "lucide-react"
import { ShiftType, type Shift, type OncallRecord } from "@/lib/db/shift-schema"
import {
  checkOncallLimitExceeded,
  checkConsecutiveOncallDays,
  calculateUserMonthlyShiftSummary,
} from "@/lib/utils/shift-utils"

// モックデータ（実際の実装ではAPIから取得）
const mockUsers = [
  { id: "user1", name: "山田 花子" },
  { id: "user2", name: "佐藤 次郎" },
  { id: "user3", name: "鈴木 三郎" },
  { id: "user4", name: "田中 四郎" },
  { id: "user5", name: "高橋 五郎" },
]

// モックシフトデータ（実際の実装ではAPIから取得）
const mockShifts: Shift[] = [
  // 山田花子のシフト
  {
    id: "shift1",
    userId: "user1",
    date: new Date(2025, 3, 1), // 2025-04-01
    shiftType: ShiftType.ONCALL,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "shift2",
    userId: "user1",
    date: new Date(2025, 3, 2), // 2025-04-02
    shiftType: ShiftType.ONCALL,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "shift3",
    userId: "user1",
    date: new Date(2025, 3, 3), // 2025-04-03
    shiftType: ShiftType.ONCALL,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "shift4",
    userId: "user1",
    date: new Date(2025, 3, 10), // 2025-04-10
    shiftType: ShiftType.ONCALL,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },

  // 佐藤次郎のシフト
  {
    id: "shift5",
    userId: "user2",
    date: new Date(2025, 3, 4), // 2025-04-04
    shiftType: ShiftType.ONCALL,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "shift6",
    userId: "user2",
    date: new Date(2025, 3, 5), // 2025-04-05
    shiftType: ShiftType.ONCALL,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },

  // 鈴木三郎のシフト
  {
    id: "shift7",
    userId: "user3",
    date: new Date(2025, 3, 6), // 2025-04-06
    shiftType: ShiftType.ONCALL,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "shift8",
    userId: "user3",
    date: new Date(2025, 3, 7), // 2025-04-07
    shiftType: ShiftType.ONCALL,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
]

// モックオンコール記録
const mockOncallRecords: OncallRecord[] = [
  {
    id: "oncall1",
    userId: "user1",
    date: new Date(2025, 3, 1), // 2025-04-01
    startTime: new Date(2025, 3, 1, 17, 0), // 17:00
    endTime: new Date(2025, 3, 2, 9, 0), // 翌9:00
    callsReceived: 2,
    emergencyVisits: 1,
    note: "夜間に緊急訪問1件対応",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: "oncall2",
    userId: "user1",
    date: new Date(2025, 3, 2), // 2025-04-02
    startTime: new Date(2025, 3, 2, 17, 0), // 17:00
    endTime: new Date(2025, 3, 3, 9, 0), // 翌9:00
    callsReceived: 1,
    emergencyVisits: 0,
    note: "電話対応のみ",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]

// オンコール設定
const oncallSettings = {
  maxOncallsPerMonth: 5, // 月間最大オンコール回数
  maxConsecutiveDays: 3, // 連続オンコール最大日数
  oncallAllowance: 5000, // オンコール手当（円/日）
  emergencyVisitAllowance: 3000, // 緊急訪問手当（円/件）
}

interface OncallManagementProps {
  year?: number
  month?: number
}

export function OncallManagement({
  year = new Date().getFullYear(),
  month = new Date().getMonth() + 1,
}: OncallManagementProps) {
  const [shifts, setShifts] = useState<Shift[]>([])
  const [oncallRecords, setOncallRecords] = useState<OncallRecord[]>([])
  const [users, setUsers] = useState<{ id: string; name: string }[]>([])
  const [loading, setLoading] = useState(true)
  const [alerts, setAlerts] = useState<{ userId: string; type: string; message: string }[]>([])

  // データ取得（モック）
  useEffect(() => {
    // 実際の実装ではAPIからデータを取得
    setLoading(true)

    // モックデータをセット
    setTimeout(() => {
      setShifts(mockShifts)
      setOncallRecords(mockOncallRecords)
      setUsers(mockUsers)

      // アラートを計算
      const newAlerts: { userId: string; type: string; message: string }[] = []

      mockUsers.forEach((user) => {
        // 月間オンコール回数制限チェック
        if (checkOncallLimitExceeded(mockShifts, user.id, year, month, oncallSettings.maxOncallsPerMonth)) {
          newAlerts.push({
            userId: user.id,
            type: "limit",
            message: `${user.name}さんの月間オンコール回数が上限（${oncallSettings.maxOncallsPerMonth}回）を超えています`,
          })
        }

        // 連続オンコール日数チェック
        if (checkConsecutiveOncallDays(mockShifts, user.id, oncallSettings.maxConsecutiveDays)) {
          newAlerts.push({
            userId: user.id,
            type: "consecutive",
            message: `${user.name}さんが${oncallSettings.maxConsecutiveDays}日以上連続でオンコール当番になっています`,
          })
        }
      })

      setAlerts(newAlerts)
      setLoading(false)
    }, 500)
  }, [year, month])

  // ユーザーごとのオンコール集計を計算
  const userOncallSummaries = users.map((user) => {
    const summary = calculateUserMonthlyShiftSummary(shifts, user.id, year, month)

    // ユーザーのオンコール記録を取得
    const userOncallRecords = oncallRecords.filter((record) => record.userId === user.id)

    // 緊急訪問の合計
    const totalEmergencyVisits = userOncallRecords.reduce((sum, record) => sum + record.emergencyVisits, 0)

    // 手当計算
    const oncallAllowanceTotal = summary.oncallDays * oncallSettings.oncallAllowance
    const emergencyVisitAllowanceTotal = totalEmergencyVisits * oncallSettings.emergencyVisitAllowance
    const totalAllowance = oncallAllowanceTotal + emergencyVisitAllowanceTotal

    return {
      userId: user.id,
      userName: user.name,
      oncallDays: summary.oncallDays,
      callsReceived: userOncallRecords.reduce((sum, record) => sum + record.callsReceived, 0),
      emergencyVisits: totalEmergencyVisits,
      totalAllowance,
      hasAlert: alerts.some((alert) => alert.userId === user.id),
    }
  })

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>オンコール管理を読み込み中...</CardTitle>
        </CardHeader>
        <CardContent className="h-48 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Phone className="mr-2 h-5 w-5 text-primary" />
            オンコール管理
          </CardTitle>
          <CardDescription>
            {year}年{month}月のオンコール当番と実績を管理します
          </CardDescription>
        </CardHeader>
        <CardContent>
          {alerts.length > 0 && (
            <div className="mb-4 space-y-2">
              {alerts.map((alert, index) => (
                <Alert key={index} variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>オンコール制限アラート</AlertTitle>
                  <AlertDescription>{alert.message}</AlertDescription>
                </Alert>
              ))}
            </div>
          )}

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>スタッフ</TableHead>
                <TableHead className="text-right">オンコール日数</TableHead>
                <TableHead className="text-right">受信件数</TableHead>
                <TableHead className="text-right">緊急訪問</TableHead>
                <TableHead className="text-right">手当合計</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {userOncallSummaries.map((summary) => (
                <TableRow key={summary.userId}>
                  <TableCell className="font-medium">
                    <div className="flex items-center">
                      {summary.hasAlert && <AlertTriangle className="mr-1 h-4 w-4 text-destructive" />}
                      {summary.userName}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">{summary.oncallDays}日</TableCell>
                  <TableCell className="text-right">{summary.callsReceived}件</TableCell>
                  <TableCell className="text-right">{summary.emergencyVisits}件</TableCell>
                  <TableCell className="text-right">{summary.totalAllowance.toLocaleString()}円</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm" className="float-right">
                      詳細 <ChevronRight className="ml-1 h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Calendar className="mr-2 h-5 w-5 text-primary" />
            今月のオンコール当番
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {oncallRecords.map((record) => {
              const user = users.find((u) => u.id === record.userId)
              return (
                <div key={record.id} className="flex items-start space-x-4 border-b pb-4">
                  <div className="flex-shrink-0 rounded-full bg-primary/10 p-2">
                    <User className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-grow">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">{user?.name || "不明なユーザー"}</div>
                      <Badge variant="outline">
                        {record.date.toLocaleDateString("ja-JP", { month: "long", day: "numeric" })}
                      </Badge>
                    </div>
                    <div className="mt-1 flex items-center text-sm text-muted-foreground">
                      <Clock className="mr-1 h-4 w-4" />
                      {record.startTime.toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit" })}
                      {" 〜 "}
                      {record.endTime.toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit" })}
                    </div>
                    <div className="mt-2 flex space-x-4 text-sm">
                      <div>
                        <span className="font-medium">受信件数:</span> {record.callsReceived}件
                      </div>
                      <div>
                        <span className="font-medium">緊急訪問:</span> {record.emergencyVisits}件
                      </div>
                    </div>
                    {record.note && <div className="mt-2 text-sm">{record.note}</div>}
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
