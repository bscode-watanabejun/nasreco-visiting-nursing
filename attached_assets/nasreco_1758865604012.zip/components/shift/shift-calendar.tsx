"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChevronLeft, ChevronRight, Calendar, Users } from "lucide-react"
import { ShiftType, type Shift, type ShiftSchedule } from "@/lib/db/shift-schema"
import {
  getMonthDates,
  getDayOfWeek,
  getDayOfWeekName,
  isWeekend,
  isHoliday,
  getShiftTypeName,
  getShiftTypeColor,
  getUserShiftForDate,
} from "@/lib/utils/shift-utils"

// モックデータ（実際の実装ではAPIから取得）
const mockUsers = [
  { id: "user1", name: "山田 花子" },
  { id: "user2", name: "佐藤 次郎" },
  { id: "user3", name: "鈴木 三郎" },
  { id: "user4", name: "田中 四郎" },
  { id: "user5", name: "高橋 五郎" },
]

// モックシフトデータ（実際の実装ではAPIから取得）
const mockShifts: Shift[] = [
  // 山田花子のシフト
  {
    id: "shift1",
    userId: "user1",
    date: new Date(2025, 3, 1), // 2025-04-01
    shiftType: ShiftType.REGULAR,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "shift2",
    userId: "user1",
    date: new Date(2025, 3, 2), // 2025-04-02
    shiftType: ShiftType.REGULAR,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "shift3",
    userId: "user1",
    date: new Date(2025, 3, 3), // 2025-04-03
    shiftType: ShiftType.ONCALL,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "shift4",
    userId: "user1",
    date: new Date(2025, 3, 4), // 2025-04-04
    shiftType: ShiftType.REGULAR,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "shift5",
    userId: "user1",
    date: new Date(2025, 3, 5), // 2025-04-05
    shiftType: ShiftType.OFF,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "shift6",
    userId: "user1",
    date: new Date(2025, 3, 6), // 2025-04-06
    shiftType: ShiftType.OFF,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },

  // 佐藤次郎のシフト
  {
    id: "shift7",
    userId: "user2",
    date: new Date(2025, 3, 1), // 2025-04-01
    shiftType: ShiftType.REGULAR,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "shift8",
    userId: "user2",
    date: new Date(2025, 3, 2), // 2025-04-02
    shiftType: ShiftType.REGULAR,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "shift9",
    userId: "user2",
    date: new Date(2025, 3, 3), // 2025-04-03
    shiftType: ShiftType.REGULAR,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "shift10",
    userId: "user2",
    date: new Date(2025, 3, 4), // 2025-04-04
    shiftType: ShiftType.ONCALL,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "shift11",
    userId: "user2",
    date: new Date(2025, 3, 5), // 2025-04-05
    shiftType: ShiftType.OFF,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
  {
    id: "shift12",
    userId: "user2",
    date: new Date(2025, 3, 6), // 2025-04-06
    shiftType: ShiftType.OFF,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "admin",
  },
]

// モックシフトスケジュール
const mockShiftSchedule: ShiftSchedule = {
  id: "schedule1",
  name: "2025年4月シフト",
  year: 2025,
  month: 4,
  status: "published",
  shifts: mockShifts,
  createdAt: new Date(),
  updatedAt: new Date(),
}

interface ShiftCalendarProps {
  initialYear?: number
  initialMonth?: number
  editable?: boolean
}

export function ShiftCalendar({
  initialYear = new Date().getFullYear(),
  initialMonth = new Date().getMonth() + 1,
  editable = false,
}: ShiftCalendarProps) {
  const [year, setYear] = useState(initialYear)
  const [month, setMonth] = useState(initialMonth)
  const [schedule, setSchedule] = useState<ShiftSchedule | null>(null)
  const [users, setUsers] = useState<{ id: string; name: string }[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedShiftType, setSelectedShiftType] = useState<ShiftType>(ShiftType.REGULAR)

  // 月の日付配列を取得
  const dates = getMonthDates(year, month)

  // 前月へ移動
  const goToPreviousMonth = () => {
    if (month === 1) {
      setYear(year - 1)
      setMonth(12)
    } else {
      setMonth(month - 1)
    }
  }

  // 次月へ移動
  const goToNextMonth = () => {
    if (month === 12) {
      setYear(year + 1)
      setMonth(1)
    } else {
      setMonth(month + 1)
    }
  }

  // データ取得（モック）
  useEffect(() => {
    // 実際の実装ではAPIからデータを取得
    setLoading(true)

    // モックデータをセット
    setTimeout(() => {
      setSchedule(mockShiftSchedule)
      setUsers(mockUsers)
      setLoading(false)
    }, 500)
  }, [year, month])

  // シフトセルをクリックした時の処理
  const handleShiftCellClick = (userId: string, date: Date) => {
    if (!editable) return

    // 実際の実装ではAPIを呼び出してシフトを更新
    console.log(`シフト更新: ユーザー ${userId}, 日付 ${date.toISOString()}, シフト ${selectedShiftType}`)

    // モックデータを更新（実際の実装では不要）
    const existingShiftIndex = mockShifts.findIndex(
      (shift) => shift.userId === userId && shift.date.toISOString().split("T")[0] === date.toISOString().split("T")[0],
    )

    if (existingShiftIndex >= 0) {
      // 既存のシフトを更新
      mockShifts[existingShiftIndex] = {
        ...mockShifts[existingShiftIndex],
        shiftType: selectedShiftType,
        updatedAt: new Date(),
      }
    } else {
      // 新しいシフトを追加
      mockShifts.push({
        id: `shift${mockShifts.length + 1}`,
        userId,
        date,
        shiftType: selectedShiftType,
        createdAt: new Date(),
        updatedAt: new Date(),
        createdBy: "admin",
      })
    }

    // スケジュールを更新
    setSchedule({
      ...mockShiftSchedule,
      shifts: [...mockShifts],
    })
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>シフト表を読み込み中...</CardTitle>
        </CardHeader>
        <CardContent className="h-96 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-xl font-bold">
          シフト表: {year}年{month}月
        </CardTitle>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="icon" onClick={goToPreviousMonth}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={goToNextMonth}>
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm">
            <Calendar className="mr-2 h-4 w-4" />
            今月
          </Button>
          <Button variant="outline" size="sm">
            <Users className="mr-2 h-4 w-4" />
            スタッフ管理
          </Button>
        </div>
      </CardHeader>

      <CardContent>
        {editable && (
          <div className="mb-4 flex items-center space-x-2">
            <span className="text-sm font-medium">選択中のシフト:</span>
            <Select value={selectedShiftType} onValueChange={(value) => setSelectedShiftType(value as ShiftType)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="シフトタイプを選択" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ShiftType.REGULAR}>通常勤務</SelectItem>
                <SelectItem value={ShiftType.NIGHT}>夜勤</SelectItem>
                <SelectItem value={ShiftType.ONCALL}>オンコール</SelectItem>
                <SelectItem value={ShiftType.OFF}>休み</SelectItem>
                <SelectItem value={ShiftType.PAID_LEAVE}>有給休暇</SelectItem>
                <SelectItem value={ShiftType.HALF_DAY}>半日勤務</SelectItem>
                <SelectItem value={ShiftType.TRAINING}>研修</SelectItem>
              </SelectContent>
            </Select>
            <Badge className={getShiftTypeColor(selectedShiftType)}>{getShiftTypeName(selectedShiftType)}</Badge>
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-muted">
                <th className="border p-2 text-left sticky left-0 bg-muted z-10 min-w-[120px]">スタッフ</th>
                {dates.map((date) => {
                  const dayOfWeek = getDayOfWeek(date)
                  const dayName = getDayOfWeekName(dayOfWeek)
                  const isWeekendDay = isWeekend(date)
                  const isHolidayDay = isHoliday(date)

                  return (
                    <th
                      key={date.toISOString()}
                      className={`border p-1 text-center w-12 ${isWeekendDay || isHolidayDay ? "bg-red-50" : ""}`}
                    >
                      <div className="text-sm">{date.getDate()}</div>
                      <div
                        className={`text-xs ${
                          dayOfWeek === 0 || isHolidayDay ? "text-red-500" : dayOfWeek === 6 ? "text-blue-500" : ""
                        }`}
                      >
                        {dayName}
                      </div>
                    </th>
                  )
                })}
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id}>
                  <td className="border p-2 sticky left-0 bg-white z-10 font-medium">{user.name}</td>
                  {dates.map((date) => {
                    const shift = getUserShiftForDate(schedule?.shifts || [], user.id, date)

                    return (
                      <td
                        key={`${user.id}-${date.toISOString()}`}
                        className={`border p-1 text-center ${
                          isWeekend(date) || isHoliday(date) ? "bg-red-50" : ""
                        } ${editable ? "cursor-pointer hover:bg-gray-100" : ""}`}
                        onClick={() => handleShiftCellClick(user.id, date)}
                      >
                        {shift ? (
                          <Badge className={`text-xs ${getShiftTypeColor(shift.shiftType)}`}>
                            {getShiftTypeName(shift.shiftType)}
                          </Badge>
                        ) : null}
                      </td>
                    )
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          {Object.values(ShiftType).map((type) => (
            <div key={type} className="flex items-center">
              <Badge className={`mr-1 ${getShiftTypeColor(type)}`}>{getShiftTypeName(type)}</Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
