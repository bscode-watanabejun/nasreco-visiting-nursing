"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { ChevronDown, ChevronUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { FieldRenderer } from "./field-renderer"
import type { FormField, FormSection, FormTemplate } from "@/lib/db/form-schema"

interface DynamicFormProps {
  template: FormTemplate
  initialValues?: Record<string, any>
  onSubmit: (data: Record<string, any>) => void
  onSaveDraft?: (data: Record<string, any>) => void
  readOnly?: boolean
  patientId?: string
  visitId?: string
}

export function DynamicForm({
  template,
  initialValues = {},
  onSubmit,
  onSaveDraft,
  readOnly = false,
  patientId,
  visitId,
}: DynamicFormProps) {
  const [formData, setFormData] = useState<Record<string, any>>(initialValues)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({})
  const [mediaAttachments, setMediaAttachments] = useState<Record<string, { id: string; url: string; type: string }[]>>(
    {},
  )

  // セクションの折りたたみ状態を初期化
  useEffect(() => {
    const initialCollapsedState: Record<string, boolean> = {}
    template.sections.forEach((section) => {
      initialCollapsedState[section.id] = section.isCollapsed || false
    })
    setCollapsedSections(initialCollapsedState)
  }, [template.sections])

  // 現在の日時を初期値として設定（日付・時間フィールドがある場合）
  useEffect(() => {
    const now = new Date()
    const today = now.toISOString().split("T")[0]
    const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`

    const newFormData = { ...formData }
    let dataUpdated = false

    // テンプレート内のすべてのフィールドをチェック
    template.sections.forEach((section) => {
      section.fields.forEach((field) => {
        // 日付フィールドで値が設定されていない場合は今日の日付を設定
        if (field.type === "date" && !formData[field.id]) {
          newFormData[field.id] = today
          dataUpdated = true
        }
        // 時間フィールドで値が設定されていない場合は現在時刻を設定
        if (field.type === "time" && !formData[field.id]) {
          newFormData[field.id] = currentTime
          dataUpdated = true
        }
      })
    })

    if (dataUpdated) {
      setFormData(newFormData)
    }
  }, [template.sections, formData])

  const toggleSection = (sectionId: string) => {
    setCollapsedSections({
      ...collapsedSections,
      [sectionId]: !collapsedSections[sectionId],
    })
  }

  const handleFieldChange = (fieldId: string, value: any) => {
    setFormData({
      ...formData,
      [fieldId]: value,
    })

    // エラーがあれば削除
    if (errors[fieldId]) {
      setErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[fieldId]
        return newErrors
      })
    }
  }

  const handleMediaUpload = (fieldId: string, files: FileList | null) => {
    if (!files || files.length === 0) return

    // 実際の実装ではファイルをアップロードする処理を実装
    // ここではモックデータを使用
    const newAttachments = Array.from(files).map((file) => ({
      id: `attachment-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      url: URL.createObjectURL(file),
      type: file.type.startsWith("image/") ? "image" : "video",
    }))

    setMediaAttachments({
      ...mediaAttachments,
      [fieldId]: [...(mediaAttachments[fieldId] || []), ...newAttachments],
    })
  }

  const handleRemoveMedia = (fieldId: string, attachmentId: string) => {
    setMediaAttachments({
      ...mediaAttachments,
      [fieldId]: (mediaAttachments[fieldId] || []).filter((attachment) => attachment.id !== attachmentId),
    })
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    template.sections.forEach((section) => {
      section.fields.forEach((field) => {
        if (shouldShowField(field)) {
          // 必須フィールドのバリデーション
          if (field.isRequired && isEmptyValue(formData[field.id])) {
            newErrors[field.id] = "この項目は必須です"
          }

          // カスタムバリデーションルール
          if (field.validation && field.validation.length > 0) {
            field.validation.forEach((rule) => {
              if (formData[field.id] !== undefined && formData[field.id] !== "") {
                switch (rule.type) {
                  case "min":
                    if (
                      (field.type === "number" && Number(formData[field.id]) < Number(rule.value)) ||
                      (field.type === "text" && formData[field.id].length < Number(rule.value))
                    ) {
                      newErrors[field.id] = rule.message
                    }
                    break
                  case "max":
                    if (
                      (field.type === "number" && Number(formData[field.id]) > Number(rule.value)) ||
                      (field.type === "text" && formData[field.id].length > Number(rule.value))
                    ) {
                      newErrors[field.id] = rule.message
                    }
                    break
                  case "pattern":
                    if (rule.value && !new RegExp(rule.value).test(formData[field.id])) {
                      newErrors[field.id] = rule.message
                    }
                    break
                  // カスタムバリデーションは実際の実装で追加
                }
              }
            })
          }
        }
      })
    })

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const isEmptyValue = (value: any): boolean => {
    if (value === undefined || value === null || value === "") return true
    if (Array.isArray(value) && value.length === 0) return true
    return false
  }

  const shouldShowField = (field: FormField): boolean => {
    if (field.isHidden) return false

    if (field.dependsOn) {
      const { field: dependsOnField, value: dependsOnValue } = field.dependsOn
      return formData[dependsOnField] === dependsOnValue
    }

    return true
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (validateForm()) {
      // メディア添付ファイルを含めて送信
      const submissionData = {
        ...formData,
        _mediaAttachments: mediaAttachments,
        _patientId: patientId,
        _visitId: visitId,
        _templateId: template.id,
        _templateVersion: template.version,
        _submittedAt: new Date().toISOString(),
      }
      onSubmit(submissionData)
    } else {
      // エラーがある場合は、最初のエラーフィールドが含まれるセクションを展開
      const firstErrorField = Object.keys(errors)[0]
      const sectionWithError = template.sections.find((section) =>
        section.fields.some((field) => field.id === firstErrorField),
      )

      if (sectionWithError && sectionWithError.isCollapsible) {
        setCollapsedSections((prev) => ({ ...prev, [sectionWithError.id]: false }))
      }

      // エラーフィールドにスクロール
      const errorElement = document.getElementById(firstErrorField)
      if (errorElement) {
        errorElement.scrollIntoView({ behavior: "smooth", block: "center" })
      }
    }
  }

  const handleSaveDraft = () => {
    if (onSaveDraft) {
      const draftData = {
        ...formData,
        _mediaAttachments: mediaAttachments,
        _patientId: patientId,
        _visitId: visitId,
        _templateId: template.id,
        _templateVersion: template.version,
        _savedAt: new Date().toISOString(),
        _status: "draft",
      }
      onSaveDraft(draftData)
    }
  }

  const renderSection = (section: FormSection) => {
    const isCollapsed = collapsedSections[section.id]
    const hasVisibleFields = section.fields.some(shouldShowField)

    if (!hasVisibleFields) return null

    return (
      <Card key={section.id} className="mb-4">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle>{section.title}</CardTitle>
            {section.isCollapsible && (
              <Button variant="ghost" size="icon" onClick={() => toggleSection(section.id)}>
                {isCollapsed ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
              </Button>
            )}
          </div>
          {section.description && <CardDescription>{section.description}</CardDescription>}
        </CardHeader>
        {!isCollapsed && (
          <CardContent>
            <div className="grid grid-cols-12 gap-4">
              {section.fields.map((field) =>
                shouldShowField(field) ? (
                  <FieldRenderer
                    key={field.id}
                    field={field}
                    value={formData[field.id]}
                    onChange={(value) => handleFieldChange(field.id, value)}
                    error={errors[field.id]}
                    readOnly={readOnly || field.isReadOnly}
                    mediaAttachments={mediaAttachments[field.id] || []}
                    onMediaUpload={(files) => handleMediaUpload(field.id, files)}
                    onMediaRemove={(attachmentId) => handleRemoveMedia(field.id, attachmentId)}
                  />
                ) : null,
              )}
            </div>
          </CardContent>
        )}
      </Card>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {template.sections.map(renderSection)}

      {!readOnly && (
        <div className="flex justify-end gap-2">
          {onSaveDraft && (
            <Button type="button" variant="outline" onClick={handleSaveDraft}>
              下書き保存
            </Button>
          )}
          <Button type="submit">送信</Button>
        </div>
      )}
    </form>
  )
}
