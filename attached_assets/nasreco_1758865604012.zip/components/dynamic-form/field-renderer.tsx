"use client"

import { useState } from "react"
import { Camera, Paperclip, MessageSquare, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Slider } from "@/components/ui/slider"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import type { FormField } from "@/lib/db/form-schema"

// モック定型文データ
const mockTextTemplates = [
  {
    id: "text-1",
    title: "バイタル安定",
    content: "バイタルサインは安定しています。特に異常所見は認められません。",
    category: "観察記録",
  },
  {
    id: "text-2",
    title: "服薬管理",
    content: "処方薬の管理状況を確認。指示通りに内服できています。残薬の過不足はありません。",
    category: "服薬管理",
  },
  {
    id: "text-3",
    title: "褥瘡処置",
    content:
      "仙骨部の褥瘡に対し、洗浄・消毒後、指示のあるハイドロコロイド材を貼付しました。発赤の範囲は縮小傾向にあります。",
    category: "処置",
  },
]

interface FieldRendererProps {
  field: FormField
  value: any
  onChange: (value: any) => void
  error?: string
  readOnly?: boolean
  mediaAttachments?: { id: string; url: string; type: string }[]
  onMediaUpload?: (files: FileList | null) => void
  onMediaRemove?: (attachmentId: string) => void
}

export function FieldRenderer({
  field,
  value,
  onChange,
  error,
  readOnly = false,
  mediaAttachments = [],
  onMediaUpload,
  onMediaRemove,
}: FieldRendererProps) {
  const [openTemplatePopover, setOpenTemplatePopover] = useState(false)

  const fieldWidth = field.width || "full"
  const widthClass = {
    full: "col-span-12",
    half: "col-span-6",
    third: "col-span-4",
  }[fieldWidth]

  const insertTextTemplate = (content: string) => {
    const currentValue = value || ""
    const newValue = currentValue ? `${currentValue}\n${content}` : content
    onChange(newValue)
    setOpenTemplatePopover(false)
  }

  return (
    <div className={`${widthClass} space-y-2`}>
      <Label htmlFor={field.id}>
        {field.label}
        {field.isRequired && <span className="text-destructive ml-1">*</span>}
      </Label>

      {field.type === "text" && (
        <Input
          id={field.id}
          placeholder={field.placeholder}
          value={value || ""}
          onChange={(e) => onChange(e.target.value)}
          disabled={readOnly}
          className={error ? "border-destructive" : ""}
        />
      )}

      {field.type === "textarea" && (
        <div className="space-y-2">
          <div className="relative">
            <Textarea
              id={field.id}
              placeholder={field.placeholder}
              value={value || ""}
              onChange={(e) => onChange(e.target.value)}
              disabled={readOnly}
              rows={4}
              className={error ? "border-destructive" : ""}
            />
            {!readOnly && (
              <div className="absolute bottom-2 right-2">
                <Popover open={openTemplatePopover} onOpenChange={setOpenTemplatePopover}>
                  <PopoverTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MessageSquare className="h-4 w-4" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-80 p-0" align="end">
                    <Command>
                      <CommandInput placeholder="定型文を検索..." />
                      <CommandList>
                        <CommandEmpty>定型文が見つかりません</CommandEmpty>
                        {mockTextTemplates.map((template) => (
                          <CommandGroup key={template.id} heading={template.category}>
                            <CommandItem
                              onSelect={() => insertTextTemplate(template.content)}
                              className="cursor-pointer"
                            >
                              <div>
                                <p className="font-medium">{template.title}</p>
                                <p className="text-xs text-muted-foreground line-clamp-1">{template.content}</p>
                              </div>
                            </CommandItem>
                          </CommandGroup>
                        ))}
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>
            )}
          </div>
        </div>
      )}

      {field.type === "number" && (
        <Input
          id={field.id}
          type="number"
          placeholder={field.placeholder}
          value={value || ""}
          onChange={(e) => onChange(e.target.value)}
          disabled={readOnly}
          className={error ? "border-destructive" : ""}
          min={field.validation?.find((v) => v.type === "min")?.value}
          max={field.validation?.find((v) => v.type === "max")?.value}
        />
      )}

      {field.type === "select" && (
        <Select value={value || ""} onValueChange={onChange} disabled={readOnly}>
          <SelectTrigger id={field.id} className={error ? "border-destructive" : ""}>
            <SelectValue placeholder={field.placeholder || "選択してください"} />
          </SelectTrigger>
          <SelectContent>
            {(field.options || []).map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}

      {field.type === "multiselect" && (
        <Select
          value={value || ""}
          onValueChange={(selectedValue) => {
            const currentValues = Array.isArray(value) ? value : []
            const newValues = currentValues.includes(selectedValue)
              ? currentValues.filter((v) => v !== selectedValue)
              : [...currentValues, selectedValue]
            onChange(newValues)
          }}
          disabled={readOnly}
        >
          <SelectTrigger id={field.id} className={error ? "border-destructive" : ""}>
            <SelectValue
              placeholder={field.placeholder || "選択してください"}
              className="overflow-hidden text-ellipsis"
            >
              {Array.isArray(value) && value.length > 0
                ? field.options
                    ?.filter((opt) => value.includes(opt.value))
                    .map((opt) => opt.label)
                    .join(", ")
                : field.placeholder || "選択してください"}
            </SelectValue>
          </SelectTrigger>
          <SelectContent>
            {(field.options || []).map((option) => (
              <SelectItem key={option.value} value={option.value}>
                <div className="flex items-center gap-2">
                  <Checkbox checked={Array.isArray(value) && value.includes(option.value)} />
                  <span>{option.label}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}

      {field.type === "checkbox" && (
        <div className="space-y-2">
          {(field.options || []).map((option) => {
            const checkboxId = `${field.id}-${option.value}`
            return (
              <div key={option.value} className="flex items-center space-x-2">
                <Checkbox
                  id={checkboxId}
                  checked={Array.isArray(value) && value.includes(option.value)}
                  onCheckedChange={(checked) => {
                    const currentValues = Array.isArray(value) ? value : []
                    const newValues = checked
                      ? [...currentValues, option.value]
                      : currentValues.filter((v) => v !== option.value)
                    onChange(newValues)
                  }}
                  disabled={readOnly}
                />
                <Label htmlFor={checkboxId} className={readOnly ? "opacity-70" : ""}>
                  {option.label}
                </Label>
              </div>
            )
          })}
        </div>
      )}

      {field.type === "radio" && (
        <RadioGroup value={value || ""} onValueChange={onChange} disabled={readOnly}>
          {(field.options || []).map((option) => {
            const radioId = `${field.id}-${option.value}`
            return (
              <div key={option.value} className="flex items-center space-x-2">
                <RadioGroupItem value={option.value} id={radioId} />
                <Label htmlFor={radioId} className={readOnly ? "opacity-70" : ""}>
                  {option.label}
                </Label>
              </div>
            )
          })}
        </RadioGroup>
      )}

      {field.type === "date" && (
        <Input
          id={field.id}
          type="date"
          value={value || ""}
          onChange={(e) => onChange(e.target.value)}
          disabled={readOnly}
          className={error ? "border-destructive" : ""}
        />
      )}

      {field.type === "time" && (
        <Input
          id={field.id}
          type="time"
          value={value || ""}
          onChange={(e) => onChange(e.target.value)}
          disabled={readOnly}
          className={error ? "border-destructive" : ""}
        />
      )}

      {field.type === "scale" && (
        <div className="pt-4 pb-2">
          <Slider
            id={field.id}
            min={(field.metadata?.min as number) || 0}
            max={(field.metadata?.max as number) || 10}
            step={(field.metadata?.step as number) || 1}
            value={[value || (field.metadata?.min as number) || 0]}
            onValueChange={(newValue) => onChange(newValue[0])}
            disabled={readOnly}
            className={error ? "border-destructive" : ""}
          />
          <div className="flex justify-between mt-1 text-xs text-muted-foreground">
            <span>{field.metadata?.min || 0}</span>
            <span>{value || (field.metadata?.min as number) || 0}</span>
            <span>{field.metadata?.max || 10}</span>
          </div>
        </div>
      )}

      {field.type === "media" && !readOnly && (
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <label
              htmlFor={`${field.id}-file`}
              className="flex h-10 w-full cursor-pointer items-center justify-center gap-2 rounded-md border border-input bg-background px-3 py-2 text-sm font-medium ring-offset-background hover:bg-accent hover:text-accent-foreground"
            >
              <Paperclip className="h-4 w-4" />
              <span>ファイルを選択</span>
              <input
                id={`${field.id}-file`}
                type="file"
                accept="image/*,video/*"
                multiple
                className="hidden"
                onChange={(e) => onMediaUpload && onMediaUpload(e.target.files)}
                disabled={readOnly}
              />
            </label>
            <label
              htmlFor={`${field.id}-camera`}
              className="flex h-10 cursor-pointer items-center justify-center gap-2 rounded-md border border-input bg-background px-3 py-2 text-sm font-medium ring-offset-background hover:bg-accent hover:text-accent-foreground"
            >
              <Camera className="h-4 w-4" />
              <span>カメラ</span>
              <input
                id={`${field.id}-camera`}
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={(e) => onMediaUpload && onMediaUpload(e.target.files)}
                disabled={readOnly}
              />
            </label>
          </div>

          {mediaAttachments.length > 0 && (
            <div className="grid grid-cols-2 gap-2 mt-2">
              {mediaAttachments.map((attachment) => (
                <div key={attachment.id} className="relative rounded-md overflow-hidden border">
                  {attachment.type === "image" ? (
                    <img
                      src={attachment.url || "/placeholder.svg?height=200&width=200&query=image"}
                      alt="添付画像"
                      className="w-full h-32 object-cover"
                    />
                  ) : (
                    <video src={attachment.url} controls className="w-full h-32 object-cover" />
                  )}
                  {!readOnly && onMediaRemove && (
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute top-1 right-1 h-6 w-6"
                      onClick={() => onMediaRemove(attachment.id)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {field.type === "media" && readOnly && mediaAttachments.length > 0 && (
        <div className="grid grid-cols-2 gap-2">
          {mediaAttachments.map((attachment) => (
            <div key={attachment.id} className="rounded-md overflow-hidden border">
              {attachment.type === "image" ? (
                <img
                  src={attachment.url || "/placeholder.svg?height=200&width=200&query=image"}
                  alt="添付画像"
                  className="w-full h-32 object-cover"
                />
              ) : (
                <video src={attachment.url} controls className="w-full h-32 object-cover" />
              )}
            </div>
          ))}
        </div>
      )}

      {field.type === "signature" && (
        <div
          className={`h-40 border rounded-md bg-muted flex items-center justify-center ${
            error ? "border-destructive" : ""
          }`}
        >
          {value ? (
            <img src={value || "/placeholder.svg"} alt="署名" className="max-h-full max-w-full" />
          ) : (
            <span className="text-muted-foreground">ここに署名</span>
          )}
        </div>
      )}

      {field.helpText && <p className="text-xs text-muted-foreground">{field.helpText}</p>}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  )
}
