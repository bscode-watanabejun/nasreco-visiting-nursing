// 特別管理加算対象項目の定義
export const specialManagementItems = {
  typeI: {
    // 500単位/月
    items: [
      { id: "malignant_tumor", label: "在宅悪性腫瘍等患者指導管理", requireDetail: ["薬剤名"] },
      { id: "tracheotomy", label: "在宅気管切開患者指導管理", requireDetail: ["カニューレサイズ"] },
      { id: "tracheal_cannula", label: "気管カニューレ使用", requireDetail: ["交換頻度"] },
      { id: "indwelling_catheter", label: "留置カテーテル管理", requireDetail: ["種類（膀胱/腎瘻/その他）"] },
      { id: "narcotic_injection", label: "在宅麻薬等注射指導管理", requireDetail: ["薬剤名"], isNew2024: true },
      {
        id: "chemotherapy_injection",
        label: "在宅腫瘍化学療法注射指導管理",
        requireDetail: ["プロトコル"],
        isNew2024: true,
      },
      { id: "cardiac_drug", label: "在宅強心剤持続投与指導管理", requireDetail: ["薬剤名"], isNew2024: true },
    ],
  },
  typeII: {
    // 250単位/月
    items: [
      { id: "oxygen_therapy", label: "在宅酸素療法", requireDetail: ["流量(L/min)", "使用時間(時間/日)"] },
      { id: "cpap", label: "在宅持続陽圧呼吸療法(CPAP/ASV)", requireDetail: ["設定圧(cmH2O)"] },
      { id: "ventilator", label: "在宅人工呼吸療法", requireDetail: ["機種", "モード"] },
      { id: "peg", label: "胃ろう・腸ろうによる経管栄養", requireDetail: ["栄養剤", "投与時間"] },
      { id: "ng_tube", label: "経鼻経管栄養", requireDetail: ["チューブサイズ(Fr)"] },
      { id: "stoma", label: "人工肛門(ストーマ)", requireDetail: ["造設部位"] },
      { id: "urostomy", label: "人工膀胱", requireDetail: ["種類"] },
      { id: "pressure_ulcer", label: "真皮を越える褥瘡", requireDetail: ["部位", "DESIGN-R点数"] },
      { id: "iv_injection", label: "点滴注射(週3日以上)", requireDetail: ["薬剤名", "頻度(週◯回)"] },
    ],
  },
}

// 特別管理加算利用者の必須記録項目
export const requiredRecordItems = {
  basic: [
    { field: "visitDate", label: "訪問日時", type: "datetime" },
    { field: "staffName", label: "担当者名", type: "text" },
    { field: "staffRole", label: "職種", type: "select" },
    { field: "vitalSigns", label: "バイタルサイン", type: "object", subFields: ["体温", "血圧", "脈拍", "SpO2"] },
  ],
  specialManagement: [
    { field: "deviceCheck", label: "医療機器作動確認", type: "checkbox" },
    { field: "catheterStatus", label: "カテーテル固定・清潔状態", type: "select" },
    { field: "skinCondition", label: "皮膚状態観察", type: "textarea" },
    { field: "managementDetail", label: "管理内容詳細", type: "textarea" },
    { field: "abnormalFindings", label: "異常所見", type: "radio", options: ["あり", "なし"] },
    { field: "doctorInstruction", label: "医師指示確認", type: "checkbox" },
  ],
  reasoning: [
    { field: "multipleVisitReason", label: "複数回訪問理由", condition: "multipleVisit" },
    { field: "longVisitReason", label: "長時間訪問理由", condition: "over90min" },
    { field: "emergencyReason", label: "緊急訪問理由", condition: "emergency" },
  ],
}

// アラートレベルの定義
export const alertLevels = {
  ERROR: {
    icon: "🔴",
    message: "必須項目が未入力です",
    canSave: false,
    fields: ["visitDate", "staffName", "vitalSigns", "managementDetail"],
  },
  WARNING: {
    icon: "🟡",
    message: "加算要件を満たしていない可能性があります",
    canSave: true,
    conditions: [
      { check: "doctorInstructionExpiry", message: "医師指示書の期限が近づいています" },
      { check: "missingReason", message: "訪問形態の変更理由が未記載です" },
      { check: "inconsistentTime", message: "記録時間とサービス提供時間が一致しません" },
    ],
  },
  INFO: {
    icon: "🔵",
    message: "確認を推奨します",
    canSave: true,
    conditions: [
      { check: "significantChange", message: "前回訪問から大幅な変更があります" },
      { check: "handoverRequired", message: "申し送り事項があります" },
    ],
  },
}

// 型定義（TypeScriptの型安全性のため）
export type SpecialManagementItemId =
  | "malignant_tumor"
  | "tracheotomy"
  | "tracheal_cannula"
  | "indwelling_catheter"
  | "narcotic_injection"
  | "chemotherapy_injection"
  | "cardiac_drug"
  | "oxygen_therapy"
  | "cpap"
  | "ventilator"
  | "peg"
  | "ng_tube"
  | "stoma"
  | "urostomy"
  | "pressure_ulcer"
  | "iv_injection"

export type SpecialManagementItem = {
  id: SpecialManagementItemId
  label: string
  requireDetail: string[]
  isNew2024?: boolean
}

export type SpecialManagementItemsType = {
  typeI: {
    items: SpecialManagementItem[]
  }
  typeII: {
    items: SpecialManagementItem[]
  }
}

export type RequiredRecordField = {
  field: string
  label: string
  type: "text" | "textarea" | "select" | "checkbox" | "radio" | "datetime" | "object"
  subFields?: string[]
  options?: string[]
  condition?: string
}

export type RequiredRecordItems = {
  basic: RequiredRecordField[]
  specialManagement: RequiredRecordField[]
  reasoning: RequiredRecordField[]
}

export type AlertCondition = {
  check: string
  message: string
}

export type AlertLevel = {
  icon: string
  message: string
  canSave: boolean
  fields?: string[]
  conditions?: AlertCondition[]
}

export type AlertLevels = {
  ERROR: AlertLevel
  WARNING: AlertLevel
  INFO: AlertLevel
}
