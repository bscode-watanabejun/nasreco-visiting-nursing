// カスタムフォームのデータモデル

export type FieldType =
  | "text"
  | "textarea"
  | "number"
  | "select"
  | "multiselect"
  | "checkbox"
  | "radio"
  | "date"
  | "time"
  | "scale"
  | "media"
  | "signature"

export type ValidationRule = {
  type: "required" | "min" | "max" | "pattern" | "custom"
  value?: any
  message: string
}

// フォームフィールドの定義
export type FormField = {
  id: string
  type: FieldType
  label: string
  placeholder?: string
  helpText?: string
  defaultValue?: any
  options?: { label: string; value: string }[]
  validation?: ValidationRule[]
  isRequired?: boolean
  isHidden?: boolean
  isReadOnly?: boolean
  width?: "full" | "half" | "third"
  dependsOn?: { field: string; value: any }
  mappingKey?: string // 標準項目とのマッピングキー
  metadata?: Record<string, any> // 追加情報
}

// フォームセクションの定義
export type FormSection = {
  id: string
  title: string
  description?: string
  fields: FormField[]
  isCollapsible?: boolean
  isCollapsed?: boolean
  order: number
}

// フォームテンプレートの定義
export type FormTemplate = {
  id: string
  name: string
  description?: string
  type: "visit" | "assessment" | "plan" | "custom"
  sections: FormSection[]
  createdAt: Date
  updatedAt: Date
  createdBy: string
  isActive: boolean
  tenantId: string
  version: number
}

// フォーム入力データの定義
export type FormData = {
  id: string
  templateId: string
  templateVersion: number
  patientId: string
  visitId?: string
  data: Record<string, any>
  createdAt: Date
  updatedAt: Date
  createdBy: string
  status: "draft" | "completed" | "reviewed"
  mediaAttachments?: MediaAttachment[]
}

// メディア添付ファイルの定義
export type MediaAttachment = {
  id: string
  formDataId: string
  fieldId: string
  type: "image" | "video" | "audio" | "document"
  url: string
  thumbnailUrl?: string
  filename: string
  filesize: number
  metadata?: Record<string, any>
  createdAt: Date
  createdBy: string
}

// テンプレート定型文の定義
export type TextTemplate = {
  id: string
  title: string
  content: string
  category: string
  tags: string[]
  createdAt: Date
  updatedAt: Date
  createdBy: string
  tenantId: string
  usageCount: number
}

// マスタデータの定義
export type MasterDataItem = {
  id: string
  value: string
  label: string
  category: string
  order: number
  isActive: boolean
  metadata?: Record<string, any>
}

export type MasterDataCategory = {
  id: string
  name: string
  description?: string
  items: MasterDataItem[]
  createdAt: Date
  updatedAt: Date
  tenantId: string
}
