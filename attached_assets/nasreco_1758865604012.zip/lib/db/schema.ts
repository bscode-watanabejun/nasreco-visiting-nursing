// 患者情報スキーマ
export type Patient = {
  id: string
  tenantId: string // 所属テナントID
  name: string // 氏名
  dateOfBirth: Date // 生年月日
  gender: "male" | "female" | "other" | "unknown" // 性別
  address?: string // 住所
  phoneNumber?: string // 電話番号
  emergencyContact?: {
    // 緊急連絡先
    name: string
    relationship: string
    phoneNumber: string
  }
  // ... その他基本的な患者情報 ...

  // 医療プロファイルへの参照 (オプション)
  // PatientMedicalProfileが作成されたら、そのIDをここに格納するか、
  // medicalProfileオブジェクトを直接ネストすることも考えられる。
  // NoSQL的なアプローチならネスト、RDB的ならIDで関連付ける。
  // ここではIDでの関連を想定。
  medicalProfileId?: string
  // または、取得時に結合することを前提に、直接プロファイルを持つことも可能
  // medicalProfile?: PatientMedicalProfile;

  // 視覚的マーク表示用のサマリー情報 (DBのビューや取得時の加工で生成しても良い)
  // specialAdditionBadge?: "特管Ⅰ" | "特管Ⅱ" | null;

  createdAt: Date
  updatedAt: Date
}

export type Tenant = {
  id: string
  name: string
  domain: string | null
  createdAt: Date
  updatedAt: Date
}

export type User = {
  id: string
  tenantId: string
  email: string
  name: string
  passwordHash: string
  role: "admin" | "manager" | "staff"
  createdAt: Date
  updatedAt: Date
}

export type Session = {
  id: string
  userId: string
  expiresAt: Date
  createdAt: Date
}

// 実際のデータベース接続時には、Prisma や Drizzle などの ORM を使用します
// 現在はモックデータを使用します
