// 記録機能のデータモデル

export type RecordType = "visit" | "vital" | "medication" | "treatment" | "assessment" | "plan" | "other"
export type RecordStatus = "draft" | "completed" | "reviewed" | "approved"
export type TemplateType = "personal" | "team" | "system"

// 看護記録の定義
export type NursingRecord = {
  id: string
  patientId: string
  createdById: string
  reviewedById?: string
  approvedById?: string
  recordType: RecordType
  visitDate: Date
  createdAt: Date
  updatedAt: Date
  status: RecordStatus
  content: RecordContent
  templateId?: string
  planIds?: string[] // 関連する看護計画のID
  tags?: string[]
  isDeleted: boolean
}

// 記録内容の定義（SOAP形式）
export type RecordContent = {
  subjective?: string // 主観的情報（患者の訴え）
  objective?: string // 客観的情報（観察・測定結果）
  assessment?: string // アセスメント（評価）
  plan?: string // 計画
  notes?: string // 備考
  vitalSigns?: VitalSigns
  medications?: Medication[]
  treatments?: Treatment[]
  attachments?: Attachment[]
}

// バイタルサインの定義
export type VitalSigns = {
  bodyTemperature?: number // 体温（℃）
  pulseRate?: number // 脈拍（回/分）
  respiratoryRate?: number // 呼吸数（回/分）
  bloodPressureSystolic?: number // 収縮期血圧（mmHg）
  bloodPressureDiastolic?: number // 拡張期血圧（mmHg）
  oxygenSaturation?: number // 酸素飽和度（%）
  bloodGlucose?: number // 血糖値（mg/dL）
  painScale?: number // 疼痛スケール（0-10）
  consciousnessLevel?: string // 意識レベル
  weight?: number // 体重（kg）
}

// 投薬情報の定義
export type Medication = {
  name: string
  dosage?: string
  route?: string
  frequency?: string
  notes?: string
  administeredAt?: Date
  administeredById?: string
}

// 処置情報の定義
export type Treatment = {
  name: string
  description?: string
  notes?: string
  performedAt?: Date
  performedById?: string
}

// 添付ファイルの定義
export type Attachment = {
  id: string
  fileName: string
  fileType: string
  fileSize: number
  url: string
  thumbnailUrl?: string
  uploadedAt: Date
  uploadedById: string
}

// 記録テンプレートの定義
export type RecordTemplate = {
  id: string
  name: string
  description?: string
  type: TemplateType
  createdById: string
  createdAt: Date
  updatedAt: Date
  recordType: RecordType
  content: Partial<RecordContent>
  tags?: string[]
  isDefault?: boolean
  isDeleted: boolean
}

// 定型文の定義
export type TextSnippet = {
  id: string
  userId: string
  category: string
  title: string
  content: string
  createdAt: Date
  updatedAt: Date
  usageCount: number
  isDeleted: boolean
}

// 音声認識設定の定義
export type VoiceRecognitionSetting = {
  userId: string
  isEnabled: boolean
  language: string
  autoSave: boolean
  confidenceThreshold: number
}
