export enum DocumentType {
  CARE_PLAN = "care_plan",
  MEDICAL_INSTRUCTION = "medical_instruction",
  PRESCRIPTION = "prescription",
  REPORT = "report",
  PHOTO = "photo",
  OTHER = "other",
}

export enum DocumentStatus {
  ACTIVE = "active",
  ARCHIVED = "archived",
  DELETED = "deleted",
}

export enum OCRStatus {
  NOT_PROCESSED = "not_processed",
  PROCESSING = "processing",
  COMPLETED = "completed",
  FAILED = "failed",
}

export interface PatientDocument {
  id: string
  patientId: string
  fileName: string
  originalFileName: string
  fileSize: number
  mimeType: string
  documentType: DocumentType
  status: DocumentStatus
  uploadedBy: string
  uploadedAt: Date
  updatedAt: Date
  description?: string
  tags?: string[]

  // OCR関連フィールド
  ocrStatus: OCRStatus
  ocrText?: string
  ocrProcessedAt?: Date
  ocrConfidence?: number
}

export interface DocumentUploadRequest {
  patientId: string
  file: File
  documentType: DocumentType
  description?: string
  tags?: string[]
  enableOCR?: boolean
}

export interface DocumentUpdateRequest {
  id: string
  documentType?: DocumentType
  description?: string
  tags?: string[]
  ocrText?: string
}
