// コミュニケーション機能のデータモデル

export type MessageType = "text" | "image" | "video" | "file" | "notification"
export type MessageStatus = "sent" | "delivered" | "read" | "failed"
export type ChatType = "internal" | "external" | "multidisciplinary"

// チャットルームの定義
export type ChatRoom = {
  id: string
  name: string
  type: ChatType
  createdAt: Date
  updatedAt: Date
  participants: string[] // ユーザーIDの配列
  isArchived: boolean
  metadata?: Record<string, any> // 追加情報（LINE連携IDなど）
}

// メッセージの定義
export type Message = {
  id: string
  roomId: string
  senderId: string
  type: MessageType
  content: string
  attachmentUrl?: string
  createdAt: Date
  status: MessageStatus
  isDeleted: boolean
  replyToId?: string // 返信元メッセージID
  metadata?: Record<string, any> // 追加情報
}

// 通知設定の定義
export type NotificationSetting = {
  userId: string
  roomId: string
  isMuted: boolean
  muteUntil?: Date
  workHoursOnly: boolean
  workHoursStart?: string // "HH:MM" 形式
  workHoursEnd?: string // "HH:MM" 形式
}

// 自動応答設定の定義
export type AutoResponseSetting = {
  roomId: string
  isEnabled: boolean
  message: string
  scheduleType: "always" | "outside_hours" | "custom"
  startTime?: string // "HH:MM" 形式
  endTime?: string // "HH:MM" 形式
  daysOfWeek?: number[] // 0-6 (日曜-土曜)
  forwardToUserId?: string // 転送先ユーザーID
}
