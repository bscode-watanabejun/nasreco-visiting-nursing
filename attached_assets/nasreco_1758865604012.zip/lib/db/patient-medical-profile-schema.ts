import type { SpecialManagementItemId } from "@/lib/definitions/addition-management-defs"

// 患者の医療プロファイルと特別管理加算に関するスキーマ

// 医師指示書情報
export type PhysicianInstruction = {
  confirmedDate?: Date // 指示書確認日
  expiryDate?: Date // 指示書有効期限
  notes?: string // 備考
}

// 特別管理加算の対象項目 (チェックボックス等で選択される項目)
// export type SpecialManagementApplicableItem =
//   | "home_malignant_tumor_guidance" // 在宅悪性腫瘍等患者指導管理
//   | "home_tracheostomy_guidance" // 在宅気管切開患者指導管理
//   | "tracheal_cannula_usage" // 気管カニューレ使用
//   | "indwelling_catheter_management" // 留置カテーテル管理
//   | "home_narcotics_injection_guidance" // 在宅麻薬等注射指導管理
//   | "home_tumor_chemotherapy_injection_guidance" // 在宅腫瘍化学療法注射指導管理
//   | "home_inotropic_agent_infusion_guidance" // 在宅強心剤持続投与指導管理
//   | "home_oxygen_therapy" // 在宅酸素療法
//   | "home_cpap_asv_therapy" // 在宅持続陽圧呼吸療法（CPAP/ASV）
//   | "home_artificial_respiration_therapy" // 在宅人工呼吸療法
//   | "tube_feeding" // 経管栄養（胃ろう・腸ろう・経鼻）
//   | "artificial_anus_bladder" // 人工肛門・人工膀胱
//   | "pressure_ulcer_beyond_dermis" // 真皮を越える褥瘡
//   | "iv_drip_3plus_days_week" // 点滴注射（週3日以上）

// 特別管理加算の判定結果
export type SpecialManagementAdditionStatus = {
  isType1Applicable: boolean // 加算Iの対象か
  isType2Applicable: boolean // 加算IIの対象か
  applicableItems: string[] // 該当する具体的な項目
  priorityType: "type1" | "type2" | null // 優先される加算タイプ (IとII両方該当する場合)
  startDate?: Date // 加算適用開始日
  // physicianInstruction?: PhysicianInstruction // 関連する医師指示書情報
}

// 特別管理加算の対象となる医療管理項目
export type ManagementItems = {
  [key in SpecialManagementItemId]?: boolean
}

// 各管理項目の詳細情報
export type ManagementItemDetails = {
  [key in SpecialManagementItemId]?: {
    [detailKey: string]: string
  }
}

// 患者医療プロファイル (利用者カルテに相当)
export type PatientMedicalProfile = {
  id: string // プロファイルID
  patientId: string // 患者ID (FK)

  managementItems: ManagementItems
  managementItemDetails: ManagementItemDetails
  specialManagementAdditionStatus: SpecialManagementAdditionStatus
  physicianInstruction: PhysicianInstruction
  allergies: string[]
  pastMedicalHistory: string[]
  createdAt: Date
  updatedAt: Date
}

// 特別管理加算の定義 (単位等) - これはマスタデータとして持つか、固定値として扱う
export const SPECIAL_MANAGEMENT_ADDITION_DEFINITIONS = {
  type1: {
    name: "特別管理加算（Ⅰ）",
    units: 500,
    description:
      "在宅悪性腫瘍等患者指導管理、在宅気管切開患者指導管理など特定の高度な管理を必要とする場合に算定（月1回）",
    applicableItems: [
      "home_malignant_tumor_guidance",
      "home_tracheostomy_guidance",
      "tracheal_cannula_usage",
      "indwelling_catheter_management",
      "home_narcotics_injection_guidance",
      "home_tumor_chemotherapy_injection_guidance",
      "home_inotropic_agent_infusion_guidance",
    ] as any[], //SpecialManagementApplicableItem[],
  },
  type2: {
    name: "特別管理加算（Ⅱ）",
    units: 250,
    description: "在宅酸素療法、人工肛門・人工膀胱の管理など特定の管理を必要とする場合に算定（月1回）",
    applicableItems: [
      "home_oxygen_therapy",
      "home_cpap_asv_therapy",
      "home_artificial_respiration_therapy",
      "tube_feeding",
      "artificial_anus_bladder",
      "pressure_ulcer_beyond_dermis",
      "iv_drip_3plus_days_week",
    ] as any[], //SpecialManagementApplicableItem[],
  },
}
