/**
 * 訪問スケジュールと関連データのスキーマ定義
 */

// 訪問タイプの定義（オブジェクトとして定義）
export const VisitType = {
  REGULAR: "regular" as const, // 定期訪問
  EMERGENCY: "emergency" as const, // 緊急訪問
  ASSESSMENT: "assessment" as const, // アセスメント
  SPECIAL: "special" as const, // 特別訪問
  OTHER: "other" as const, // その他
}

// 訪問タイプの型定義
export type VisitTypeValue = (typeof VisitType)[keyof typeof VisitType]

// 訪問ステータスの定義（オブジェクトとして定義）
export const VisitStatus = {
  SCHEDULED: "scheduled" as const, // 予定
  IN_PROGRESS: "in_progress" as const, // 進行中
  COMPLETED: "completed" as const, // 完了
  CANCELLED: "cancelled" as const, // キャンセル
  RESCHEDULED: "rescheduled" as const, // 日程変更
}

// 訪問ステータスの型定義
export type VisitStatusValue = (typeof VisitStatus)[keyof typeof VisitStatus]

// 曜日の定義（オブジェクトとして定義）
export const Weekday = {
  SUNDAY: 0 as const,
  MONDAY: 1 as const,
  TUESDAY: 2 as const,
  WEDNESDAY: 3 as const,
  THURSDAY: 4 as const,
  FRIDAY: 5 as const,
  SATURDAY: 6 as const,
}

// 曜日の型定義
export type WeekdayValue = (typeof Weekday)[keyof typeof Weekday]

// 繰り返しタイプの定義（オブジェクトとして定義）
export const RecurrenceType = {
  DAILY: "daily" as const, // 毎日
  WEEKLY: "weekly" as const, // 毎週
  BIWEEKLY: "biweekly" as const, // 隔週
  MONTHLY: "monthly" as const, // 毎月
  CUSTOM: "custom" as const, // カスタム
}

// 繰り返しタイプの型定義
export type RecurrenceTypeValue = (typeof RecurrenceType)[keyof typeof RecurrenceType]

// 訪問スケジュールのインターフェース
export interface VisitSchedule {
  id: string
  patientId: string
  staffId: string
  visitDate: Date
  startTime: Date
  endTime: Date
  visitType: VisitTypeValue
  status: VisitStatusValue
  note?: string
  recurrenceId?: string
  estimatedTravelTime?: number // 移動時間（分）
  createdAt: Date
  updatedAt: Date
  createdBy: string
  updatedBy?: string
}

// 繰り返しパターンのインターフェース
export interface RecurrencePattern {
  id: string
  patientId: string
  staffId: string
  recurrenceType: RecurrenceTypeValue
  startDate: Date
  endDate?: Date
  startTime: Date
  duration: number // 分単位
  weekdays?: WeekdayValue[] // 週次・隔週の場合の曜日指定
  monthDay?: number // 月次の場合の日付指定
  visitType: VisitTypeValue
  note?: string
  createdAt: Date
  updatedAt: Date
  createdBy: string
  updatedBy?: string
}

// 位置情報のインターフェース
export interface Location {
  id: string
  name: string
  address: string
  latitude: number
  longitude: number
  type: "office" | "patient" | "other" // 事業所、患者宅、その他
  patientId?: string // 患者宅の場合
  createdAt: Date
  updatedAt: Date
}

// ルート情報のインターフェース
export interface Route {
  id: string
  staffId: string
  date: Date
  visitOrder: string[] // 訪問順序（VisitSchedule.idの配列）
  optimized: boolean // 最適化済みかどうか
  totalDistance: number // 総移動距離（km）
  totalTravelTime: number // 総移動時間（分）
  createdAt: Date
  updatedAt: Date
}

// 移動時間・距離のインターフェース
export interface TravelInfo {
  id: string
  fromLocationId: string
  toLocationId: string
  distance: number // km
  duration: number // 分
  trafficCondition: "light" | "normal" | "heavy" // 交通状況
  updatedAt: Date
}
