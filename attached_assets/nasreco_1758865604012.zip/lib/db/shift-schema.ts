/**
 * シフトと勤怠管理のためのデータモデル定義
 *
 * このファイルでは、シフト管理、オンコール管理、勤怠記録に必要な
 * データ構造を定義しています。
 */

// シフトの種類を表す列挙型
export enum ShiftType {
  REGULAR = "regular", // 通常勤務
  NIGHT = "night", // 夜勤
  ONCALL = "oncall", // オンコール
  OFF = "off", // 休日
  PAID_LEAVE = "paid_leave", // 有給休暇
  HALF_DAY = "half_day", // 半日勤務
  TRAINING = "training", // 研修
}

// シフトの状態を表す列挙型
export enum ShiftStatus {
  DRAFT = "draft", // 下書き
  PUBLISHED = "published", // 公開済み
  APPROVED = "approved", // 承認済み
}

// シフトパターンの定義
export type ShiftPattern = {
  id: string
  name: string // パターン名（例: 「週末当番」「平日通常」）
  description?: string // パターンの説明
  pattern: {
    // 曜日ごとのシフト設定
    monday?: ShiftType
    tuesday?: ShiftType
    wednesday?: ShiftType
    thursday?: ShiftType
    friday?: ShiftType
    saturday?: ShiftType
    sunday?: ShiftType
  }
  createdAt: Date
  updatedAt: Date
}

// 個別シフトの定義
export type Shift = {
  id: string
  userId: string // シフト対象のユーザーID
  date: Date // シフト日付
  shiftType: ShiftType // シフトの種類
  startTime?: Date // 開始時間（オプション）
  endTime?: Date // 終了時間（オプション）
  note?: string // 備考
  createdAt: Date
  updatedAt: Date
  createdBy: string // 作成者ID
}

// シフト表の定義
export type ShiftSchedule = {
  id: string
  name: string // シフト表名（例: 「2025年4月シフト」）
  year: number // 年
  month: number // 月
  status: ShiftStatus // シフト表の状態
  shifts: Shift[] // 個別シフトの配列
  createdAt: Date
  updatedAt: Date
  publishedAt?: Date // 公開日時
  approvedAt?: Date // 承認日時
  approvedBy?: string // 承認者ID
}

// シフト希望の定義
export type ShiftRequest = {
  id: string
  userId: string // 希望を出したユーザーID
  requestType: "off" | "oncall" | "specific" // 休み希望/オンコール希望/特定シフト希望
  date: Date // 希望日
  shiftType?: ShiftType // 希望シフトタイプ（特定シフト希望の場合）
  reason?: string // 理由
  status: "pending" | "approved" | "rejected" // 状態
  createdAt: Date
  updatedAt: Date
  reviewedAt?: Date // 審査日時
  reviewedBy?: string // 審査者ID
  reviewNote?: string // 審査コメント
}

// オンコール記録の定義
export type OncallRecord = {
  id: string
  userId: string // オンコール担当者ID
  date: Date // 日付
  startTime: Date // 開始時間
  endTime: Date // 終了時間
  callsReceived: number // 受けた呼び出し数
  emergencyVisits: number // 緊急訪問数
  note?: string // 備考
  createdAt: Date
  updatedAt: Date
}

// 勤怠記録の定義
export type AttendanceRecord = {
  id: string
  userId: string // ユーザーID
  date: Date // 日付
  clockInTime: Date // 出勤時間
  clockOutTime?: Date // 退勤時間
  breakTime?: number // 休憩時間（分）
  totalWorkMinutes?: number // 総労働時間（分）
  overtimeMinutes?: number // 残業時間（分）
  nightWorkMinutes?: number // 深夜労働時間（分）
  status: "pending" | "approved" | "rejected" // 状態
  note?: string // 備考
  location?: {
    // 位置情報（オプション）
    clockIn?: { lat: number; lng: number }
    clockOut?: { lat: number; lng: number }
  }
  createdAt: Date
  updatedAt: Date
  approvedAt?: Date // 承認日時
  approvedBy?: string // 承認者ID
}

// 勤怠集計の定義
export type AttendanceSummary = {
  id: string
  userId: string // ユーザーID
  year: number // 年
  month: number // 月
  workDays: number // 勤務日数
  totalWorkMinutes: number // 総労働時間（分）
  overtimeMinutes: number // 残業時間（分）
  nightWorkMinutes: number // 深夜労働時間（分）
  oncallDays: number // オンコール日数
  paidLeaveDays: number // 有給休暇日数
  status: "draft" | "confirmed" // 状態
  createdAt: Date
  updatedAt: Date
  confirmedAt?: Date // 確定日時
  confirmedBy?: string // 確定者ID
}
