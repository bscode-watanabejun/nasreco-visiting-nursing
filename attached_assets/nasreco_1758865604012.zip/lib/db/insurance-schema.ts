// 保険・加算管理のデータモデル

// 保険種別
export type InsuranceType = "medical" | "nursing_care" | "self_pay" | "other"

// 保険情報
export type InsuranceInfo = {
  id: string
  patientId: string
  insuranceType: InsuranceType
  insuranceNumber?: string
  insuranceName?: string
  insuredPerson?: string // 被保険者（本人または家族の場合）
  relationship?: string // 本人との関係
  validFrom: Date
  validUntil?: Date
  copayRate: number // 自己負担割合（0.1 = 10%）
  isPublicExpense?: boolean // 公費負担の有無
  publicExpenseType?: string // 公費負担の種類
  publicExpenseNumber?: string // 公費負担者番号
  publicExpenseRate?: number // 公費負担割合
  isActive: boolean
  note?: string
  createdAt: Date
  updatedAt: Date
}

// 加算項目
export type AdditionItem = {
  id: string
  code: string
  name: string
  description?: string
  insuranceType: InsuranceType[] // 適用される保険種別
  unitPrice: number // 単価
  calculationType: "per_visit" | "per_month" | "per_hour" | "per_procedure" // 算定方法
  requiresApproval: boolean // 承認が必要かどうか
  requiresDocument: boolean // 書類が必要かどうか
  requiredDocumentType?: string // 必要書類の種類
  maxTimesPerDay?: number // 1日あたりの最大回数
  maxTimesPerMonth?: number // 月あたりの最大回数
  conditions?: string[] // 算定条件（JSONで保存）
  isActive: boolean
  validFrom: Date
  validUntil?: Date
  createdAt: Date
  updatedAt: Date
}

// 患者の加算適用情報
export type PatientAddition = {
  id: string
  patientId: string
  additionId: string
  isApplied: boolean // 適用されているかどうか
  appliedFrom: Date
  appliedUntil?: Date
  approvedBy?: string // 承認者
  approvedAt?: Date
  documentId?: string // 関連書類ID
  note?: string
  createdAt: Date
  updatedAt: Date
}

// 訪問記録の加算情報
export type VisitAddition = {
  id: string
  visitId: string
  additionId: string
  patientId: string
  quantity: number // 算定数量
  unitPrice: number // 単価（記録時点の単価）
  amount: number // 金額（単価×数量）
  isManuallyAdded: boolean // 手動で追加されたかどうか
  addedBy: string // 追加者
  addedAt: Date
  note?: string
}

// 請求データ
export type BillingData = {
  id: string
  patientId: string
  billingMonth: string // YYYY-MM形式
  insuranceType: InsuranceType
  insuranceId: string
  visitCount: number // 訪問回数
  totalBasicFee: number // 基本療養費合計
  totalAdditionFee: number // 加算料合計
  totalAmount: number // 合計金額
  copayRate: number // 自己負担割合
  copayAmount: number // 自己負担額
  insuranceAmount: number // 保険負担額
  publicExpenseAmount?: number // 公費負担額
  status: "draft" | "confirmed" | "submitted" | "paid" // 請求状態
  issuedAt?: Date // 請求書発行日
  paidAt?: Date // 支払日
  note?: string
  createdAt: Date
  updatedAt: Date
}

// 請求明細
export type BillingDetail = {
  id: string
  billingId: string
  visitId?: string
  visitDate?: Date
  itemType: "basic_fee" | "addition" | "other" // 項目種別
  itemCode: string
  itemName: string
  quantity: number
  unitPrice: number
  amount: number
  note?: string
}

// 請求書
export type Invoice = {
  id: string
  billingId: string
  patientId: string
  invoiceNumber: string
  issuedDate: Date
  dueDate: Date
  totalAmount: number
  status: "issued" | "paid" | "overdue" | "cancelled"
  paidAt?: Date
  paidAmount?: number
  paymentMethod?: string
  note?: string
  createdAt: Date
  updatedAt: Date
}

// レセプトデータ
export type ReceiptData = {
  id: string
  billingId: string
  patientId: string
  insuranceId: string
  receiptMonth: string // YYYY-MM形式
  medicalInstitutionCode: string
  receiptNumber: string
  patientInfo: {
    name: string
    dateOfBirth: string
    gender: string
    insuranceNumber: string
    insuredPersonSymbol?: string
    insuredPersonNumber?: string
  }
  medicalFee: {
    totalPoints: number
    totalFee: number
    insuranceFee: number
    copayFee: number
    publicExpenseFee?: number
  }
  details: ReceiptDetail[]
  status: "draft" | "confirmed" | "submitted" | "rejected" | "accepted"
  submittedAt?: Date
  acceptedAt?: Date
  rejectedReason?: string
  note?: string
  createdAt: Date
  updatedAt: Date
}

// レセプト明細
export type ReceiptDetail = {
  id: string
  receiptId: string
  serviceDate: Date
  serviceCode: string
  serviceName: string
  quantity: number
  unit: string
  points: number
  amount: number
}

// 算定チェック結果
export type CalculationCheckResult = {
  id: string
  patientId: string
  billingMonth: string // YYYY-MM形式
  checkDate: Date
  checkItems: CalculationCheckItem[]
  hasWarning: boolean
  hasError: boolean
  checkedBy: string
  confirmedBy?: string
  confirmedAt?: Date
  note?: string
  createdAt: Date
  updatedAt: Date
}

// 算定チェック項目
export type CalculationCheckItem = {
  id: string
  checkResultId: string
  itemType: "addition" | "document" | "limit" | "other"
  itemCode?: string
  itemName: string
  status: "ok" | "warning" | "error"
  message: string
  relatedEntityId?: string // 関連するエンティティID（訪問ID、書類IDなど）
  isResolved: boolean
  resolvedBy?: string
  resolvedAt?: Date
  note?: string
}

// 保険請求設定
export type InsuranceBillingSettings = {
  id: string
  organizationId: string
  medicalInstitutionCode: string
  nursingCareOfficeCode: string
  billingCycle: "monthly" // 請求サイクル
  billingDay: number // 請求日（毎月x日）
  paymentDueDay: number // 支払期限日（毎月x日）
  defaultCopayRate: number // デフォルト自己負担割合
  electronicBillingEnabled: boolean // 電子請求の有効化
  electronicBillingFormat: "medical_receipt" | "nursing_care_receipt" | "both" // 電子請求フォーマット
  autoCalculationEnabled: boolean // 自動計算の有効化
  autoAdditionEnabled: boolean // 自動加算の有効化
  reminderEnabled: boolean // リマインダーの有効化
  reminderDays: number // リマインダー日数（請求日のx日前）
  updatedAt: Date
  updatedBy: string
}
