/**
 * シフト管理のためのユーティリティ関数
 *
 * このファイルでは、シフト管理に関する様々なヘルパー関数を提供します。
 * 日付操作、シフトの計算、表示用フォーマットなどの機能を含みます。
 */

import { ShiftType, type Shift } from "@/lib/db/shift-schema"

/**
 * 指定した年月の日数を取得する
 */
export function getDaysInMonth(year: number, month: number): number {
  return new Date(year, month, 0).getDate()
}

/**
 * 指定した年月の日付配列を生成する
 */
export function getMonthDates(year: number, month: number): Date[] {
  const daysInMonth = getDaysInMonth(year, month)
  const dates: Date[] = []

  for (let day = 1; day <= daysInMonth; day++) {
    dates.push(new Date(year, month - 1, day))
  }

  return dates
}

/**
 * 日付から曜日を取得する（0: 日曜日, 1: 月曜日, ..., 6: 土曜日）
 */
export function getDayOfWeek(date: Date): number {
  return date.getDay()
}

/**
 * 曜日名を取得する（日本語）
 */
export function getDayOfWeekName(dayOfWeek: number): string {
  const dayNames = ["日", "月", "火", "水", "木", "金", "土"]
  return dayNames[dayOfWeek]
}

/**
 * 日付が週末（土日）かどうかを判定する
 */
export function isWeekend(date: Date): boolean {
  const day = getDayOfWeek(date)
  return day === 0 || day === 6 // 0: 日曜日, 6: 土曜日
}

/**
 * 日付が祝日かどうかを判定する（実際の実装では祝日APIや祝日リストを使用）
 */
export function isHoliday(date: Date): boolean {
  // 実際の実装では祝日判定ロジックを追加
  // ここではモックとして特定の日付を祝日とする
  const holidays = [
    "2025-01-01", // 元日
    "2025-01-13", // 成人の日
    "2025-02-11", // 建国記念日
    "2025-02-23", // 天皇誕生日
    "2025-03-21", // 春分の日
    "2025-04-29", // 昭和の日
    "2025-05-03", // 憲法記念日
    "2025-05-04", // みどりの日
    "2025-05-05", // こどもの日
    "2025-07-21", // 海の日
    "2025-08-11", // 山の日
    "2025-09-15", // 敬老の日
    "2025-09-23", // 秋分の日
    "2025-10-13", // スポーツの日
    "2025-11-03", // 文化の日
    "2025-11-23", // 勤労感謝の日
  ]

  const dateString = date.toISOString().split("T")[0]
  return holidays.includes(dateString)
}

/**
 * シフトタイプに応じた表示名を取得する
 */
export function getShiftTypeName(shiftType: ShiftType): string {
  const shiftTypeNames: Record<ShiftType, string> = {
    [ShiftType.REGULAR]: "通常",
    [ShiftType.NIGHT]: "夜勤",
    [ShiftType.ONCALL]: "オンコール",
    [ShiftType.OFF]: "休み",
    [ShiftType.PAID_LEAVE]: "有給",
    [ShiftType.HALF_DAY]: "半日",
    [ShiftType.TRAINING]: "研修",
  }

  return shiftTypeNames[shiftType] || "不明"
}

/**
 * シフトタイプに応じた表示色を取得する
 */
export function getShiftTypeColor(shiftType: ShiftType): string {
  const shiftTypeColors: Record<ShiftType, string> = {
    [ShiftType.REGULAR]: "bg-blue-100 text-blue-800",
    [ShiftType.NIGHT]: "bg-purple-100 text-purple-800",
    [ShiftType.ONCALL]: "bg-amber-100 text-amber-800",
    [ShiftType.OFF]: "bg-gray-100 text-gray-800",
    [ShiftType.PAID_LEAVE]: "bg-green-100 text-green-800",
    [ShiftType.HALF_DAY]: "bg-cyan-100 text-cyan-800",
    [ShiftType.TRAINING]: "bg-indigo-100 text-indigo-800",
  }

  return shiftTypeColors[shiftType] || "bg-gray-100 text-gray-800"
}

/**
 * 特定のユーザーと日付のシフトを取得する
 */
export function getUserShiftForDate(shifts: Shift[], userId: string, date: Date): Shift | undefined {
  const dateString = date.toISOString().split("T")[0]

  return shifts.find((shift) => {
    const shiftDateString = shift.date.toISOString().split("T")[0]
    return shift.userId === userId && shiftDateString === dateString
  })
}

/**
 * 特定の日付のすべてのシフトを取得する
 */
export function getShiftsForDate(shifts: Shift[], date: Date): Shift[] {
  const dateString = date.toISOString().split("T")[0]

  return shifts.filter((shift) => {
    const shiftDateString = shift.date.toISOString().split("T")[0]
    return shiftDateString === dateString
  })
}

/**
 * 特定のユーザーの月間シフト集計を計算する
 */
export function calculateUserMonthlyShiftSummary(shifts: Shift[], userId: string, year: number, month: number) {
  // 対象月のシフトをフィルタリング
  const monthStart = new Date(year, month - 1, 1)
  const monthEnd = new Date(year, month, 0)

  const userShifts = shifts.filter((shift) => {
    return shift.userId === userId && shift.date >= monthStart && shift.date <= monthEnd
  })

  // 各シフトタイプの日数をカウント
  const counts: Record<ShiftType, number> = {
    [ShiftType.REGULAR]: 0,
    [ShiftType.NIGHT]: 0,
    [ShiftType.ONCALL]: 0,
    [ShiftType.OFF]: 0,
    [ShiftType.PAID_LEAVE]: 0,
    [ShiftType.HALF_DAY]: 0,
    [ShiftType.TRAINING]: 0,
  }

  userShifts.forEach((shift) => {
    counts[shift.shiftType]++
  })

  // 勤務日数（通常+夜勤+半日+研修）
  const workDays =
    counts[ShiftType.REGULAR] + counts[ShiftType.NIGHT] + counts[ShiftType.HALF_DAY] * 0.5 + counts[ShiftType.TRAINING]

  return {
    userId,
    year,
    month,
    workDays,
    regularDays: counts[ShiftType.REGULAR],
    nightDays: counts[ShiftType.NIGHT],
    oncallDays: counts[ShiftType.ONCALL],
    offDays: counts[ShiftType.OFF],
    paidLeaveDays: counts[ShiftType.PAID_LEAVE],
    halfDays: counts[ShiftType.HALF_DAY],
    trainingDays: counts[ShiftType.TRAINING],
  }
}

/**
 * オンコール担当回数の制限をチェックする
 * @returns 制限を超えている場合はtrueを返す
 */
export function checkOncallLimitExceeded(
  shifts: Shift[],
  userId: string,
  year: number,
  month: number,
  maxOncallsPerMonth: number,
): boolean {
  const summary = calculateUserMonthlyShiftSummary(shifts, userId, year, month)
  return summary.oncallDays > maxOncallsPerMonth
}

/**
 * 連続オンコール日数をチェックする
 * @returns 連続日数が制限を超えている場合はtrueを返す
 */
export function checkConsecutiveOncallDays(shifts: Shift[], userId: string, maxConsecutiveDays: number): boolean {
  // ユーザーのシフトを日付順にソート
  const userShifts = shifts
    .filter((shift) => shift.userId === userId)
    .sort((a, b) => a.date.getTime() - b.date.getTime())

  let consecutiveDays = 0
  let maxConsecutive = 0

  for (let i = 0; i < userShifts.length; i++) {
    if (userShifts[i].shiftType === ShiftType.ONCALL) {
      consecutiveDays++
      maxConsecutive = Math.max(maxConsecutive, consecutiveDays)
    } else {
      consecutiveDays = 0
    }
  }

  return maxConsecutive > maxConsecutiveDays
}
