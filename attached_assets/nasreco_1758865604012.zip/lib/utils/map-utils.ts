/**
 * 地図連携とルート最適化のためのユーティリティ関数
 */

import type { Location, Route, VisitSchedule } from "@/lib/db/schedule-schema"

/**
 * 2点間の直線距離を計算する（ハーバーサイン公式）
 * @param lat1 出発地点の緯度
 * @param lon1 出発地点の経度
 * @param lat2 到着地点の緯度
 * @param lon2 到着地点の経度
 * @returns 距離（km）
 */
export function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371 // 地球の半径（km）
  const dLat = deg2rad(lat2 - lat1)
  const dLon = deg2rad(lon2 - lon1)
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  const distance = R * c // 距離（km）
  return Math.round(distance * 100) / 100 // 小数点第2位まで
}

/**
 * 度をラジアンに変換する
 */
function deg2rad(deg: number): number {
  return deg * (Math.PI / 180)
}

/**
 * 推定移動時間を計算する（距離から概算）
 * @param distance 距離（km）
 * @param speedKmPerHour 平均速度（km/h）
 * @returns 移動時間（分）
 */
export function estimateTravelTime(distance: number, speedKmPerHour = 30): number {
  const timeHours = distance / speedKmPerHour
  const timeMinutes = Math.ceil(timeHours * 60)
  return timeMinutes
}

/**
 * 最適な訪問順序を計算する（最近傍法）
 * @param startLocation 出発地点
 * @param locations 訪問先の位置情報
 * @param endLocation 到着地点（省略可）
 * @returns 最適な訪問順序の位置情報ID配列
 */
export function calculateOptimalRoute(
  startLocation: Location,
  locations: Location[],
  endLocation?: Location,
): string[] {
  if (locations.length === 0) {
    return []
  }

  const route: string[] = []
  const unvisited = [...locations]
  let currentLocation = startLocation

  // 全ての訪問先を回るまで繰り返す
  while (unvisited.length > 0) {
    // 現在地から最も近い訪問先を探す
    let minDistance = Number.POSITIVE_INFINITY
    let nextLocationIndex = -1

    for (let i = 0; i < unvisited.length; i++) {
      const distance = calculateDistance(
        currentLocation.latitude,
        currentLocation.longitude,
        unvisited[i].latitude,
        unvisited[i].longitude,
      )

      if (distance < minDistance) {
        minDistance = distance
        nextLocationIndex = i
      }
    }

    // 最も近い訪問先を追加
    const nextLocation = unvisited[nextLocationIndex]
    route.push(nextLocation.id)
    currentLocation = nextLocation
    unvisited.splice(nextLocationIndex, 1)
  }

  // 終了地点が指定されている場合は追加
  if (endLocation) {
    route.push(endLocation.id)
  }

  return route
}

/**
 * 訪問スケジュールからルート情報を生成する
 * @param schedules 訪問スケジュール
 * @param patientLocations 患者の位置情報
 * @param officeLocation 事業所の位置情報
 * @returns ルート情報
 */
export function generateRoute(
  schedules: VisitSchedule[],
  patientLocations: Record<string, Location>,
  officeLocation: Location,
): Route {
  // スケジュールを時間順にソート
  const sortedSchedules = [...schedules].sort((a, b) => a.startTime.getTime() - b.startTime.getTime())

  // 訪問先の位置情報を取得
  const visitLocations: Location[] = sortedSchedules.map((schedule) => {
    return patientLocations[schedule.patientId]
  })

  // 総移動距離と時間を計算
  let totalDistance = 0
  let totalTime = 0

  // 事業所から最初の訪問先までの距離と時間
  if (sortedSchedules.length > 0) {
    const firstLocation = patientLocations[sortedSchedules[0].patientId]
    const firstDistance = calculateDistance(
      officeLocation.latitude,
      officeLocation.longitude,
      firstLocation.latitude,
      firstLocation.longitude,
    )
    const firstTime = estimateTravelTime(firstDistance)
    totalDistance += firstDistance
    totalTime += firstTime
  }

  // 訪問先間の距離と時間
  for (let i = 0; i < sortedSchedules.length - 1; i++) {
    const currentLocation = patientLocations[sortedSchedules[i].patientId]
    const nextLocation = patientLocations[sortedSchedules[i + 1].patientId]
    const distance = calculateDistance(
      currentLocation.latitude,
      currentLocation.longitude,
      nextLocation.latitude,
      nextLocation.longitude,
    )
    const time = estimateTravelTime(distance)
    totalDistance += distance
    totalTime += time

    // 移動時間をスケジュールに設定
    sortedSchedules[i + 1] = {
      ...sortedSchedules[i + 1],
      estimatedTravelTime: time,
      estimatedTravelDistance: distance,
    }
  }

  // 最後の訪問先から事業所までの距離と時間
  if (sortedSchedules.length > 0) {
    const lastLocation = patientLocations[sortedSchedules[sortedSchedules.length - 1].patientId]
    const lastDistance = calculateDistance(
      lastLocation.latitude,
      lastLocation.longitude,
      officeLocation.latitude,
      officeLocation.longitude,
    )
    const lastTime = estimateTravelTime(lastDistance)
    totalDistance += lastDistance
    totalTime += lastTime
  }

  // ルート情報を生成
  const route: Route = {
    id: `route-${Date.now()}`,
    staffId: sortedSchedules[0]?.staffId || "",
    date: sortedSchedules[0]?.visitDate || new Date(),
    startLocationId: officeLocation.id,
    endLocationId: officeLocation.id,
    schedules: sortedSchedules,
    totalTravelDistance: Math.round(totalDistance * 100) / 100,
    totalTravelTime: totalTime,
    isOptimized: false,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "system",
  }

  return route
}

/**
 * ルートを最適化する
 * @param route 現在のルート情報
 * @param patientLocations 患者の位置情報
 * @param officeLocation 事業所の位置情報
 * @returns 最適化されたルート情報
 */
export function optimizeRoute(
  route: Route,
  patientLocations: Record<string, Location>,
  officeLocation: Location,
): Route {
  // 訪問先の位置情報を取得
  const visitLocations: Location[] = route.schedules.map((schedule) => {
    return patientLocations[schedule.patientId]
  })

  // 最適な訪問順序を計算
  const optimalOrder = calculateOptimalRoute(officeLocation, visitLocations, officeLocation)

  // スケジュールを最適な順序に並べ替え
  const optimizedSchedules: VisitSchedule[] = []
  for (const locationId of optimalOrder) {
    // 事業所の場合はスキップ
    if (locationId === officeLocation.id) {
      continue
    }

    // 位置情報から患者IDを取得
    const patientId = Object.keys(patientLocations).find((id) => patientLocations[id].id === locationId)

    if (patientId) {
      // 患者IDに対応するスケジュールを探す
      const schedule = route.schedules.find((s) => s.patientId === patientId)
      if (schedule) {
        optimizedSchedules.push(schedule)
      }
    }
  }

  // 総移動距離と時間を再計算
  let totalDistance = 0
  let totalTime = 0

  // 事業所から最初の訪問先までの距離と時間
  if (optimizedSchedules.length > 0) {
    const firstLocation = patientLocations[optimizedSchedules[0].patientId]
    const firstDistance = calculateDistance(
      officeLocation.latitude,
      officeLocation.longitude,
      firstLocation.latitude,
      firstLocation.longitude,
    )
    const firstTime = estimateTravelTime(firstDistance)
    totalDistance += firstDistance
    totalTime += firstTime
  }

  // 訪問先間の距離と時間
  for (let i = 0; i < optimizedSchedules.length - 1; i++) {
    const currentLocation = patientLocations[optimizedSchedules[i].patientId]
    const nextLocation = patientLocations[optimizedSchedules[i + 1].patientId]
    const distance = calculateDistance(
      currentLocation.latitude,
      currentLocation.longitude,
      nextLocation.latitude,
      nextLocation.longitude,
    )
    const time = estimateTravelTime(distance)
    totalDistance += distance
    totalTime += time

    // 移動時間をスケジュールに設定
    optimizedSchedules[i + 1] = {
      ...optimizedSchedules[i + 1],
      estimatedTravelTime: time,
      estimatedTravelDistance: distance,
      routeOrder: i + 1,
    }
  }

  // 最初のスケジュールのルート順序を設定
  if (optimizedSchedules.length > 0) {
    optimizedSchedules[0] = {
      ...optimizedSchedules[0],
      routeOrder: 0,
    }
  }

  // 最後の訪問先から事業所までの距離と時間
  if (optimizedSchedules.length > 0) {
    const lastLocation = patientLocations[optimizedSchedules[optimizedSchedules.length - 1].patientId]
    const lastDistance = calculateDistance(
      lastLocation.latitude,
      lastLocation.longitude,
      officeLocation.latitude,
      officeLocation.longitude,
    )
    const lastTime = estimateTravelTime(lastDistance)
    totalDistance += lastDistance
    totalTime += lastTime
  }

  // 最適化されたルート情報を生成
  const optimizedRoute: Route = {
    ...route,
    schedules: optimizedSchedules,
    totalTravelDistance: Math.round(totalDistance * 100) / 100,
    totalTravelTime: totalTime,
    isOptimized: true,
    updatedAt: new Date(),
    updatedBy: "system",
  }

  return optimizedRoute
}

/**
 * Google Maps URLを生成する
 * @param location 位置情報
 * @returns Google Maps URL
 */
export function generateGoogleMapsUrl(location: Location): string {
  return `https://www.google.com/maps/search/?api=1&query=${location.latitude},${location.longitude}`
}

/**
 * Google Maps ナビゲーションURLを生成する
 * @param origin 出発地点
 * @param destination 目的地
 * @returns Google Maps ナビゲーションURL
 */
export function generateGoogleMapsNavigationUrl(origin: Location, destination: Location): string {
  return `https://www.google.com/maps/dir/?api=1&origin=${origin.latitude},${origin.longitude}&destination=${destination.latitude},${destination.longitude}&travelmode=driving`
}

/**
 * Google Maps 経路URLを生成する
 * @param origin 出発地点
 * @param destination 目的地
 * @param waypoints 経由地点
 * @returns Google Maps 経路URL
 */
export function generateGoogleMapsRouteUrl(origin: Location, destination: Location, waypoints: Location[]): string {
  const waypointsParam = waypoints.map((waypoint) => `${waypoint.latitude},${waypoint.longitude}`).join("|")
  return `https://www.google.com/maps/dir/?api=1&origin=${origin.latitude},${origin.longitude}&destination=${destination.latitude},${destination.longitude}&waypoints=${waypointsParam}&travelmode=driving`
}
