/**
 * 訪問スケジュール管理のためのユーティリティ関数
 */

import { addDays, addMonths, addWeeks, format, getDay, isSameDay } from "date-fns"
import { ja } from "date-fns/locale"
import {
  type RecurrencePattern,
  RecurrenceType,
  type VisitSchedule,
  VisitStatus,
  VisitType,
  Weekday,
  type VisitStatusValue,
  type VisitTypeValue,
  type WeekdayValue,
  type RecurrenceTypeValue,
} from "../db/schedule-schema"

/**
 * 訪問タイプの表示名を取得する
 */
export function getVisitTypeName(visitType: VisitTypeValue): string {
  const visitTypeNames: Record<VisitTypeValue, string> = {
    [VisitType.REGULAR]: "定期訪問",
    [VisitType.EMERGENCY]: "緊急訪問",
    [VisitType.ASSESSMENT]: "アセスメント",
    [VisitType.SPECIAL]: "特別訪問",
    [VisitType.OTHER]: "その他",
  }
  return visitTypeNames[visitType]
}

/**
 * 訪問ステータスの表示名を取得する
 */
export function getVisitStatusName(status: VisitStatusValue): string {
  const statusNames: Record<VisitStatusValue, string> = {
    [VisitStatus.SCHEDULED]: "予定",
    [VisitStatus.IN_PROGRESS]: "進行中",
    [VisitStatus.COMPLETED]: "完了",
    [VisitStatus.CANCELLED]: "キャンセル",
    [VisitStatus.RESCHEDULED]: "日程変更",
  }
  return statusNames[status]
}

/**
 * 訪問ステータスに応じたバッジの色クラスを取得する
 */
export function getVisitStatusColor(status: VisitStatusValue): string {
  const statusColors: Record<VisitStatusValue, string> = {
    [VisitStatus.SCHEDULED]: "bg-blue-100 text-blue-800",
    [VisitStatus.IN_PROGRESS]: "bg-yellow-100 text-yellow-800",
    [VisitStatus.COMPLETED]: "bg-green-100 text-green-800",
    [VisitStatus.CANCELLED]: "bg-red-100 text-red-800",
    [VisitStatus.RESCHEDULED]: "bg-purple-100 text-purple-800",
  }
  return statusColors[status]
}

/**
 * 訪問タイプに応じたバッジの色クラスを取得する
 */
export function getVisitTypeColor(visitType: VisitTypeValue): string {
  const typeColors: Record<VisitTypeValue, string> = {
    [VisitType.REGULAR]: "bg-gray-100 text-gray-800",
    [VisitType.EMERGENCY]: "bg-red-100 text-red-800",
    [VisitType.ASSESSMENT]: "bg-blue-100 text-blue-800",
    [VisitType.SPECIAL]: "bg-purple-100 text-purple-800",
    [VisitType.OTHER]: "bg-gray-100 text-gray-800",
  }
  return typeColors[visitType]
}

/**
 * 曜日の日本語名を取得する
 */
export function getWeekdayName(weekday: WeekdayValue): string {
  const weekdayNames: Record<WeekdayValue, string> = {
    [Weekday.SUNDAY]: "日",
    [Weekday.MONDAY]: "月",
    [Weekday.TUESDAY]: "火",
    [Weekday.WEDNESDAY]: "水",
    [Weekday.THURSDAY]: "木",
    [Weekday.FRIDAY]: "金",
    [Weekday.SATURDAY]: "土",
  }
  return weekdayNames[weekday]
}

/**
 * 繰り返しタイプの表示名を取得する
 */
export function getRecurrenceTypeName(recurrenceType: RecurrenceTypeValue): string {
  const recurrenceTypeNames: Record<RecurrenceTypeValue, string> = {
    [RecurrenceType.DAILY]: "毎日",
    [RecurrenceType.WEEKLY]: "毎週",
    [RecurrenceType.BIWEEKLY]: "隔週",
    [RecurrenceType.MONTHLY]: "毎月",
    [RecurrenceType.CUSTOM]: "カスタム",
  }
  return recurrenceTypeNames[recurrenceType]
}

/**
 * 繰り返しパターンの説明文を生成する
 */
export function getRecurrenceDescription(pattern: RecurrencePattern): string {
  let description = ""

  switch (pattern.recurrenceType) {
    case RecurrenceType.DAILY:
      description = "毎日"
      break
    case RecurrenceType.WEEKLY:
      if (pattern.weekdays && pattern.weekdays.length > 0) {
        const weekdayNames = pattern.weekdays.map((day) => getWeekdayName(day)).join("・")
        description = `毎週 ${weekdayNames}曜日`
      } else {
        description = "毎週"
      }
      break
    case RecurrenceType.BIWEEKLY:
      if (pattern.weekdays && pattern.weekdays.length > 0) {
        const weekdayNames = pattern.weekdays.map((day) => getWeekdayName(day)).join("・")
        description = `隔週 ${weekdayNames}曜日`
      } else {
        description = "隔週"
      }
      break
    case RecurrenceType.MONTHLY:
      if (pattern.monthDay) {
        description = `毎月 ${pattern.monthDay}日`
      } else {
        description = "毎月"
      }
      break
    case RecurrenceType.CUSTOM:
      description = "カスタム"
      break
  }

  // 時間を追加
  const timeStr = format(pattern.startTime, "HH:mm")
  description += ` ${timeStr}`

  // 期間を追加
  if (pattern.endDate) {
    const startDateStr = format(pattern.startDate, "yyyy/MM/dd", { locale: ja })
    const endDateStr = format(pattern.endDate, "yyyy/MM/dd", { locale: ja })
    description += ` (${startDateStr} 〜 ${endDateStr})`
  }

  return description
}

/**
 * 繰り返しパターンから指定期間内の訪問予定を生成する
 */
export function generateSchedulesFromPattern(
  pattern: RecurrencePattern,
  startDate: Date,
  endDate: Date,
): VisitSchedule[] {
  const schedules: VisitSchedule[] = []
  let currentDate = new Date(pattern.startDate)

  // パターンの終了日がある場合は、それを超えないようにする
  if (pattern.endDate && pattern.endDate < endDate) {
    endDate = new Date(pattern.endDate)
  }

  // 開始日より前の場合は、開始日に設定
  if (currentDate < startDate) {
    currentDate = new Date(startDate)
  }

  // 時間部分を取得
  const hours = pattern.startTime.getHours()
  const minutes = pattern.startTime.getMinutes()

  // 繰り返しタイプに応じて予定を生成
  while (currentDate <= endDate) {
    switch (pattern.recurrenceType) {
      case RecurrenceType.DAILY:
        // 日付が範囲内かチェック
        if (currentDate >= startDate && currentDate <= endDate) {
          const scheduleDate = new Date(currentDate)
          scheduleDate.setHours(hours, minutes, 0, 0)

          const endTime = new Date(scheduleDate)
          endTime.setMinutes(endTime.getMinutes() + pattern.duration)

          schedules.push(createScheduleFromPattern(pattern, scheduleDate, endTime))
        }
        currentDate = addDays(currentDate, 1)
        break

      case RecurrenceType.WEEKLY:
        if (pattern.weekdays && pattern.weekdays.length > 0) {
          const currentDay = getDay(currentDate) as WeekdayValue
          if (pattern.weekdays.includes(currentDay) && currentDate >= startDate && currentDate <= endDate) {
            const scheduleDate = new Date(currentDate)
            scheduleDate.setHours(hours, minutes, 0, 0)

            const endTime = new Date(scheduleDate)
            endTime.setMinutes(endTime.getMinutes() + pattern.duration)

            schedules.push(createScheduleFromPattern(pattern, scheduleDate, endTime))
          }
          currentDate = addDays(currentDate, 1)
        } else {
          // 曜日指定がない場合は、開始日から7日ごとに予定を生成
          if (currentDate >= startDate && currentDate <= endDate) {
            const scheduleDate = new Date(currentDate)
            scheduleDate.setHours(hours, minutes, 0, 0)

            const endTime = new Date(scheduleDate)
            endTime.setMinutes(endTime.getMinutes() + pattern.duration)

            schedules.push(createScheduleFromPattern(pattern, scheduleDate, endTime))
          }
          currentDate = addWeeks(currentDate, 1)
        }
        break

      case RecurrenceType.BIWEEKLY:
        if (pattern.weekdays && pattern.weekdays.length > 0) {
          const currentDay = getDay(currentDate) as WeekdayValue
          if (pattern.weekdays.includes(currentDay) && currentDate >= startDate && currentDate <= endDate) {
            // 隔週かどうかを確認（開始日からの週数が偶数週の場合のみ）
            const weeksSinceStart = Math.floor(
              (currentDate.getTime() - pattern.startDate.getTime()) / (7 * 24 * 60 * 60 * 1000),
            )
            if (weeksSinceStart % 2 === 0) {
              const scheduleDate = new Date(currentDate)
              scheduleDate.setHours(hours, minutes, 0, 0)

              const endTime = new Date(scheduleDate)
              endTime.setMinutes(endTime.getMinutes() + pattern.duration)

              schedules.push(createScheduleFromPattern(pattern, scheduleDate, endTime))
            }
          }
          currentDate = addDays(currentDate, 1)
        } else {
          // 曜日指定がない場合は、開始日から14日ごとに予定を生成
          if (currentDate >= startDate && currentDate <= endDate) {
            const scheduleDate = new Date(currentDate)
            scheduleDate.setHours(hours, minutes, 0, 0)

            const endTime = new Date(scheduleDate)
            endTime.setMinutes(endTime.getMinutes() + pattern.duration)

            schedules.push(createScheduleFromPattern(pattern, scheduleDate, endTime))
          }
          currentDate = addWeeks(currentDate, 2)
        }
        break

      case RecurrenceType.MONTHLY:
        if (pattern.monthDay) {
          // 月の日付が指定されている場合
          if (currentDate.getDate() === pattern.monthDay && currentDate >= startDate && currentDate <= endDate) {
            const scheduleDate = new Date(currentDate)
            scheduleDate.setHours(hours, minutes, 0, 0)

            const endTime = new Date(scheduleDate)
            endTime.setMinutes(endTime.getMinutes() + pattern.duration)

            schedules.push(createScheduleFromPattern(pattern, scheduleDate, endTime))
          }

          // 次の日に進む
          currentDate = addDays(currentDate, 1)

          // 月が変わったら、指定された日に設定
          if (currentDate.getDate() === 1) {
            const nextMonth = new Date(currentDate)
            // 存在しない日付の場合は月の最終日に設定
            try {
              nextMonth.setDate(pattern.monthDay)
              currentDate = nextMonth
            } catch (e) {
              // 無効な日付の場合（例：2月30日）は、月の最終日に設定
              const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0)
              currentDate = lastDayOfMonth
            }
          }
        } else {
          // 日付指定がない場合は、開始日から1ヶ月ごとに予定を生成
          if (currentDate >= startDate && currentDate <= endDate) {
            const scheduleDate = new Date(currentDate)
            scheduleDate.setHours(hours, minutes, 0, 0)

            const endTime = new Date(scheduleDate)
            endTime.setMinutes(endTime.getMinutes() + pattern.duration)

            schedules.push(createScheduleFromPattern(pattern, scheduleDate, endTime))
          }
          currentDate = addMonths(currentDate, 1)
        }
        break

      case RecurrenceType.CUSTOM:
        // カスタムの場合は、パターンに応じた処理を実装
        // ここでは単純に次の日に進む
        currentDate = addDays(currentDate, 1)
        break
    }
  }

  return schedules
}

/**
 * 繰り返しパターンから訪問予定を作成する
 */
function createScheduleFromPattern(pattern: RecurrencePattern, startTime: Date, endTime: Date): VisitSchedule {
  return {
    id: `schedule-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    patientId: pattern.patientId,
    staffId: pattern.staffId,
    visitDate: new Date(startTime),
    startTime: new Date(startTime),
    endTime: new Date(endTime),
    visitType: pattern.visitType,
    status: VisitStatus.SCHEDULED,
    recurrenceId: pattern.id,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: pattern.createdBy,
  }
}

/**
 * 指定された日付の訪問予定を取得する
 */
export function getSchedulesForDate(schedules: VisitSchedule[], date: Date): VisitSchedule[] {
  return schedules.filter((schedule) => isSameDay(new Date(schedule.visitDate), date))
}

/**
 * 指定されたスタッフの訪問予定を取得する
 */
export function getSchedulesForStaff(schedules: VisitSchedule[], staffId: string): VisitSchedule[] {
  return schedules.filter((schedule) => schedule.staffId === staffId)
}

/**
 * 指定された患者の訪問予定を取得する
 */
export function getSchedulesForPatient(schedules: VisitSchedule[], patientId: string): VisitSchedule[] {
  return schedules.filter((schedule) => schedule.patientId === patientId)
}

/**
 * 訪問予定を時間順にソートする
 */
export function sortSchedulesByTime(schedules: VisitSchedule[]): VisitSchedule[] {
  return [...schedules].sort((a, b) => a.startTime.getTime() - b.startTime.getTime())
}

/**
 * 訪問時間をフォーマットする（例：09:00 - 10:30）
 */
export function formatVisitTime(startTime: Date, endTime: Date): string {
  return `${format(startTime, "HH:mm")} - ${format(endTime, "HH:mm")}`
}

/**
 * 訪問予定の所要時間を計算する（分）
 */
export function calculateVisitDuration(startTime: Date, endTime: Date): number {
  return Math.round((endTime.getTime() - startTime.getTime()) / (1000 * 60))
}

/**
 * 訪問予定が重複しているかチェックする
 */
export function checkScheduleOverlap(
  schedule: VisitSchedule,
  existingSchedules: VisitSchedule[],
): VisitSchedule | null {
  // 同じスタッフの予定のみをチェック
  const staffSchedules = existingSchedules.filter(
    (s) => s.staffId === schedule.staffId && s.id !== schedule.id && s.status !== VisitStatus.CANCELLED,
  )

  // 時間が重複する予定を探す
  for (const existingSchedule of staffSchedules) {
    const newStart = new Date(schedule.startTime).getTime()
    const newEnd = new Date(schedule.endTime).getTime()
    const existingStart = new Date(existingSchedule.startTime).getTime()
    const existingEnd = new Date(existingSchedule.endTime).getTime()

    // 重複チェック
    if (
      (newStart >= existingStart && newStart < existingEnd) ||
      (newEnd > existingStart && newEnd <= existingEnd) ||
      (newStart <= existingStart && newEnd >= existingEnd)
    ) {
      return existingSchedule
    }
  }

  return null
}

/**
 * 訪問予定の移動時間を考慮した実現可能性をチェックする
 */
export function checkScheduleFeasibility(
  schedules: VisitSchedule[],
  travelTimes: Record<string, number>, // locationId1-locationId2 -> 移動時間（分）
): { feasible: boolean; issues: { scheduleId: string; issue: string }[] } {
  const sortedSchedules = sortSchedulesByTime(schedules)
  const issues: { scheduleId: string; issue: string }[] = []

  for (let i = 0; i < sortedSchedules.length - 1; i++) {
    const currentSchedule = sortedSchedules[i]
    const nextSchedule = sortedSchedules[i + 1]

    // 同じスタッフの連続する予定のみチェック
    if (currentSchedule.staffId !== nextSchedule.staffId) {
      continue
    }

    const currentEnd = new Date(currentSchedule.endTime).getTime()
    const nextStart = new Date(nextSchedule.startTime).getTime()
    const availableTime = (nextStart - currentEnd) / (1000 * 60) // 分単位

    // 移動時間を取得
    const travelTimeKey = `${currentSchedule.patientId}-${nextSchedule.patientId}`
    const estimatedTravelTime = travelTimes[travelTimeKey] || 30 // デフォルト30分

    if (availableTime < estimatedTravelTime) {
      issues.push({
        scheduleId: nextSchedule.id,
        issue: `移動時間が不足しています。必要時間: ${estimatedTravelTime}分、利用可能時間: ${Math.round(availableTime)}分`,
      })
    }
  }

  return {
    feasible: issues.length === 0,
    issues,
  }
}
