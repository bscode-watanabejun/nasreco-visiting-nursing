// 開発用のモックデータ - シンプル化バージョン
import type { Tenant, User, Session } from "../db/schema"
import { hashPassword } from "./password"

// テナントのモックデータ
export const tenants: Tenant[] = [
  {
    id: "tenant-1",
    name: "医療法人 健康会",
    domain: "kenkokai.example.com",
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
  {
    id: "tenant-2",
    name: "訪問看護ステーション ひまわり",
    domain: "himawari.example.com",
    createdAt: new Date("2024-01-02"),
    updatedAt: new Date("2024-01-02"),
  },
]

// シンプルなハッシュを使用したパスワード
// 実際のパスワード: password123
const simpleHashedPassword = "ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f"

// ユーザーのモックデータ
export const users: User[] = [
  {
    id: "user-1",
    tenantId: "tenant-1",
    email: "admin@kenkokai.example.com",
    name: "管理者 太郎",
    passwordHash: simpleHashedPassword,
    role: "admin",
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
  {
    id: "user-2",
    tenantId: "tenant-1",
    email: "yamada@kenkokai.example.com",
    name: "山田 花子",
    passwordHash: simpleHashedPassword,
    role: "staff",
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
  {
    id: "user-3",
    tenantId: "tenant-2",
    email: "admin@himawari.example.com",
    name: "鈴木 管理者",
    passwordHash: simpleHashedPassword,
    role: "admin",
    createdAt: new Date("2024-01-02"),
    updatedAt: new Date("2024-01-02"),
  },
]

// セッションのモックデータ
export const sessions: Session[] = []

// 初期化時にパスワードが正しくハッシュ化されているか確認
console.log("Mock data initialized")
console.log(`Test password hash: ${hashPassword("password123")}`)
console.log(`Stored password hash: ${users[0].passwordHash}`)
console.log(`Hash match: ${hashPassword("password123") === users[0].passwordHash}`)
