// パスワードのハッシュ化と検証 - シンプル化バージョン
import crypto from "crypto"

// 開発環境用の単純なハッシュ関数
export function hashPassword(password: string): string {
  try {
    console.log("Hashing password")
    // 単純なハッシュ（開発環境用）
    // 注意: 本番環境では bcrypt や Argon2 などを使用すべき
    const hash = crypto.createHash("sha256").update(password).digest("hex")
    return hash
  } catch (error) {
    console.error("Error hashing password:", error)
    // エラー時はフォールバックとして元のパスワードを返す（開発環境のみ）
    return password
  }
}

// パスワード検証
export function verifyPassword(storedPassword: string, suppliedPassword: string): boolean {
  try {
    console.log("Verifying password")

    // モックデータ用の特別なケース
    if (storedPassword.includes(":")) {
      // 以前のフォーマット（salt:hash）の場合
      const [salt, storedHash] = storedPassword.split(":")
      if (!salt || !storedHash) {
        console.error("Invalid stored password format")
        return false
      }

      const suppliedHash = crypto.pbkdf2Sync(suppliedPassword, salt, 1000, 64, "sha512").toString("hex")
      return storedHash === suppliedHash
    }

    // 新しいシンプルなフォーマット
    const hashedSupplied = crypto.createHash("sha256").update(suppliedPassword).digest("hex")
    const result = storedPassword === hashedSupplied
    console.log(`Password verification result: ${result}`)
    return result
  } catch (error) {
    console.error("Error verifying password:", error)
    return false
  }
}
