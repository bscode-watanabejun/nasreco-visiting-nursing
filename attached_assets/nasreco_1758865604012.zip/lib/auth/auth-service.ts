// 認証サービス - デバッグ強化バージョン
import { v4 as uuidv4 } from "uuid"
import { users, sessions, tenants } from "./mock-data"
import { verifyPassword, hashPassword } from "./password"
import { signJWT } from "./jwt"
import type { User, Session } from "../db/schema"

// ユーザーの検索
export function findUserByEmail(email: string): User | undefined {
  console.log(`Finding user by email: ${email}`)
  const user = users.find((user) => user.email === email)
  console.log(`User found: ${!!user}`)
  return user
}

export function findUserById(id: string): User | undefined {
  console.log(`Finding user by ID: ${id}`)
  const user = users.find((user) => user.id === id)
  console.log(`User found: ${!!user}`)
  return user
}

export function findTenantByDomain(domain: string): string | undefined {
  const tenant = tenants.find((t) => t.domain === domain)
  return tenant?.id
}

// ログイン処理
export async function login(email: string, password: string) {
  console.log(`Login attempt for email: ${email}`)

  try {
    // ユーザー検索
    const user = findUserByEmail(email)

    if (!user) {
      console.log("User not found")
      return { success: false, error: "ユーザーが見つかりません" }
    }

    // パスワード検証
    console.log("Verifying password")
    const passwordValid = verifyPassword(user.passwordHash, password)

    if (!passwordValid) {
      console.log("Invalid password")
      return { success: false, error: "パスワードが正しくありません" }
    }

    // セッションの作成
    console.log("Creating session")
    const sessionId = uuidv4()
    const session: Session = {
      id: sessionId,
      userId: user.id,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24時間後
      createdAt: new Date(),
    }

    sessions.push(session)
    console.log(`Session created: ${sessionId}`)

    // JWTの生成
    console.log("Generating token")
    const payload = {
      userId: user.id,
      tenantId: user.tenantId,
      sessionId: session.id,
      role: user.role,
    }

    const token = await signJWT(payload)
    console.log("Token generated successfully")

    // ユーザー情報の返却
    return {
      success: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        tenantId: user.tenantId,
      },
      token,
    }
  } catch (error) {
    console.error("Login service error:", error)
    return { success: false, error: "ログイン処理中にエラーが発生しました" }
  }
}

// ユーザー登録処理
export async function register(
  email: string,
  password: string,
  name: string,
  tenantId: string,
  role: "admin" | "manager" | "staff" = "staff",
) {
  console.log(`Registration attempt for email: ${email}`)

  try {
    // メールアドレスの重複チェック
    const existingUser = findUserByEmail(email)

    if (existingUser) {
      console.log("Email already in use")
      return { success: false, error: "このメールアドレスは既に使用されています" }
    }

    // テナントの存在チェック
    const tenantExists = tenants.some((t) => t.id === tenantId)

    if (!tenantExists) {
      console.log("Tenant not found")
      return { success: false, error: "指定されたテナントが存在しません" }
    }

    // 新しいユーザーの作成
    console.log("Creating new user")
    const userId = uuidv4()
    const newUser: User = {
      id: userId,
      tenantId,
      email,
      name,
      passwordHash: hashPassword(password),
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    users.push(newUser)
    console.log(`User created: ${userId}`)

    // セッションの作成
    console.log("Creating session")
    const sessionId = uuidv4()
    const session: Session = {
      id: sessionId,
      userId: newUser.id,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24時間後
      createdAt: new Date(),
    }

    sessions.push(session)
    console.log(`Session created: ${sessionId}`)

    // JWTの生成
    console.log("Generating token")
    const payload = {
      userId: newUser.id,
      tenantId: newUser.tenantId,
      sessionId: session.id,
      role: newUser.role,
    }

    const token = await signJWT(payload)
    console.log("Token generated successfully")

    // ユーザー情報の返却
    return {
      success: true,
      user: {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        tenantId: newUser.tenantId,
      },
      token,
    }
  } catch (error) {
    console.error("Registration service error:", error)
    return { success: false, error: "登録処理中にエラーが発生しました" }
  }
}

// ログアウト処理
export function logout(sessionId: string) {
  console.log(`Logout attempt for session: ${sessionId}`)

  try {
    const sessionIndex = sessions.findIndex((session) => session.id === sessionId)

    if (sessionIndex !== -1) {
      sessions.splice(sessionIndex, 1)
      console.log("Session removed")
    } else {
      console.log("Session not found")
    }

    return { success: true }
  } catch (error) {
    console.error("Logout service error:", error)
    return { success: false, error: "ログアウト処理中にエラーが発生しました" }
  }
}

// 現在のユーザー情報を取得
export function getCurrentUser(userId: string) {
  console.log(`Getting current user: ${userId}`)

  try {
    const user = findUserById(userId)

    if (!user) {
      console.log("User not found")
      return null
    }

    console.log("User found, returning info")
    return {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      tenantId: user.tenantId,
    }
  } catch (error) {
    console.error("Get current user service error:", error)
    return null
  }
}
