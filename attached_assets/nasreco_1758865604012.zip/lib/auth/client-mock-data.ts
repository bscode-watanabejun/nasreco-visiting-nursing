// クライアントサイド用のモックデータ
export const users = [
  {
    id: "user-1",
    tenantId: "tenant-1",
    email: "admin@kenkokai.example.com",
    name: "管理者 太郎",
    password: "password123", // 注意: これは開発環境専用です
    role: "admin",
  },
  {
    id: "user-2",
    tenantId: "tenant-1",
    email: "yamada@kenkokai.example.com",
    name: "山田 花子",
    password: "password123", // 注意: これは開発環境専用です
    role: "staff",
  },
  {
    id: "user-3",
    tenantId: "tenant-2",
    email: "admin@himawari.example.com",
    name: "鈴木 管理者",
    password: "password123", // 注意: これは開発環境専用です
    role: "admin",
  },
]

export const tenants = [
  {
    id: "tenant-1",
    name: "医療法人 健康会",
    domain: "kenkokai.example.com",
  },
  {
    id: "tenant-2",
    name: "訪問看護ステーション ひまわり",
    domain: "himawari.example.com",
  },
]
