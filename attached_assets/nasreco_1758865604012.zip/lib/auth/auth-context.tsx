// クライアントサイドのみの認証コンテキスト
"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { users } from "./client-mock-data"

// ユーザータイプの定義
type User = {
  id: string
  name: string
  email: string
  role: string
  tenantId: string
}

// 認証コンテキストの型定義
type AuthContextType = {
  user: User | null
  loading: boolean
  error: string | null
  login: (email: string, password: string) => Promise<void>
  register: (email: string, password: string, name: string, confirmPassword: string) => Promise<void>
  logout: () => Promise<void>
}

// 認証コンテキストの作成
const AuthContext = createContext<AuthContextType | undefined>(undefined)

// ローカルストレージのキー
const USER_STORAGE_KEY = "nasreco-user"

// 認証プロバイダーコンポーネント
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  // 初期化時にローカルストレージからユーザー情報を取得
  useEffect(() => {
    try {
      // クライアントサイドでのみ実行
      if (typeof window !== "undefined") {
        const storedUser = localStorage.getItem(USER_STORAGE_KEY)
        if (storedUser) {
          setUser(JSON.parse(storedUser))
        }
      }
    } catch (error) {
      console.error("Failed to load user from localStorage:", error)
    } finally {
      setLoading(false)
    }
  }, [])

  // ログイン処理（クライアントサイドのみ）
  const login = async (email: string, password: string) => {
    console.log(`Login attempt for: ${email}`)
    setLoading(true)
    setError(null)

    try {
      // 意図的な遅延を追加（APIリクエストをシミュレート）
      await new Promise((resolve) => setTimeout(resolve, 500))

      // モックデータからユーザーを検索
      const foundUser = users.find((u) => u.email === email)

      if (!foundUser) {
        throw new Error("ユーザーが見つかりません")
      }

      // パスワード検証
      if (foundUser.password !== password) {
        throw new Error("パスワードが正しくありません")
      }

      // ユーザー情報（パスワードを除く）
      const userInfo = {
        id: foundUser.id,
        name: foundUser.name,
        email: foundUser.email,
        role: foundUser.role,
        tenantId: foundUser.tenantId,
      }

      // ローカルストレージに保存
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(userInfo))

      // ユーザー情報を設定
      setUser(userInfo)

      // ダッシュボードにリダイレクト
      router.push("/dashboard")
    } catch (error) {
      console.error("Login error:", error)
      setError(error instanceof Error ? error.message : "認証エラーが発生しました")
    } finally {
      setLoading(false)
    }
  }

  // 登録処理（クライアントサイドのみ）
  const register = async (email: string, password: string, name: string, confirmPassword: string) => {
    setLoading(true)
    setError(null)

    try {
      // 入力検証
      if (!email || !password || !name || !confirmPassword) {
        throw new Error("全ての項目を入力してください")
      }

      if (password !== confirmPassword) {
        throw new Error("パスワードが一致しません")
      }

      if (password.length < 8) {
        throw new Error("パスワードは8文字以上である必要があります")
      }

      // メールアドレスの形式チェック
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (!emailRegex.test(email)) {
        throw new Error("有効なメールアドレスを入力してください")
      }

      // 意図的な遅延を追加（APIリクエストをシミュレート）
      await new Promise((resolve) => setTimeout(resolve, 500))

      // メールアドレスの重複チェック
      const existingUser = users.find((u) => u.email === email)
      if (existingUser) {
        throw new Error("このメールアドレスは既に使用されています")
      }

      // ドメインからテナントを特定
      const domain = email.split("@")[1]
      const tenantId = "tenant-1" // 簡易化のため固定値

      // 新しいユーザー情報
      const newUser = {
        id: `user-${Date.now()}`,
        name,
        email,
        role: "staff",
        tenantId,
      }

      // ローカルストレージに保存
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(newUser))

      // ユーザー情報を設定
      setUser(newUser)

      // ダッシュボードにリダイレクト
      router.push("/dashboard")
    } catch (error) {
      console.error("Registration error:", error)
      setError(error instanceof Error ? error.message : "登録処理中にエラーが発生しました")
    } finally {
      setLoading(false)
    }
  }

  // ログアウト処理
  const logout = async () => {
    setLoading(true)

    try {
      // 意図的な遅延を追加（APIリクエストをシミュレート）
      await new Promise((resolve) => setTimeout(resolve, 300))

      // ローカルストレージからユーザー情報を削除
      localStorage.removeItem(USER_STORAGE_KEY)

      // ユーザー情報をクリア
      setUser(null)

      // ログインページにリダイレクト
      router.push("/")
    } catch (error) {
      console.error("Logout error:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthContext.Provider value={{ user, loading, error, login, register, logout }}>{children}</AuthContext.Provider>
  )
}

// 認証コンテキストを使用するためのフック
export function useAuth() {
  const context = useContext(AuthContext)

  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }

  return context
}
