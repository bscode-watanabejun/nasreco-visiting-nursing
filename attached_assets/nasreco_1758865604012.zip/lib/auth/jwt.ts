// JWT トークンの生成と検証 - 超シンプル化バージョン
import type { NextRequest } from "next/server"

// 単純な文字列ベースのトークン生成（開発用）
export async function signJWT(payload: any) {
  try {
    // 開発環境用の単純なトークン生成
    // 注意: これは本番環境では使用しないでください
    const tokenData = {
      ...payload,
      exp: Math.floor(Date.now() / 1000) + 24 * 60 * 60, // 24時間後
    }

    // Base64エンコード
    const token = Buffer.from(JSON.stringify(tokenData)).toString("base64")
    console.log("Generated token successfully")
    return token
  } catch (error) {
    console.error("JWT signing error:", error)
    throw new Error("トークン生成に失敗しました")
  }
}

// トークンの検証
export async function verifyJWT(token: string) {
  try {
    // Base64デコード
    const decoded = JSON.parse(Buffer.from(token, "base64").toString())

    // 有効期限チェック
    if (decoded.exp && decoded.exp < Math.floor(Date.now() / 1000)) {
      console.log("Token expired")
      return null
    }

    return decoded
  } catch (error) {
    console.error("JWT verification error:", error)
    return null
  }
}

// リクエストからトークンを取得
export function getTokenFromRequest(request: NextRequest) {
  try {
    // Authorization ヘッダーからトークンを取得
    const authHeader = request.headers.get("authorization")
    if (authHeader && authHeader.startsWith("Bearer ")) {
      return authHeader.substring(7)
    }

    // クッキーからトークンを取得
    return request.cookies.get("auth-token")?.value
  } catch (error) {
    console.error("Error getting token from request:", error)
    return null
  }
}
