import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ShiftCalendar } from "@/components/shift/shift-calendar"
import { AlertCircle, Save, FileText, Copy, Calendar } from "lucide-react"

export default function ShiftEditPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">シフト編集</h2>
          <p className="text-muted-foreground">2025年4月のシフト表を編集しています</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Calendar className="mr-2 h-4 w-4" />
            月選択
          </Button>
          <Button variant="outline">
            <Copy className="mr-2 h-4 w-4" />
            テンプレート
          </Button>
          <Button variant="outline">
            <FileText className="mr-2 h-4 w-4" />
            インポート
          </Button>
          <Button>
            <Save className="mr-2 h-4 w-4" />
            保存
          </Button>
        </div>
      </div>

      <Card className="bg-amber-50 border-amber-200">
        <CardContent className="pt-6">
          <div className="flex items-start space-x-2">
            <AlertCircle className="h-5 w-5 text-amber-500 mt-0.5" />
            <div>
              <p className="font-medium text-amber-800">編集モード</p>
              <p className="text-sm text-amber-700">
                シフト表のセルをクリックして、シフトを編集できます。
                編集が完了したら「保存」ボタンをクリックしてください。
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <ShiftCalendar initialYear={2025} initialMonth={4} editable={true} />

      <div className="flex justify-end space-x-2">
        <Button variant="outline">キャンセル</Button>
        <Button>保存</Button>
      </div>
    </div>
  )
}
