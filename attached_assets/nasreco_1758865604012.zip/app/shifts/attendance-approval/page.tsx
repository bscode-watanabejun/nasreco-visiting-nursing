"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CheckCircle2, XCircle, Calendar, FileCheck, Filter, Download } from "lucide-react"

// モックデータ
const mockAttendanceData = [
  {
    id: "att1",
    userName: "山田 花子",
    userId: "user1",
    date: new Date(2025, 3, 1),
    clockIn: "08:30",
    clockOut: "17:15",
    workHours: "8時間45分",
    overtime: "15分",
    status: "pending",
  },
  {
    id: "att2",
    userName: "佐藤 次郎",
    userId: "user2",
    date: new Date(2025, 3, 1),
    clockIn: "08:45",
    clockOut: "18:30",
    workHours: "9時間45分",
    overtime: "1時間15分",
    status: "pending",
  },
  {
    id: "att3",
    userName: "鈴木 三郎",
    userId: "user3",
    date: new Date(2025, 3, 1),
    clockIn: "09:00",
    clockOut: "17:00",
    workHours: "8時間",
    overtime: "0分",
    status: "approved",
  },
  {
    id: "att4",
    userName: "田中 四郎",
    userId: "user4",
    date: new Date(2025, 3, 1),
    clockIn: "08:30",
    clockOut: "19:00",
    workHours: "10時間30分",
    overtime: "2時間",
    status: "rejected",
  },
]

export default function AttendanceApprovalPage() {
  const [attendanceData, setAttendanceData] = useState(mockAttendanceData)

  // 承認処理
  const handleApprove = (id: string) => {
    setAttendanceData(attendanceData.map((item) => (item.id === id ? { ...item, status: "approved" } : item)))
  }

  // 却下処理
  const handleReject = (id: string) => {
    setAttendanceData(attendanceData.map((item) => (item.id === id ? { ...item, status: "rejected" } : item)))
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">勤怠承認</h2>
          <p className="text-muted-foreground">スタッフの勤怠記録を確認・承認します</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Calendar className="mr-2 h-4 w-4" />
            日付選択
          </Button>
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" />
            フィルター
          </Button>
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            エクスポート
          </Button>
        </div>
      </div>

      <Tabs defaultValue="pending" className="space-y-4">
        <TabsList>
          <TabsTrigger value="pending">
            未承認 ({attendanceData.filter((item) => item.status === "pending").length})
          </TabsTrigger>
          <TabsTrigger value="approved">
            承認済 ({attendanceData.filter((item) => item.status === "approved").length})
          </TabsTrigger>
          <TabsTrigger value="rejected">
            却下 ({attendanceData.filter((item) => item.status === "rejected").length})
          </TabsTrigger>
          <TabsTrigger value="all">すべて ({attendanceData.length})</TabsTrigger>
        </TabsList>

        {["pending", "approved", "rejected", "all"].map((tabValue) => (
          <TabsContent key={tabValue} value={tabValue}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileCheck className="mr-2 h-5 w-5 text-primary" />
                  勤怠記録
                  {tabValue === "pending" && " (未承認)"}
                  {tabValue === "approved" && " (承認済)"}
                  {tabValue === "rejected" && " (却下)"}
                </CardTitle>
                <CardDescription>
                  {new Date().toLocaleDateString("ja-JP", { year: "numeric", month: "long", day: "numeric" })}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>スタッフ</TableHead>
                      <TableHead>日付</TableHead>
                      <TableHead>出勤</TableHead>
                      <TableHead>退勤</TableHead>
                      <TableHead>勤務時間</TableHead>
                      <TableHead>残業</TableHead>
                      <TableHead>状態</TableHead>
                      <TableHead>アクション</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {attendanceData
                      .filter((item) => tabValue === "all" || item.status === tabValue)
                      .map((item) => (
                        <TableRow key={item.id}>
                          <TableCell className="font-medium">{item.userName}</TableCell>
                          <TableCell>
                            {item.date.toLocaleDateString("ja-JP", { month: "numeric", day: "numeric" })}
                          </TableCell>
                          <TableCell>{item.clockIn}</TableCell>
                          <TableCell>{item.clockOut}</TableCell>
                          <TableCell>{item.workHours}</TableCell>
                          <TableCell>{item.overtime}</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                item.status === "approved"
                                  ? "default"
                                  : item.status === "rejected"
                                    ? "destructive"
                                    : "outline"
                              }
                            >
                              {item.status === "approved" ? "承認済" : item.status === "rejected" ? "却下" : "未承認"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleApprove(item.id)}
                                disabled={item.status === "approved"}
                              >
                                <CheckCircle2 className="h-4 w-4 text-green-500" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleReject(item.id)}
                                disabled={item.status === "rejected"}
                              >
                                <XCircle className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
