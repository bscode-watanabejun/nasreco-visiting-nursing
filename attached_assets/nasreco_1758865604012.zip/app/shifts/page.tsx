import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ShiftCalendar } from "@/components/shift/shift-calendar"
import { OncallManagement } from "@/components/shift/oncall-management"
import { AttendanceRecordComponent } from "@/components/attendance/attendance-record"

export default function ShiftsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">シフト・勤怠管理</h2>
        <p className="text-muted-foreground">スタッフのシフト、オンコール当番、勤怠記録を管理します</p>
      </div>

      <Tabs defaultValue="shift-calendar" className="space-y-4">
        <TabsList>
          <TabsTrigger value="shift-calendar">シフト表</TabsTrigger>
          <TabsTrigger value="oncall">オンコール管理</TabsTrigger>
          <TabsTrigger value="attendance">勤怠記録</TabsTrigger>
          <TabsTrigger value="attendance-history">勤怠履歴</TabsTrigger>
        </TabsList>

        <TabsContent value="shift-calendar">
          <ShiftCalendar editable={true} />
        </TabsContent>

        <TabsContent value="oncall">
          <OncallManagement />
        </TabsContent>

        <TabsContent value="attendance">
          <AttendanceRecordComponent viewMode="day" />
        </TabsContent>

        <TabsContent value="attendance-history">
          <AttendanceRecordComponent viewMode="list" />
        </TabsContent>
      </Tabs>
    </div>
  )
}
