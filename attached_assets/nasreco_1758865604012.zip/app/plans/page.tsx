import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Filter, FileText, Pencil, ClipboardList, MoreHorizontal } from "lucide-react"

export default function PlansPage() {
  // 仮の看護計画データ
  const plans = [
    {
      id: 1,
      patient: "佐藤 一郎",
      diagnosis: "非効果的血糖コントロール",
      createdAt: "2025-02-15",
      status: "有効",
    },
    {
      id: 2,
      patient: "田中 正男",
      diagnosis: "心拍出量減少",
      createdAt: "2025-03-01",
      status: "有効",
    },
    {
      id: 3,
      patient: "鈴木 良子",
      diagnosis: "移動障害",
      createdAt: "2025-01-20",
      status: "有効",
    },
    {
      id: 4,
      patient: "佐藤 花子",
      diagnosis: "疼痛",
      createdAt: "2025-03-10",
      status: "有効",
    },
    {
      id: 5,
      patient: "高橋 健太",
      diagnosis: "非効果的呼吸パターン",
      createdAt: "2025-02-28",
      status: "有効",
    },
  ]

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">看護計画管理</h2>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          新規看護計画作成
        </Button>
      </div>

      <Tabs defaultValue="active" className="space-y-4">
        <TabsList>
          <TabsTrigger value="active">有効な計画</TabsTrigger>
          <TabsTrigger value="completed">終了した計画</TabsTrigger>
          <TabsTrigger value="templates">テンプレート</TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="space-y-4">
          <div className="flex items-center space-x-2">
            <div className="flex-1">
              <Input placeholder="患者名または診断名で検索..." />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>有効な看護計画一覧</CardTitle>
              <CardDescription>
                現在有効な看護計画の一覧です。詳細を確認するには計画をクリックしてください。
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>計画ID</TableHead>
                    <TableHead>患者名</TableHead>
                    <TableHead>看護診断</TableHead>
                    <TableHead>作成日</TableHead>
                    <TableHead>状態</TableHead>
                    <TableHead>操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {plans.map((plan) => (
                    <TableRow key={plan.id}>
                      <TableCell>{plan.id}</TableCell>
                      <TableCell className="font-medium">{plan.patient}</TableCell>
                      <TableCell>{plan.diagnosis}</TableCell>
                      <TableCell>{plan.createdAt}</TableCell>
                      <TableCell>
                        <div className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold bg-green-100 text-green-800">
                          {plan.status}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-1">
                          <Button variant="ghost" size="icon">
                            <FileText className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <ClipboardList className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="completed">
          <Card>
            <CardHeader>
              <CardTitle>終了した看護計画</CardTitle>
              <CardDescription>目標達成または終了した看護計画の一覧です。</CardDescription>
            </CardHeader>
            <CardContent>
              <p>終了した看護計画のデータがここに表示されます。</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates">
          <Card>
            <CardHeader>
              <CardTitle>看護計画テンプレート</CardTitle>
              <CardDescription>よく使用される看護計画のテンプレート一覧です。</CardDescription>
            </CardHeader>
            <CardContent>
              <p>テンプレートデータがここに表示されます。</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
