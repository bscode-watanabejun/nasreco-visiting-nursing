// ログアウトAPI - 超シンプル化バージョン
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  console.log("Logout API called")

  try {
    // レスポンスの作成
    const response = NextResponse.json({ success: true })

    // クッキーの削除
    response.cookies.set({
      name: "auth-token",
      value: "",
      path: "/",
      maxAge: 0, // 即時期限切れ
    })

    console.log("Logout successful")
    return response
  } catch (error) {
    console.error("Logout API error:", error)
    return NextResponse.json({ error: "ログアウト処理中にエラーが発生しました" }, { status: 500 })
  }
}
