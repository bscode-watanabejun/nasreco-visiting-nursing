// ログインAPI - 超シンプル化バージョン
import { type NextRequest, NextResponse } from "next/server"
import { users } from "@/lib/auth/mock-data"

export async function POST(request: NextRequest) {
  console.log("Login API called")

  try {
    // リクエストボディの解析
    const body = await request.json()
    console.log("Request body parsed")

    const { email, password } = body

    // 入力検証
    if (!email || !password) {
      console.log("Missing email or password")
      return NextResponse.json({ error: "メールアドレスとパスワードは必須です" }, { status: 400 })
    }

    // 超シンプルな認証（モックデータから直接検索）
    console.log(`Authenticating user: ${email}`)
    const user = users.find((u) => u.email === email)

    if (!user) {
      console.log("User not found")
      return NextResponse.json({ error: "ユーザーが見つかりません" }, { status: 401 })
    }

    // 超シンプルなパスワード検証（開発環境用）
    // 注意: 本番環境では絶対に使用しないでください
    const isPasswordValid = password === "password123" // テスト用の固定パスワード

    if (!isPasswordValid) {
      console.log("Invalid password")
      return NextResponse.json({ error: "パスワードが正しくありません" }, { status: 401 })
    }

    // ユーザー情報（パスワードハッシュを除く）
    const userInfo = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      tenantId: user.tenantId,
    }

    // 超シンプルなトークン（開発環境用）
    const token = Buffer.from(
      JSON.stringify({
        userId: user.id,
        exp: Date.now() + 24 * 60 * 60 * 1000,
      }),
    ).toString("base64")

    console.log("Authentication successful")

    // レスポンスの作成
    const response = NextResponse.json({ user: userInfo })

    // クッキーの設定
    response.cookies.set({
      name: "auth-token",
      value: token,
      httpOnly: true,
      path: "/",
      maxAge: 60 * 60 * 24, // 24時間
    })

    console.log("Login successful, returning response")
    return response
  } catch (error) {
    console.error("Login API error:", error)
    return NextResponse.json({ error: "認証処理中にエラーが発生しました" }, { status: 500 })
  }
}
