// 現在のユーザー情報を取得するAPI - 超シンプル化バージョン
import { type NextRequest, NextResponse } from "next/server"
import { users } from "@/lib/auth/mock-data"

export async function GET(request: NextRequest) {
  console.log("Me API called")

  try {
    // クッキーからトークンを取得
    const token = request.cookies.get("auth-token")?.value
    console.log(`Token exists: ${!!token}`)

    if (!token) {
      return NextResponse.json({ error: "認証されていません" }, { status: 401 })
    }

    // トークンのデコード（超シンプル版）
    let payload
    try {
      const decoded = Buffer.from(token, "base64").toString()
      payload = JSON.parse(decoded)
      console.log("Token decoded successfully")
    } catch (error) {
      console.error("Token decode error:", error)
      return NextResponse.json({ error: "無効なトークンです" }, { status: 401 })
    }

    // トークンの有効期限チェック
    if (!payload.userId || (payload.exp && payload.exp < Date.now())) {
      console.log("Token invalid or expired")
      return NextResponse.json({ error: "トークンの有効期限が切れています" }, { status: 401 })
    }

    // ユーザー情報の取得
    console.log(`Getting user info for: ${payload.userId}`)
    const user = users.find((u) => u.id === payload.userId)

    if (!user) {
      console.log("User not found")
      return NextResponse.json({ error: "ユーザーが見つかりません" }, { status: 404 })
    }

    // ユーザー情報（パスワードハッシュを除く）
    const userInfo = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      tenantId: user.tenantId,
    }

    console.log("User found, returning info")
    return NextResponse.json({ user: userInfo })
  } catch (error) {
    console.error("Get current user API error:", error)
    return NextResponse.json({ error: "ユーザー情報の取得中にエラーが発生しました" }, { status: 500 })
  }
}
