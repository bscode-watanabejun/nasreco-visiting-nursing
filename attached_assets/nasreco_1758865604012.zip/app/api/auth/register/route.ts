// 登録API - デバッグ強化バージョン
import { type NextRequest, NextResponse } from "next/server"
import { register, findTenantByDomain } from "@/lib/auth/auth-service"

export async function POST(request: NextRequest) {
  console.log("Register API called")

  try {
    // リクエストボディの解析
    const body = await request.json()
    console.log("Request body parsed", { email: body.email ? "***@***" : "missing" })

    const { email, password, name, confirmPassword, tenantId: providedTenantId } = body

    // 必須フィールドのチェック
    if (!email || !password || !name || !confirmPassword) {
      console.log("Missing required fields")
      return NextResponse.json({ error: "全ての項目を入力してください" }, { status: 400 })
    }

    // パスワード確認のチェック
    if (password !== confirmPassword) {
      console.log("Passwords do not match")
      return NextResponse.json({ error: "パスワードが一致しません" }, { status: 400 })
    }

    // パスワードの強度チェック
    if (password.length < 8) {
      console.log("Password too short")
      return NextResponse.json({ error: "パスワードは8文字以上である必要があります" }, { status: 400 })
    }

    // メールアドレスの形式チェック
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      console.log("Invalid email format")
      return NextResponse.json({ error: "有効なメールアドレスを入力してください" }, { status: 400 })
    }

    // テナントIDの決定
    let tenantId = providedTenantId

    if (!tenantId) {
      console.log("No tenant ID provided, trying to find by domain")
      const domain = email.split("@")[1]
      tenantId = findTenantByDomain(domain)

      if (!tenantId) {
        console.log("Tenant not found for domain")
        return NextResponse.json(
          { error: "所属する組織が特定できません。管理者にお問い合わせください。" },
          { status: 400 },
        )
      }
    }

    // 登録処理
    console.log("Calling register service")
    const result = await register(email, password, name, tenantId)
    console.log("Register service result", { success: result.success })

    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 400 })
    }

    // レスポンスの作成
    console.log("Creating successful response")
    const response = NextResponse.json({ user: result.user })

    // クッキーの設定
    console.log("Setting auth cookie")
    response.cookies.set({
      name: "auth-token",
      value: result.token,
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24, // 24時間
    })

    console.log("Registration successful, returning response")
    return response
  } catch (error) {
    console.error("Registration API error:", error)
    return NextResponse.json({ error: "登録処理中にエラーが発生しました" }, { status: 500 })
  }
}
