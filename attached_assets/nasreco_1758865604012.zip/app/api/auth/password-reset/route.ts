// パスワードリセットAPI
import { type NextRequest, NextResponse } from "next/server"
import { findUserByEmail } from "@/lib/auth/auth-service"

// 実際の実装ではメール送信機能を追加する必要があります
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email } = body

    if (!email) {
      return NextResponse.json({ error: "メールアドレスは必須です" }, { status: 400 })
    }

    const user = findUserByEmail(email)

    // ユーザーが存在しない場合でも、セキュリティのために同じレスポンスを返す
    // これにより、攻撃者はメールアドレスの存在を推測できなくなる
    return NextResponse.json({
      success: true,
      message: "パスワードリセットの手順をメールで送信しました（開発環境では実際には送信されません）",
    })
  } catch (error) {
    console.error("Password reset error:", error)
    return NextResponse.json({ error: "パスワードリセット処理中にエラーが発生しました" }, { status: 500 })
  }
}
