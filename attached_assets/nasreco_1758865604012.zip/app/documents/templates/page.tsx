import { TemplateManager } from "@/components/documents/template-manager"

export default function DocumentTemplatesPage() {
  return (
    <div className="container mx-auto py-6">
      <TemplateManager />
    </div>
  )
}
