"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DocumentCreator } from "@/components/documents/document-creator"
import type { Document, DocumentTemplate } from "@/lib/db/document-schema"

// モックデータ - 実際の実装ではAPIから取得
const mockDocument: Document = {
  id: "doc-4",
  templateId: "template-4",
  templateVersion: 1,
  documentType: "consent",
  patientId: "patient-3",
  title: "鈴木良子様 個人情報取扱同意書",
  content: "<h1>個人情報取扱同意書</h1><p>同意日: 2025年1月10日</p>...",
  status: "draft",
  createdAt: new Date("2025-01-10"),
  updatedAt: new Date("2025-01-10"),
  createdBy: "user-1",
  signatures: [],
  approvalHistory: [],
  isDeleted: false,
}

const mockTemplate: DocumentTemplate = {
  id: "template-4",
  name: "個人情報取扱同意書",
  description: "個人情報の取り扱いに関する同意書",
  documentType: "consent",
  content: "<h1>個人情報取扱同意書</h1><p>同意日: {{consentDate}}</p>...",
  placeholders: ["consentDate", "patientName", "patientAddress"],
  createdAt: new Date("2025-01-15"),
  updatedAt: new Date("2025-01-15"),
  createdBy: "user-2",
  isActive: true,
  version: 1,
  requiredSignatures: [{ id: "sig-1", role: "patient", description: "利用者署名", isRequired: true, order: 1 }],
}

export default function EditDocumentPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [document, setDocument] = useState<Document | null>(null)
  const [template, setTemplate] = useState<DocumentTemplate | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // 実際の実装ではAPIから書類データを取得
    setIsLoading(true)

    // モックデータを使用
    setDocument(mockDocument)
    setTemplate(mockTemplate)

    setIsLoading(false)
  }, [params.id])

  const handleSave = (updatedDocument: Document) => {
    // 実際の実装ではAPIを呼び出して保存
    console.log("Saving document:", updatedDocument)

    // 保存後に書類一覧ページに戻る
    router.push("/documents")
  }

  if (isLoading) {
    return (
      <div className="container mx-auto py-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" onClick={() => router.push("/documents")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            戻る
          </Button>
          <div>
            <h2 className="text-2xl font-bold">書類を読み込み中...</h2>
          </div>
        </div>
      </div>
    )
  }

  if (!document || !template) {
    return (
      <div className="container mx-auto py-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" onClick={() => router.push("/documents")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            戻る
          </Button>
          <div>
            <h2 className="text-2xl font-bold">書類が見つかりません</h2>
            <p className="text-muted-foreground">指定された書類は存在しないか、アクセス権限がありません。</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6">
      <DocumentCreator
        initialTemplate={template}
        initialPatientId={document.patientId}
        onSave={handleSave}
        onSubmit={handleSave}
      />
    </div>
  )
}
