"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Download, Pencil, Check, X, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SignaturePad } from "@/components/documents/signature-pad"
import type { Document, DocumentStatus, Signature } from "@/lib/db/document-schema"

// モックデータ - 実際の実装ではAPIから取得
const mockDocument: Document = {
  id: "doc-1",
  templateId: "template-1",
  templateVersion: 1,
  documentType: "care_plan",
  patientId: "patient-1",
  title: "佐藤一郎様 訪問看護計画書",
  content: "<h1>訪問看護計画書</h1><p>患者名: 佐藤 一郎</p><p>生年月日: 1955年4月10日</p>...",
  status: "approved",
  createdAt: new Date("2025-03-01"),
  updatedAt: new Date("2025-03-05"),
  createdBy: "user-1",
  approvedBy: "user-2",
  approvedAt: new Date("2025-03-05"),
  signatures: [
    {
      id: "sig-1",
      documentId: "doc-1",
      signerName: "佐藤 一郎",
      signerRole: "patient",
      signatureData: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA...",
      signedAt: new Date("2025-03-03"),
      isValid: true,
    },
    {
      id: "sig-2",
      documentId: "doc-1",
      signerName: "山田 花子",
      signerRole: "nurse",
      signatureData: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA...",
      signedAt: new Date("2025-03-04"),
      isValid: true,
    },
  ],
  approvalHistory: [
    {
      id: "approval-1",
      documentId: "doc-1",
      stepId: "step-1",
      stepName: "看護師確認",
      approverId: "user-1",
      approverName: "山田 花子",
      action: "approve",
      timestamp: new Date("2025-03-04"),
    },
    {
      id: "approval-2",
      documentId: "doc-1",
      stepId: "step-2",
      stepName: "管理者承認",
      approverId: "user-2",
      approverName: "鈴木 次郎",
      action: "approve",
      timestamp: new Date("2025-03-05"),
    },
  ],
  expiresAt: new Date("2025-09-01"),
  isDeleted: false,
  pdfUrl: "/documents/doc-1.pdf",
}

// モックデータ - 患者情報
const mockPatients = [
  { id: "patient-1", name: "佐藤 一郎", age: 68 },
  { id: "patient-2", name: "田中 正男", age: 75 },
  { id: "patient-3", name: "鈴木 良子", age: 82 },
  { id: "patient-4", name: "佐藤 花子", age: 45 },
  { id: "patient-5", name: "高橋 健太", age: 58 },
]

// 書類タイプの表示名マッピング
const documentTypeLabels: Record<string, string> = {
  care_plan: "訪問看護計画書",
  progress_report: "経過報告書",
  service_contract: "サービス利用契約書",
  medical_instruction: "訪問看護指示書",
  assessment: "アセスメント",
  consent: "同意書",
  other: "その他",
}

// 書類ステータスの表示名マッピング
const documentStatusLabels: Record<DocumentStatus, string> = {
  draft: "下書き",
  pending: "承認待ち",
  approved: "承認済み",
  rejected: "却下",
  signed: "署名済み",
  expired: "期限切れ",
  archived: "アーカイブ",
}

// ステータスに応じたバッジの色
const statusBadgeVariant = (status: DocumentStatus): "default" | "secondary" | "destructive" | "outline" => {
  switch (status) {
    case "approved":
      return "default"
    case "signed":
      return "default"
    case "pending":
      return "secondary"
    case "rejected":
      return "destructive"
    case "expired":
      return "destructive"
    default:
      return "outline"
  }
}

export default function DocumentDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [document, setDocument] = useState<Document | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<"document" | "signatures" | "history">("document")

  useEffect(() => {
    // 実際の実装ではAPIから書類データを取得
    setIsLoading(true)

    // モックデータを使用
    setDocument(mockDocument)

    setIsLoading(false)
  }, [params.id])

  // 患者名を取得
  const getPatientName = (patientId: string): string => {
    const patient = mockPatients.find((p) => p.id === patientId)
    return patient ? patient.name : "不明"
  }

  // 署名の追加
  const handleAddSignature = (signature: Omit<Signature, "id" | "documentId" | "signedAt" | "isValid">) => {
    if (!document) return

    // 実際の実装ではAPIを呼び出して署名を保存
    const newSignature: Signature = {
      id: `sig-${Date.now()}`,
      documentId: document.id,
      signerName: signature.signerName,
      signerRole: signature.signerRole,
      signatureData: signature.signatureData,
      signedAt: new Date(),
      ipAddress: "127.0.0.1", // 実際の実装ではクライアントのIPアドレスを取得
      deviceInfo: signature.deviceInfo,
      isValid: true,
    }

    const updatedDocument: Document = {
      ...document,
      signatures: [...document.signatures, newSignature],
      status: document.status === "approved" ? ("signed" as DocumentStatus) : document.status,
      updatedAt: new Date(),
    }

    setDocument(updatedDocument)

    // 成功メッセージを表示
    alert("署名が保存されました")
  }

  if (isLoading) {
    return (
      <div className="container mx-auto py-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" onClick={() => router.push("/documents")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            戻る
          </Button>
          <div>
            <h2 className="text-2xl font-bold">書類を読み込み中...</h2>
          </div>
        </div>
      </div>
    )
  }

  if (!document) {
    return (
      <div className="container mx-auto py-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" onClick={() => router.push("/documents")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            戻る
          </Button>
          <div>
            <h2 className="text-2xl font-bold">書類が見つかりません</h2>
            <p className="text-muted-foreground">指定された書類は存在しないか、アクセス権限がありません。</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" onClick={() => router.push("/documents")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            戻る
          </Button>
          <div>
            <h2 className="text-2xl font-bold">{document.title}</h2>
            <p className="text-muted-foreground">
              {getPatientName(document.patientId)} - {documentTypeLabels[document.documentType]}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <Badge variant={statusBadgeVariant(document.status)}>{documentStatusLabels[document.status]}</Badge>
          <div className="flex space-x-2">
            {document.pdfUrl && (
              <Button variant="outline" onClick={() => window.open(document.pdfUrl, "_blank")}>
                <Download className="mr-2 h-4 w-4" />
                PDFダウンロード
              </Button>
            )}
            {document.status === "draft" && (
              <Button onClick={() => router.push(`/documents/edit/${document.id}`)}>
                <Pencil className="mr-2 h-4 w-4" />
                編集
              </Button>
            )}
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
        <TabsList>
          <TabsTrigger value="document">書類内容</TabsTrigger>
          <TabsTrigger value="signatures">署名 ({document.signatures.length})</TabsTrigger>
          <TabsTrigger value="history">履歴 ({document.approvalHistory.length})</TabsTrigger>
        </TabsList>
        <TabsContent value="document" className="mt-6">
          <Card>
            <CardContent className="p-6">
              <div className="border rounded-md p-4 min-h-[60vh]">
                <div dangerouslySetInnerHTML={{ __html: document.content }} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="signatures" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>電子署名</CardTitle>
              <CardDescription>この書類に関連する電子署名を管理します</CardDescription>
            </CardHeader>
            <CardContent>
              <SignaturePad
                documentId={document.id}
                existingSignatures={document.signatures}
                onSave={handleAddSignature}
                readOnly={document.status === "expired" || document.status === "archived"}
              />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="history" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>承認履歴</CardTitle>
              <CardDescription>この書類の承認履歴を表示します</CardDescription>
            </CardHeader>
            <CardContent>
              {document.approvalHistory.length > 0 ? (
                <div className="space-y-4">
                  {document.approvalHistory.map((history) => (
                    <div key={history.id} className="flex items-start justify-between border-b pb-4 last:border-0">
                      <div>
                        <div className="flex items-center">
                          <span className="font-medium">{history.stepName}</span>
                          <Badge variant={history.action === "approve" ? "default" : "destructive"} className="ml-2">
                            {history.action === "approve" ? "承認" : history.action === "reject" ? "却下" : "確認"}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {history.approverName} ({new Date(history.timestamp).toLocaleString()})
                        </p>
                        {history.comment && <p className="text-sm mt-2 bg-muted p-2 rounded-md">{history.comment}</p>}
                      </div>
                      <div className="flex items-center">
                        {history.action === "approve" ? (
                          <Check className="h-5 w-5 text-green-500" />
                        ) : history.action === "reject" ? (
                          <X className="h-5 w-5 text-red-500" />
                        ) : (
                          <Check className="h-5 w-5 text-blue-500" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <p>承認履歴はありません</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {document.expiresAt && new Date() > document.expiresAt && (
        <div className="mt-6">
          <Card className="border-destructive">
            <CardContent className="p-4">
              <div className="flex items-center text-destructive">
                <AlertTriangle className="h-5 w-5 mr-2" />
                <p>この書類は有効期限が切れています（期限: {document.expiresAt.toLocaleDateString()}）</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
