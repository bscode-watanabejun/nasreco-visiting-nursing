import { DocumentList } from "@/components/documents/document-list"

export default function DocumentsPage() {
  return (
    <div className="container mx-auto py-6">
      <DocumentList />
    </div>
  )
}
