import { DocumentCreator } from "@/components/documents/document-creator"

export default function CreateDocumentPage() {
  return (
    <div className="container mx-auto py-6">
      <DocumentCreator />
    </div>
  )
}
