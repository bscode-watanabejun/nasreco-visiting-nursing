import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { FileText, UserPlus } from "lucide-react"

const mockPatients = [
  {
    id: "patient-1",
    name: "田中 正男",
    age: 78,
    gender: "男性",
    disease: "高血圧、糖尿病",
    status: "active",
    hasSpecialAddition: true,
  },
  {
    id: "patient-2",
    name: "鈴木 花子",
    age: 85,
    gender: "女性",
    disease: "心不全、認知症",
    status: "active",
    hasSpecialAddition: true,
  },
  {
    id: "patient-3",
    name: "佐藤 一郎",
    age: 68,
    gender: "男性",
    disease: "脳梗塞後遺症",
    status: "discharged",
    hasSpecialAddition: false,
  },
]

export default function PatientsPage() {
  return (
    <div className="container mx-auto p-4 sm:p-6 lg:p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">患者一覧</h1>
          <p className="text-muted-foreground">登録されている患者の一覧です。</p>
        </div>
        <Button>
          <UserPlus className="mr-2 h-4 w-4" />
          新規患者登録
        </Button>
      </div>
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>氏名</TableHead>
                <TableHead className="hidden sm:table-cell">年齢</TableHead>
                <TableHead className="hidden md:table-cell">主な疾患</TableHead>
                <TableHead className="hidden sm:table-cell">ステータス</TableHead>
                <TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockPatients.map((patient) => (
                <TableRow key={patient.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <span>{patient.name}</span>
                      {patient.hasSpecialAddition && <Badge variant="destructive">特管</Badge>}
                    </div>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell">{patient.age}</TableCell>
                  <TableCell className="hidden md:table-cell">{patient.disease}</TableCell>
                  <TableCell className="hidden sm:table-cell">
                    <Badge variant={patient.status === "active" ? "default" : "secondary"}>
                      {patient.status === "active" ? "利用中" : "退院"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Link href={`/patients/${patient.id}/documents`} passHref>
                      <Button variant="outline" size="sm">
                        <FileText className="mr-2 h-4 w-4" />
                        書類管理
                      </Button>
                    </Link>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
