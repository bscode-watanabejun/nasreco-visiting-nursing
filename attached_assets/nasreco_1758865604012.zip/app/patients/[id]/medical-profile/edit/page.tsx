"use client"

import { useState, useEffect, type FormEvent, useMemo } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import type {
  PatientMedicalProfile,
  PhysicianInstruction,
  SpecialManagementAdditionStatus,
  ManagementItems,
} from "@/lib/db/patient-medical-profile-schema"
import { specialManagementItems } from "@/lib/definitions/addition-management-defs" // インポート

// 仮のDatePickerコンポーネント
const DatePicker = ({ date, onDateChange }: { date?: Date; onDateChange: (date: Date | undefined) => void }) => {
  const formatDate = (d?: Date) => d?.toISOString().split("T")[0] || ""
  return (
    <Input
      type="date"
      value={formatDate(date)}
      onChange={(e) => onDateChange(e.target.value ? new Date(e.target.value) : undefined)}
    />
  )
}

// モックデータストアとfetch/save関数 (前回定義したものを流用、必要に応じて調整)
const mockProfileStore: { [key: string]: PatientMedicalProfile } = {}

// 自動判定ロジック (スキーマ変更に合わせて調整)
function calculateSpecialManagementAdditionStatusFromProfile(
  profileItems?: Partial<ManagementItems>,
): Pick<
  SpecialManagementAdditionStatus,
  "isType1Applicable" | "isType2Applicable" | "applicableItems" | "priorityType"
> {
  const items = profileItems || {}
  let isType1 = false
  let isType2 = false
  const applicableItems: string[] = [] // string[] に変更 (specialManagementItemsのid)

  specialManagementItems.typeI.items.forEach((itemDef) => {
    if (items[itemDef.id as keyof ManagementItems]) {
      isType1 = true
      applicableItems.push(itemDef.id)
    }
  })
  specialManagementItems.typeII.items.forEach((itemDef) => {
    if (items[itemDef.id as keyof ManagementItems]) {
      isType2 = true
      if (!applicableItems.includes(itemDef.id)) {
        // 重複を避ける
        applicableItems.push(itemDef.id)
      }
    }
  })

  let priorityType: "type1" | "type2" | null = null
  if (isType1) {
    priorityType = "type1"
  } else if (isType2) {
    priorityType = "type2"
  }

  return {
    isType1Applicable: isType1,
    isType2Applicable: isType2,
    applicableItems: applicableItems,
    priorityType: priorityType,
  }
}

async function fetchMedicalProfile(patientId: string): Promise<PatientMedicalProfile | null> {
  if (mockProfileStore[patientId]) {
    return JSON.parse(JSON.stringify(mockProfileStore[patientId]))
  }
  if (patientId === "patient-1") {
    // テストデータ
    const initialProfileForPatient1: PatientMedicalProfile = {
      id: `profile-${patientId}`,
      patientId: patientId,
      managementItems: {
        tracheal_cannula: true, // 特管Ⅰ (スキーマ変更に合わせてキー名をスネークケースに)
        oxygen_therapy: true, // 特管Ⅱ
      },
      managementItemDetails: {
        // 詳細情報のテストデータ
        tracheal_cannula: { exchange_frequency: "週1回" }, // requireDetailの項目をキーに
        oxygen_therapy: { flow_rate_l_min: "2", usage_time_hours_day: "24" },
      },
      specialManagementAdditionStatus: {
        isType1Applicable: true,
        isType2Applicable: true,
        applicableItems: ["tracheal_cannula", "oxygen_therapy"],
        priorityType: "type1",
        startDate: new Date("2024-05-01"),
      },
      physicianInstruction: {
        confirmedDate: new Date("2024-04-28"),
        expiryDate: new Date("2025-04-27"),
        notes: "医師指示書サンプル備考",
      },
      allergies: ["ペニシリン"],
      pastMedicalHistory: ["高血圧"],
      createdAt: new Date("2024-05-01"),
      updatedAt: new Date("2024-05-15"),
    }
    mockProfileStore[patientId] = initialProfileForPatient1
    return JSON.parse(JSON.stringify(initialProfileForPatient1))
  }
  if (patientId === "patient-2") {
    // 田中正男のテストデータ（心不全、腎機能低下）
    const initialProfileForPatient2: PatientMedicalProfile = {
      id: `profile-${patientId}`,
      patientId: patientId,
      managementItems: {
        oxygen_therapy: true, // 在宅酸素療法（特管Ⅱ）
        iv_drip_3plus_days: true, // 点滴注射週3日以上（特管Ⅱ）
      },
      managementItemDetails: {
        oxygen_therapy: { flow_rate_l_min: "3", usage_time_hours_day: "18" },
        iv_drip_3plus_days: { frequency_per_week: "4", infusion_type: "利尿剤" },
      },
      specialManagementAdditionStatus: {
        isType1Applicable: false,
        isType2Applicable: true,
        applicableItems: ["oxygen_therapy", "iv_drip_3plus_days"],
        priorityType: "type2",
        startDate: new Date("2024-03-01"),
      },
      physicianInstruction: {
        confirmedDate: new Date("2024-02-28"),
        expiryDate: new Date("2025-02-27"),
        notes: "心不全管理のための在宅酸素療法および点滴管理",
      },
      allergies: ["造影剤"],
      pastMedicalHistory: ["心筋梗塞", "高血圧"],
      createdAt: new Date("2024-03-01"),
      updatedAt: new Date("2024-03-15"),
    }
    mockProfileStore[patientId] = initialProfileForPatient2
    return JSON.parse(JSON.stringify(initialProfileForPatient2))
  }

  if (patientId === "patient-3") {
    // 鈴木良子のテストデータ（脳梗塞後遺症）
    const initialProfileForPatient3: PatientMedicalProfile = {
      id: `profile-${patientId}`,
      patientId: patientId,
      managementItems: {
        tube_feeding: true, // 経管栄養（特管Ⅱ）
        pressure_ulcer_beyond_dermis: true, // 真皮を越える褥瘡（特管Ⅱ）
      },
      managementItemDetails: {
        tube_feeding: { feeding_route: "胃ろう", feeding_frequency: "1日4回" },
        pressure_ulcer_beyond_dermis: { ulcer_location: "仙骨部", ulcer_stage: "ステージ3" },
      },
      specialManagementAdditionStatus: {
        isType1Applicable: false,
        isType2Applicable: true,
        applicableItems: ["tube_feeding", "pressure_ulcer_beyond_dermis"],
        priorityType: "type2",
        startDate: new Date("2024-01-15"),
      },
      physicianInstruction: {
        confirmedDate: new Date("2024-01-10"),
        expiryDate: new Date("2025-01-09"),
        notes: "脳梗塞後遺症による嚥下障害のための経管栄養管理および褥瘡処置",
      },
      allergies: [],
      pastMedicalHistory: ["脳梗塞", "高血圧", "糖尿病"],
      createdAt: new Date("2024-01-15"),
      updatedAt: new Date("2024-01-30"),
    }
    mockProfileStore[patientId] = initialProfileForPatient3
    return JSON.parse(JSON.stringify(initialProfileForPatient3))
  }
  return null
}

async function saveMedicalProfile(profileData: PatientMedicalProfile): Promise<PatientMedicalProfile> {
  const patientId = profileData.patientId!
  // 保存時に判定ロジックを再実行してstatusを更新
  const calculatedStatus = calculateSpecialManagementAdditionStatusFromProfile(profileData.managementItems)

  const now = new Date()
  const savedProfile: PatientMedicalProfile = {
    ...profileData,
    id: profileData.id || `profile-${patientId}-${Date.now()}`,
    specialManagementAdditionStatus: {
      ...(profileData.specialManagementAdditionStatus || {}), // 既存のstartDateやphysicianInstructionを保持
      ...calculatedStatus, // 計算結果で上書き
    },
    updatedAt: now,
    createdAt: profileData.createdAt || now,
  }
  mockProfileStore[patientId] = savedProfile
  console.log("Updated mockProfileStore:", mockProfileStore)
  return JSON.parse(JSON.stringify(savedProfile))
}

export default function MedicalProfileEditPage() {
  const router = useRouter()
  const params = useParams()
  const patientId = params.id as string

  const [profile, setProfile] = useState<PatientMedicalProfile | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (patientId) {
      setIsLoading(true)
      fetchMedicalProfile(patientId)
        .then((data) => {
          if (data) {
            setProfile(data)
          } else {
            // 新規作成の場合の初期プロファイル
            setProfile({
              id: "", // 保存時に生成
              patientId: patientId,
              managementItems: {},
              managementItemDetails: {},
              specialManagementAdditionStatus: {
                isType1Applicable: false,
                isType2Applicable: false,
                applicableItems: [],
                priorityType: null,
              },
              physicianInstruction: {},
              allergies: [],
              pastMedicalHistory: [],
              createdAt: new Date(),
              updatedAt: new Date(),
            })
          }
        })
        .catch((err) => {
          console.error("Error fetching profile:", err)
          // エラー時も空のプロファイルで初期化
          setProfile({
            id: "",
            patientId: patientId,
            managementItems: {},
            managementItemDetails: {},
            specialManagementAdditionStatus: {
              isType1Applicable: false,
              isType2Applicable: false,
              applicableItems: [],
              priorityType: null,
            },
            physicianInstruction: {},
            allergies: [],
            pastMedicalHistory: [],
            createdAt: new Date(),
            updatedAt: new Date(),
          })
        })
        .finally(() => setIsLoading(false))
    } else {
      // patientIdがない場合はエラーまたはリダイレクトを検討
      console.error("Patient ID is missing from URL params.")
      setIsLoading(false)
    }
  }, [patientId])

  const currentAdditionStatus = useMemo(() => {
    if (!profile?.managementItems) return { isType1Applicable: false, isType2Applicable: false, priorityType: null }
    return calculateSpecialManagementAdditionStatusFromProfile(profile.managementItems)
  }, [profile?.managementItems])

  const handleManagementItemChange = (itemKey: keyof ManagementItems, checked: boolean) => {
    setProfile((prev) => {
      if (!prev) return null
      const newManagementItems = {
        ...(prev.managementItems || {}),
        [itemKey]: checked,
      }
      // チェックが外れたら詳細情報もクリアする（任意）
      const newManagementItemDetails = { ...(prev.managementItemDetails || {}) }
      if (!checked && newManagementItemDetails[itemKey]) {
        delete newManagementItemDetails[itemKey]
      }

      return {
        ...prev,
        managementItems: newManagementItems,
        managementItemDetails: newManagementItemDetails,
      }
    })
  }

  const handleDetailItemChange = (itemKey: keyof ManagementItems, detailKey: string, value: string) => {
    setProfile((prev) => {
      if (!prev) return null
      return {
        ...prev,
        managementItemDetails: {
          ...prev.managementItemDetails,
          [itemKey]: {
            ...(prev.managementItemDetails?.[itemKey] || {}),
            [detailKey]: value,
          },
        },
      }
    })
  }

  const handlePhysicianInstructionChange = (field: keyof PhysicianInstruction, value: string | Date | undefined) => {
    setProfile((prev) =>
      prev ? { ...prev, physicianInstruction: { ...(prev.physicianInstruction || {}), [field]: value } } : null,
    )
  }

  const handleStartDateChange = (date: Date | undefined) => {
    setProfile((prev) => {
      if (!prev) return null
      return {
        ...prev,
        specialManagementAdditionStatus: {
          ...(prev.specialManagementAdditionStatus || {
            isType1Applicable: false,
            isType2Applicable: false,
            applicableItems: [],
            priorityType: null,
          }),
          startDate: date,
        },
      }
    })
  }

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault()
    if (!profile || !patientId) {
      console.error("Profile data or Patient ID is missing.")
      alert("プロファイル情報または患者IDがありません。")
      return
    }
    setIsLoading(true)
    try {
      const saved = await saveMedicalProfile(profile)
      setProfile(saved) // 保存後のデータでステートを更新
      alert("医療プロファイルが保存されました。")
      // router.push(`/patients/${patientId}`); // 必要に応じてリダイレクト
    } catch (error) {
      console.error("Failed to save profile:", error)
      alert("保存に失敗しました。")
    } finally {
      setIsLoading(false)
    }
  }

  if (isLoading) {
    return <div className="container mx-auto p-4">読み込み中...</div>
  }
  if (!profile) {
    return <div className="container mx-auto p-4">患者プロファイル情報を読み込めませんでした。</div>
  }

  const renderAdditionTypeSection = (type: "typeI" | "typeII", title: string) => (
    <div className="mb-6">
      <h4 className="font-semibold text-lg text-orange-600 mb-3">{title}</h4>
      {specialManagementItems[type].items.map((item) => (
        <div key={item.id} className="ml-4 my-3 p-3 border-l-2 border-orange-200">
          <label className="flex items-start cursor-pointer">
            <Checkbox
              id={item.id}
              className="mt-1 mr-3 h-5 w-5"
              checked={!!profile.managementItems?.[item.id as keyof ManagementItems]}
              onCheckedChange={(checked) => handleManagementItemChange(item.id as keyof ManagementItems, !!checked)}
            />
            <div className="flex-1">
              <span className="font-medium">{item.label}</span>
              {item.isNew2024 && (
                <span className="ml-2 text-xs bg-red-500 text-white px-1.5 py-0.5 rounded-sm">2024年新規</span>
              )}
            </div>
          </label>
          {profile.managementItems?.[item.id as keyof ManagementItems] &&
            item.requireDetail &&
            item.requireDetail.length > 0 && (
              <div className="mt-2 ml-8 space-y-2">
                {item.requireDetail.map((detail) => (
                  <div key={detail}>
                    <Label htmlFor={`${item.id}-${detail}`} className="text-sm text-gray-600">
                      {detail}
                    </Label>
                    <Input
                      id={`${item.id}-${detail}`}
                      type="text"
                      placeholder={detail}
                      value={
                        profile.managementItemDetails?.[item.id as keyof ManagementItems]?.[
                          detail.replace(/\s|$$|$$|\/|（|）|ヶ|・/g, "_")
                        ] || ""
                      } // キー名を整形
                      onChange={(e) =>
                        handleDetailItemChange(
                          item.id as keyof ManagementItems,
                          detail.replace(/\s|$$|$$|\/|（|）|ヶ|・/g, "_"),
                          e.target.value,
                        )
                      }
                      className="block w-full md:w-2/3 mt-1 p-2 border rounded text-sm"
                    />
                  </div>
                ))}
              </div>
            )}
        </div>
      ))}
    </div>
  )

  return (
    <div className="container mx-auto p-4 md:p-6">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl">患者医療プロファイル編集</CardTitle>
          <CardDescription>患者ID: {patientId} の医療情報を編集します。</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-10">
            <section>
              <h3 className="text-xl font-semibold mb-4 border-b pb-2">特別管理加算対象確認</h3>
              {renderAdditionTypeSection("typeI", "特別管理加算(Ⅰ) - 500単位/月")}
              {renderAdditionTypeSection("typeII", "特別管理加算(Ⅱ) - 250単位/月")}

              <div className="mt-6 p-4 bg-slate-50 rounded-md border">
                <p className="font-semibold text-md">現在の判定結果:</p>
                {currentAdditionStatus.priorityType === "type1" && (
                  <p className="text-green-700 font-bold">特別管理加算(Ⅰ) 対象</p>
                )}
                {currentAdditionStatus.priorityType === "type2" && (
                  <p className="text-blue-700 font-bold">特別管理加算(Ⅱ) 対象</p>
                )}
                {!currentAdditionStatus.priorityType && <p>加算対象外</p>}
                {currentAdditionStatus.applicableItems.length > 0 && (
                  <p className="text-xs text-gray-600 mt-1">
                    該当項目:{" "}
                    {currentAdditionStatus.applicableItems
                      .map(
                        (id) =>
                          specialManagementItems.typeI.items.find((i) => i.id === id)?.label ||
                          specialManagementItems.typeII.items.find((i) => i.id === id)?.label,
                      )
                      .filter(Boolean)
                      .join(", ")}
                  </p>
                )}
              </div>
            </section>

            <section>
              <h3 className="text-xl font-semibold mb-4 border-b pb-2">加算適用開始日</h3>
              <DatePicker
                date={
                  profile.specialManagementAdditionStatus?.startDate
                    ? new Date(profile.specialManagementAdditionStatus.startDate)
                    : undefined
                }
                onDateChange={handleStartDateChange}
              />
            </section>

            <section>
              <h3 className="text-xl font-semibold mb-4 border-b pb-2">医師指示書情報</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                <div>
                  <Label htmlFor="physicianConfirmedDate">指示書確認日</Label>
                  <DatePicker
                    date={
                      profile.physicianInstruction?.confirmedDate
                        ? new Date(profile.physicianInstruction.confirmedDate)
                        : undefined
                    }
                    onDateChange={(date) => handlePhysicianInstructionChange("confirmedDate", date)}
                  />
                </div>
                <div>
                  <Label htmlFor="physicianExpiryDate">指示書有効期限</Label>
                  <DatePicker
                    date={
                      profile.physicianInstruction?.expiryDate
                        ? new Date(profile.physicianInstruction.expiryDate)
                        : undefined
                    }
                    onDateChange={(date) => handlePhysicianInstructionChange("expiryDate", date)}
                  />
                </div>
                <div className="md:col-span-2">
                  <Label htmlFor="physicianNotes">備考</Label>
                  <Textarea
                    id="physicianNotes"
                    value={profile.physicianInstruction?.notes || ""}
                    onChange={(e) => handlePhysicianInstructionChange("notes", e.target.value)}
                    rows={3}
                  />
                </div>
              </div>
            </section>

            <section>
              <h3 className="text-xl font-semibold mb-4 border-b pb-2">その他医療情報</h3>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="allergies">アレルギー情報 (カンマ区切りで入力)</Label>
                  <Input
                    id="allergies"
                    value={profile.allergies?.join(", ") || ""}
                    onChange={(e) =>
                      setProfile((prev) =>
                        prev
                          ? {
                              ...prev,
                              allergies: e.target.value
                                .split(",")
                                .map((s) => s.trim())
                                .filter(Boolean),
                            }
                          : null,
                      )
                    }
                    placeholder="例: ペニシリン, ソバ"
                  />
                </div>
                <div>
                  <Label htmlFor="pastMedicalHistory">既往歴 (カンマ区切りで入力)</Label>
                  <Input
                    id="pastMedicalHistory"
                    value={profile.pastMedicalHistory?.join(", ") || ""}
                    onChange={(e) =>
                      setProfile((prev) =>
                        prev
                          ? {
                              ...prev,
                              pastMedicalHistory: e.target.value
                                .split(",")
                                .map((s) => s.trim())
                                .filter(Boolean),
                            }
                          : null,
                      )
                    }
                    placeholder="例: 高血圧, 糖尿病"
                  />
                </div>
              </div>
            </section>
            <CardFooter className="pt-6">
              <Button type="submit" disabled={isLoading} size="lg">
                {isLoading ? "保存中..." : "医療プロファイルを保存"}
              </Button>
            </CardFooter>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
