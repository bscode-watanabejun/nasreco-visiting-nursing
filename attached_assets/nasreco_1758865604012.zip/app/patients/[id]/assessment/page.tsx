"use client"

import { useState } from "react"
import { Calendar, Clock, ArrowUpRight, ArrowDownRight, Minus } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { AssessmentChart } from "@/components/patient-assessment/assessment-chart"
import { AIWoundAssessment } from "@/components/ai-wound-assessment"

// モックデータ
const generateMockData = (count: number, baseValue: number, variance: number) => {
  const data = []
  const now = new Date()

  for (let i = 0; i < count; i++) {
    const date = new Date(now)
    date.setDate(date.getDate() - (count - i - 1) * 3) // 3日ごとのデータ
    const value = baseValue + (Math.random() - 0.5) * variance
    data.push({
      date: date.toISOString().split("T")[0],
      value: Math.round(value * 10) / 10,
    })
  }

  return data
}

const mockVitalSigns = {
  temperature: generateMockData(20, 36.8, 1.2),
  pulse: generateMockData(20, 75, 15),
  systolicBP: generateMockData(20, 125, 20),
  diastolicBP: generateMockData(20, 80, 15),
  spo2: generateMockData(20, 97, 4),
  respiratoryRate: generateMockData(20, 16, 4),
}

const mockWoundAssessment = {
  area: generateMockData(10, 5, 2).map((item, index) => ({
    ...item,
    value: Math.max(0, 8 - index * 0.4 + (Math.random() - 0.5) * 0.8),
  })),
  depth: generateMockData(10, 0.8, 0.4).map((item, index) => ({
    ...item,
    value: Math.max(0, 1.2 - index * 0.1 + (Math.random() - 0.5) * 0.2),
  })),
}

const mockPainScale = generateMockData(15, 4, 3).map((item, index) => ({
  ...item,
  value: Math.max(0, Math.min(10, 6 - index * 0.3 + (Math.random() - 0.5) * 2)),
}))

const mockADLScores = {
  bathing: generateMockData(8, 2, 1).map((item, index) => ({
    ...item,
    value: Math.min(4, 1 + Math.floor(index / 2) + (Math.random() > 0.7 ? 0 : 1)),
  })),
  dressing: generateMockData(8, 2, 1).map((item, index) => ({
    ...item,
    value: Math.min(4, 1 + Math.floor(index / 3) + (Math.random() > 0.7 ? 0 : 1)),
  })),
  toileting: generateMockData(8, 2, 1).map((item, index) => ({
    ...item,
    value: Math.min(4, 2 + Math.floor(index / 4) + (Math.random() > 0.8 ? 0 : 1)),
  })),
  mobility: generateMockData(8, 2, 1).map((item, index) => ({
    ...item,
    value: Math.min(4, 1 + Math.floor(index / 2) + (Math.random() > 0.7 ? 0 : 1)),
  })),
}

const mockNutritionStatus = {
  weight: generateMockData(12, 58, 2).map((item, index) => ({
    ...item,
    value: 56 + index * 0.2 + (Math.random() - 0.5) * 0.4,
  })),
  albumin: generateMockData(6, 3.5, 0.5),
  totalProtein: generateMockData(6, 6.8, 0.6),
}

export default function PatientAssessmentPage({ params }: { params: { id: string } }) {
  const [activeTab, setActiveTab] = useState("vitals")

  // 最新の値と前回からの変化を計算
  const getLatestValueWithChange = (data: { date: string; value: number }[]) => {
    if (data.length < 2) return { value: data[0]?.value || 0, change: 0 }
    const latest = data[data.length - 1].value
    const previous = data[data.length - 2].value
    return {
      value: latest,
      change: latest - previous,
    }
  }

  const latestTemperature = getLatestValueWithChange(mockVitalSigns.temperature)
  const latestPulse = getLatestValueWithChange(mockVitalSigns.pulse)
  const latestSystolicBP = getLatestValueWithChange(mockVitalSigns.systolicBP)
  const latestSpo2 = getLatestValueWithChange(mockVitalSigns.spo2)
  const latestPain = getLatestValueWithChange(mockPainScale)

  const getChangeIndicator = (change: number, isInverse = false) => {
    if (Math.abs(change) < 0.01) return <Minus className="h-4 w-4 text-gray-500" />
    if ((change > 0 && !isInverse) || (change < 0 && isInverse)) {
      return <ArrowUpRight className="h-4 w-4 text-red-500" />
    }
    return <ArrowDownRight className="h-4 w-4 text-green-500" />
  }

  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">患者状態評価</h1>
          <p className="text-muted-foreground">患者ID: {params.id} - 佐藤 一郎 (68歳・男性)</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center text-muted-foreground">
            <Calendar className="mr-2 h-4 w-4" />
            <span>{new Date().toLocaleDateString()}</span>
          </div>
          <div className="flex items-center text-muted-foreground">
            <Clock className="mr-2 h-4 w-4" />
            <span>{new Date().toLocaleTimeString()}</span>
          </div>
          <Button>レポート作成</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">体温</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-end">
              <div className="text-2xl font-bold">{latestTemperature.value.toFixed(1)}℃</div>
              <div className="flex items-center text-sm">
                {getChangeIndicator(latestTemperature.change)}
                <span className="ml-1">{Math.abs(latestTemperature.change).toFixed(1)}℃</span>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">脈拍</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-end">
              <div className="text-2xl font-bold">{Math.round(latestPulse.value)}回/分</div>
              <div className="flex items-center text-sm">
                {getChangeIndicator(latestPulse.change)}
                <span className="ml-1">{Math.abs(Math.round(latestPulse.change))}回/分</span>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">血圧</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-end">
              <div className="text-2xl font-bold">
                {Math.round(latestSystolicBP.value)}/
                {Math.round(getLatestValueWithChange(mockVitalSigns.diastolicBP).value)}
              </div>
              <div className="flex items-center text-sm">
                {getChangeIndicator(latestSystolicBP.change)}
                <span className="ml-1">{Math.abs(Math.round(latestSystolicBP.change))}</span>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">SpO2</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-end">
              <div className="text-2xl font-bold">{Math.round(latestSpo2.value)}%</div>
              <div className="flex items-center text-sm">
                {getChangeIndicator(latestSpo2.change, true)}
                <span className="ml-1">{Math.abs(Math.round(latestSpo2.change))}%</span>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">痛みスケール</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-end">
              <div className="text-2xl font-bold">{Math.round(latestPain.value)}/10</div>
              <div className="flex items-center text-sm">
                {getChangeIndicator(latestPain.change, true)}
                <span className="ml-1">{Math.abs(Math.round(latestPain.change))}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="vitals">バイタルサイン</TabsTrigger>
          <TabsTrigger value="wound">褥瘡・創傷</TabsTrigger>
          <TabsTrigger value="adl">ADL評価</TabsTrigger>
          <TabsTrigger value="nutrition">栄養状態</TabsTrigger>
        </TabsList>
        <TabsContent value="vitals" className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <AssessmentChart
              title="体温"
              data={mockVitalSigns.temperature}
              unit="℃"
              normalRange={{ min: 36, max: 37.2 }}
              color="rgb(239, 68, 68)"
            />
            <AssessmentChart
              title="脈拍"
              data={mockVitalSigns.pulse}
              unit="回/分"
              normalRange={{ min: 60, max: 100 }}
              color="rgb(59, 130, 246)"
            />
            <AssessmentChart
              title="血圧"
              data={mockVitalSigns.systolicBP.map((item, index) => ({
                date: item.date,
                value: item.value,
              }))}
              unit="mmHg"
              normalRange={{ min: 90, max: 140 }}
              color="rgb(16, 185, 129)"
              description="収縮期血圧"
            />
            <AssessmentChart
              title="SpO2"
              data={mockVitalSigns.spo2}
              unit="%"
              normalRange={{ min: 95, max: 100 }}
              color="rgb(139, 92, 246)"
            />
          </div>
        </TabsContent>
        <TabsContent value="wound" className="space-y-4 pt-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="space-y-4">
              <AssessmentChart
                title="褥瘡面積"
                data={mockWoundAssessment.area}
                unit="cm²"
                color="rgb(244, 63, 94)"
                description="仙骨部褥瘡"
              />
              <AssessmentChart title="褥瘡深さ" data={mockWoundAssessment.depth} unit="cm" color="rgb(249, 115, 22)" />
            </div>
            <AIWoundAssessment
              previousResults={[
                {
                  stage: "D3",
                  area: 4.2,
                  depth: 0.5,
                  exudate: "moderate",
                  tissue: "granulation",
                  infection: false,
                  healing: "improving",
                  confidence: 0.87,
                  recommendations: [],
                },
                {
                  stage: "D3",
                  area: 5.8,
                  depth: 0.7,
                  exudate: "moderate",
                  tissue: "granulation",
                  infection: false,
                  healing: "stable",
                  confidence: 0.85,
                  recommendations: [],
                },
                {
                  stage: "D4",
                  area: 6.5,
                  depth: 0.9,
                  exudate: "heavy",
                  tissue: "necrotic",
                  infection: true,
                  healing: "worsening",
                  confidence: 0.9,
                  recommendations: [],
                },
              ]}
              previousImages={[
                "/wound-healing-stages.png",
                "/stable-wound.png",
                "/placeholder.svg?key=isd9c",
              ]}
            />
          </div>
        </TabsContent>
        <TabsContent value="adl" className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <AssessmentChart
              title="入浴"
              description="0=全介助, 4=自立"
              data={mockADLScores.bathing}
              color="rgb(14, 165, 233)"
              type="bar"
            />
            <AssessmentChart
              title="更衣"
              description="0=全介助, 4=自立"
              data={mockADLScores.dressing}
              color="rgb(168, 85, 247)"
              type="bar"
            />
            <AssessmentChart
              title="トイレ動作"
              description="0=全介助, 4=自立"
              data={mockADLScores.toileting}
              color="rgb(236, 72, 153)"
              type="bar"
            />
            <AssessmentChart
              title="移動"
              description="0=全介助, 4=自立"
              data={mockADLScores.mobility}
              color="rgb(245, 158, 11)"
              type="bar"
            />
          </div>
          <Card>
            <CardHeader>
              <CardTitle>ADL総合評価</CardTitle>
              <CardDescription>日常生活動作の自立度評価</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">総合スコア</span>
                  <div className="flex items-center">
                    <span className="text-2xl font-bold mr-2">12</span>
                    <span className="text-sm text-muted-foreground">/16</span>
                  </div>
                </div>
                <div className="w-full bg-muted rounded-full h-2.5">
                  <div className="bg-primary h-2.5 rounded-full" style={{ width: "75%" }}></div>
                </div>
                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div>
                    <h4 className="text-sm font-medium mb-2">強み</h4>
                    <ul className="list-disc list-inside text-sm space-y-1">
                      <li>トイレ動作は比較的自立している</li>
                      <li>移動能力が改善傾向にある</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium mb-2">課題</h4>
                    <ul className="list-disc list-inside text-sm space-y-1">
                      <li>入浴時の安全確保が必要</li>
                      <li>更衣動作の練習が必要</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="nutrition" className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <AssessmentChart title="体重" data={mockNutritionStatus.weight} unit="kg" color="rgb(34, 197, 94)" />
            <AssessmentChart
              title="アルブミン"
              data={mockNutritionStatus.albumin}
              unit="g/dL"
              normalRange={{ min: 3.5, max: 5.0 }}
              color="rgb(249, 115, 22)"
            />
            <AssessmentChart
              title="総タンパク"
              data={mockNutritionStatus.totalProtein}
              unit="g/dL"
              normalRange={{ min: 6.5, max: 8.0 }}
              color="rgb(168, 85, 247)"
            />
          </div>
          <Card>
            <CardHeader>
              <CardTitle>栄養状態評価</CardTitle>
              <CardDescription>栄養状態の総合評価と推奨事項</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">MNA-SF スコア</p>
                    <div className="flex items-end">
                      <span className="text-2xl font-bold">10</span>
                      <span className="text-sm text-muted-foreground ml-1">/14</span>
                    </div>
                    <p className="text-sm">低栄養リスクあり</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">BMI</p>
                    <div className="text-2xl font-bold">21.3</div>
                    <p className="text-sm">標準</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">体重変化</p>
                    <div className="flex items-center">
                      <ArrowUpRight className="h-4 w-4 text-green-500 mr-1" />
                      <span className="text-2xl font-bold">1.2</span>
                      <span className="text-sm ml-1">kg/3ヶ月</span>
                    </div>
                    <p className="text-sm">改善傾向</p>
                  </div>
                </div>
                <div className="pt-2">
                  <h4 className="text-sm font-medium mb-2">栄養介入推奨事項</h4>
                  <ul className="list-disc list-inside text-sm space-y-1">
                    <li>タンパク質摂取量の増加（目標: 1.2g/kg/日）</li>
                    <li>間食としての栄養補助食品の検討</li>
                    <li>水分摂取量の確保（1500ml/日以上）</li>
                    <li>食事摂取状況の継続的なモニタリング</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
