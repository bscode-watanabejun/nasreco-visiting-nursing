"use client"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import { FileText, Calendar, User, AlertTriangle, CheckCircle2, Clock } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface MedicalInstructionProps {
  params: {
    id: string
  }
}

// 医師指示書のダミーデータ
const getMedicalInstructions = (patientId: string) => {
  const instructions = {
    "patient-1": {
      id: "instruction-001",
      patientName: "田中 正男",
      doctorName: "山田 太郎",
      hospitalName: "総合病院 健康会",
      issueDate: new Date("2024-05-15"),
      validUntil: new Date("2024-07-15"),
      diagnosis: "慢性心不全、糖尿病",
      instructions: [
        {
          category: "バイタルサイン測定",
          items: ["血圧測定：毎回実施", "体重測定：週2回以上", "浮腫の観察：毎回実施", "呼吸状態の観察：毎回実施"],
        },
        {
          category: "薬剤管理",
          items: ["利尿剤の服薬確認：毎回", "血糖値測定：週3回", "インスリン注射指導：必要時"],
        },
        {
          category: "生活指導",
          items: ["塩分制限指導（1日6g以下）", "水分制限指導（1日1500ml以下）", "適度な運動指導"],
        },
        {
          category: "緊急時対応",
          items: ["呼吸困難時は酸素投与", "血圧180/100以上で医師連絡", "浮腫増悪時は利尿剤調整"],
        },
      ],
      specialNotes: [
        "心不全の増悪兆候に注意すること",
        "体重増加（2kg/週以上）時は医師に連絡",
        "患者の自己管理能力向上を図ること",
      ],
    },
    "patient-2": {
      id: "instruction-002",
      patientName: "佐藤 花子",
      doctorName: "鈴木 次郎",
      hospitalName: "市立病院",
      issueDate: new Date("2024-05-20"),
      validUntil: new Date("2024-07-20"),
      diagnosis: "在宅酸素療法、COPD",
      instructions: [
        {
          category: "酸素療法管理",
          items: [
            "酸素流量：安静時2L/分、労作時3L/分",
            "酸素濃縮器の動作確認：毎回",
            "SpO2測定：毎回実施",
            "鼻カニューレの清潔保持",
          ],
        },
        {
          category: "呼吸リハビリテーション",
          items: ["腹式呼吸指導：毎回10分", "口すぼめ呼吸指導", "簡単な運動療法指導"],
        },
        {
          category: "感染予防",
          items: ["手洗い・うがいの徹底指導", "マスク着用指導", "予防接種の勧奨"],
        },
      ],
      specialNotes: ["SpO2が90%以下の場合は医師に連絡", "呼吸困難増悪時は緊急対応", "機器トラブル時の対応方法を指導"],
    },
  }

  return instructions[patientId as keyof typeof instructions] || instructions["patient-1"]
}

export default function MedicalInstructionsPage({ params }: MedicalInstructionProps) {
  const instruction = getMedicalInstructions(params.id)
  const isExpiringSoon = instruction.validUntil < new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7日以内
  const isExpired = instruction.validUntil < new Date()

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <FileText className="h-6 w-6 text-blue-600" />
          <h1 className="text-2xl font-bold">医師指示書</h1>
        </div>
        <p className="text-muted-foreground">患者の医療管理に関する医師からの指示内容</p>
      </div>

      {/* 有効期限の警告 */}
      {isExpired && (
        <Alert className="mb-6 border-red-200 bg-red-50">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            <strong>注意：</strong>この医師指示書は有効期限が切れています。新しい指示書の取得が必要です。
          </AlertDescription>
        </Alert>
      )}

      {isExpiringSoon && !isExpired && (
        <Alert className="mb-6 border-yellow-200 bg-yellow-50">
          <AlertTriangle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800">
            <strong>注意：</strong>この医師指示書の有効期限が近づいています。更新の準備をしてください。
          </AlertDescription>
        </Alert>
      )}

      {/* 基本情報 */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            基本情報
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-muted-foreground">患者名</label>
                <p className="font-medium">{instruction.patientName}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">主治医</label>
                <p className="font-medium">{instruction.doctorName}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">医療機関</label>
                <p className="font-medium">{instruction.hospitalName}</p>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-muted-foreground">発行日</label>
                <p className="font-medium flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  {format(instruction.issueDate, "yyyy年M月d日", { locale: ja })}
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">有効期限</label>
                <p className="font-medium flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  {format(instruction.validUntil, "yyyy年M月d日", { locale: ja })}
                  {isExpired && (
                    <Badge variant="destructive" className="ml-2">
                      期限切れ
                    </Badge>
                  )}
                  {isExpiringSoon && !isExpired && (
                    <Badge variant="secondary" className="ml-2 bg-yellow-400 text-yellow-900">
                      期限間近
                    </Badge>
                  )}
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">診断名</label>
                <p className="font-medium">{instruction.diagnosis}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 指示内容 */}
      <div className="space-y-4 mb-6">
        <h2 className="text-xl font-semibold">指示内容</h2>
        {instruction.instructions.map((category, index) => (
          <Card key={index}>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">{category.category}</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {category.items.map((item, itemIndex) => (
                  <li key={itemIndex} className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">{item}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 特記事項 */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-orange-600" />
            特記事項・注意点
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {instruction.specialNotes.map((note, index) => (
              <li key={index} className="flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 text-orange-600 mt-0.5 flex-shrink-0" />
                <span className="text-sm font-medium">{note}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* アクション */}
      <div className="flex gap-3">
        <Button onClick={() => window.print()} variant="outline">
          印刷
        </Button>
        <Button onClick={() => window.close()} className="bg-orange-500 hover:bg-orange-600">
          閉じる
        </Button>
      </div>
    </div>
  )
}
