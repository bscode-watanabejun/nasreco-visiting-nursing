"use client"

import { useState, useEffect } from "react"
import { PatientDocumentManager } from "@/components/documents/patient-document-manager"
import { DocumentType, DocumentStatus, OCRStatus, type PatientDocument } from "@/lib/db/document-schema"

interface PageProps {
  params: {
    id: string
  }
}

// モックデータ
const mockDocuments: PatientDocument[] = [
  {
    id: "doc-1",
    patientId: "patient-1",
    fileName: "care-plan-2024.pdf",
    originalFileName: "ケアプラン_2024年1月.pdf",
    fileSize: 1024000,
    mimeType: "application/pdf",
    documentType: DocumentType.CARE_PLAN,
    status: DocumentStatus.ACTIVE,
    uploadedBy: "nurse-1",
    uploadedAt: new Date("2024-01-15"),
    updatedAt: new Date("2024-01-15"),
    description: "2024年1月のケアプラン",
    tags: ["2024年", "定期更新"],
    ocrStatus: OCRStatus.NOT_PROCESSED,
  },
  {
    id: "doc-2",
    patientId: "patient-1",
    fileName: "medical-instruction.jpg",
    originalFileName: "医療指示書_撮影.jpg",
    fileSize: 2048000,
    mimeType: "image/jpeg",
    documentType: DocumentType.MEDICAL_INSTRUCTION,
    status: DocumentStatus.ACTIVE,
    uploadedBy: "nurse-2",
    uploadedAt: new Date("2024-01-20"),
    updatedAt: new Date("2024-01-20"),
    description: "医師からの最新指示書",
    tags: ["緊急", "指示変更"],
    ocrStatus: OCRStatus.COMPLETED,
    ocrText:
      "患者: 佐藤一郎様\n\n医療指示書\n\n1. 血糖値測定: 毎食前・後\n2. インスリン投与: 朝8単位、夕6単位\n3. 血圧測定: 1日2回\n4. 体重測定: 週2回\n\n注意事項:\n- 低血糖症状に注意\n- 異常時は速やかに連絡\n\n医師: 田中医師\n日付: 2024年1月20日",
    ocrProcessedAt: new Date("2024-01-20"),
    ocrConfidence: 0.95,
  },
]

// OCRテキストのサンプル生成
const generateMockOCRText = (fileName: string, documentType: DocumentType): string => {
  const samples = {
    [DocumentType.CARE_PLAN]: `ケアプラン

利用者名: 佐藤一郎
作成日: 2024年1月15日

【基本情報】
年齢: 68歳
要介護度: 要介護2
主疾患: 糖尿病、高血圧

【ケア内容】
1. 服薬管理
   - 血糖降下薬の服薬確認
   - 血圧薬の服薬確認

2. バイタルサイン測定
   - 血圧測定（1日2回）
   - 血糖値測定（毎食前後）

3. 生活支援
   - 入浴介助（週2回）
   - 清拭（毎日）

【注意事項】
- 低血糖症状の観察
- 血圧の変動に注意`,

    [DocumentType.MEDICAL_INSTRUCTION]: `医療指示書

患者名: 佐藤一郎
指示日: 2024年1月20日

【投薬指示】
1. メトホルミン 500mg 1日2回 朝夕食後
2. アムロジピン 5mg 1日1回 朝食後
3. インスリン 朝8単位 夕6単位

【処置指示】
1. 血糖値測定 毎食前後
2. 血圧測定 1日2回
3. 体重測定 週2回

【観察項目】
- 低血糖症状の有無
- 血圧の変動
- 浮腫の有無

医師: 田中太郎`,

    [DocumentType.PRESCRIPTION]: `処方箋

患者氏名: 佐藤一郎
生年月日: 昭和30年3月15日

【処方内容】
1. メトホルミン錠500mg
   用法: 1回1錠 1日2回 朝夕食後
   日数: 30日分

2. アムロジピン錠5mg  
   用法: 1回1錠 1日1回 朝食後
   日数: 30日分

処方医: 田中太郎
処方日: 2024年1月20日`,

    [DocumentType.REPORT]: `訪問看護報告書

利用者名: 佐藤一郎
訪問日: 2024年1月20日
担当者: 山田花子

【本日の状況】
- 血圧: 130/80mmHg
- 血糖値: 空腹時 120mg/dl
- 体温: 36.5℃
- 体重: 65kg

【実施内容】
- 服薬確認・指導
- バイタルサイン測定
- 清拭実施
- 生活指導

【特記事項】
血糖値が若干高めのため、
食事内容について指導を実施。
次回訪問時に再確認予定。`,

    [DocumentType.PHOTO]: `写真撮影日: 2024年1月20日
撮影者: 山田花子

【撮影内容】
創傷部位の状態確認

【所見】
- 創傷サイズ: 約2cm×1cm
- 発赤: 軽度
- 浸出液: 少量
- 治癒傾向: 良好`,

    [DocumentType.OTHER]: `書類名: ${fileName}

内容の詳細はOCR処理により
自動で抽出されました。

この文書には重要な医療情報が
含まれている可能性があります。
内容を確認してください。`,
  }

  return samples[documentType] || samples[DocumentType.OTHER]
}

export default function PatientDocumentsPage({ params }: PageProps) {
  const [documents, setDocuments] = useState<PatientDocument[]>([])
  const [loading, setLoading] = useState(true)

  // 患者情報（モック）
  const patientName = "佐藤 一郎"

  useEffect(() => {
    // モックデータの読み込み
    setTimeout(() => {
      const patientDocs = mockDocuments.filter((doc) => doc.patientId === params.id)
      setDocuments(patientDocs)
      setLoading(false)
    }, 500)
  }, [params.id])

  const handleUploadDocument = async (uploadData: {
    file: File
    documentType: DocumentType
    description: string
    tags: string[]
    enableOCR: boolean
  }) => {
    const newDocument: PatientDocument = {
      id: `doc-${Date.now()}`,
      patientId: params.id,
      fileName: `${Date.now()}-${uploadData.file.name}`,
      originalFileName: uploadData.file.name,
      fileSize: uploadData.file.size,
      mimeType: uploadData.file.type,
      documentType: uploadData.documentType,
      status: DocumentStatus.ACTIVE,
      uploadedBy: "current-user",
      uploadedAt: new Date(),
      updatedAt: new Date(),
      description: uploadData.description,
      tags: uploadData.tags,
      ocrStatus: uploadData.enableOCR ? OCRStatus.PROCESSING : OCRStatus.NOT_PROCESSED,
    }

    // ドキュメントを即座に追加（処理中状態で）
    setDocuments((prev) => [newDocument, ...prev])

    // OCRが有効な場合、数秒後に完了状態に更新
    if (uploadData.enableOCR) {
      setTimeout(
        () => {
          const ocrText = generateMockOCRText(uploadData.file.name, uploadData.documentType)

          setDocuments((prev) =>
            prev.map((doc) =>
              doc.id === newDocument.id
                ? {
                    ...doc,
                    ocrStatus: OCRStatus.COMPLETED,
                    ocrText,
                    ocrProcessedAt: new Date(),
                    ocrConfidence: 0.85 + Math.random() * 0.1, // 0.85-0.95の範囲
                  }
                : doc,
            ),
          )
        },
        2000 + Math.random() * 3000,
      ) // 2-5秒後に完了
    }
  }

  const handleDeleteDocument = async (documentId: string) => {
    setDocuments((prev) => prev.filter((doc) => doc.id !== documentId))
  }

  const handleUpdateDocumentText = async (documentId: string, newText: string) => {
    setDocuments((prev) =>
      prev.map((doc) => (doc.id === documentId ? { ...doc, ocrText: newText, updatedAt: new Date() } : doc)),
    )
  }

  if (loading) {
    return (
      <div className="container mx-auto py-6 px-4">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6 px-4">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">書類管理</h1>
        <p className="text-gray-600 mt-2">{patientName}さんの書類一覧</p>
      </div>

      <PatientDocumentManager
        documents={documents}
        patientId={params.id}
        patientName={patientName}
        onUpload={handleUploadDocument}
        onDelete={handleDeleteDocument}
        onUpdateText={handleUpdateDocumentText}
      />
    </div>
  )
}
