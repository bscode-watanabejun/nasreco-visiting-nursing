"use client"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import { Heart, Calendar, User, Target, Activity, AlertCircle, CheckCircle2 } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"

interface CarePlanProps {
  params: {
    id: string
  }
}

// ケアプランのダミーデータ
const getCarePlan = (patientId: string) => {
  const carePlans = {
    "patient-1": {
      id: "careplan-001",
      patientName: "田中 正男",
      careManagerName: "高橋 美咲",
      createdDate: new Date("2024-05-01"),
      lastUpdated: new Date("2024-05-25"),
      nextReview: new Date("2024-08-01"),
      goals: [
        {
          id: "goal-1",
          title: "心不全の症状管理",
          description: "浮腫や呼吸困難の症状をコントロールし、日常生活の質を向上させる",
          targetDate: new Date("2024-08-01"),
          progress: 75,
          status: "進行中",
        },
        {
          id: "goal-2",
          title: "服薬管理の自立",
          description: "薬剤の正確な服用と副作用の理解を深める",
          targetDate: new Date("2024-07-01"),
          progress: 90,
          status: "ほぼ達成",
        },
        {
          id: "goal-3",
          title: "栄養管理の改善",
          description: "塩分・水分制限を理解し、適切な食事管理を行う",
          targetDate: new Date("2024-09-01"),
          progress: 60,
          status: "進行中",
        },
      ],
      services: [
        {
          category: "訪問看護",
          frequency: "週2回",
          duration: "60分/回",
          provider: "訪問看護ステーション ひまわり",
          objectives: [
            "バイタルサイン測定と状態観察",
            "服薬指導と管理",
            "生活指導（食事・運動）",
            "家族への指導・相談",
          ],
        },
        {
          category: "訪問介護",
          frequency: "週3回",
          duration: "45分/回",
          provider: "ヘルパーステーション 愛",
          objectives: ["身体介護（入浴介助）", "生活援助（掃除・買い物）", "服薬確認", "安全確認"],
        },
        {
          category: "通所介護",
          frequency: "週1回",
          duration: "6時間/回",
          provider: "デイサービス 元気",
          objectives: ["社会参加の促進", "軽度な運動療法", "栄養管理（昼食提供）", "他者との交流"],
        },
      ],
      riskAssessment: [
        {
          risk: "心不全の急性増悪",
          level: "高",
          preventionMeasures: ["定期的なバイタルサイン測定", "体重の日々記録", "症状変化時の早期受診"],
        },
        {
          risk: "転倒・骨折",
          level: "中",
          preventionMeasures: ["住環境の整備", "歩行補助具の使用", "筋力維持のための運動"],
        },
        {
          risk: "社会的孤立",
          level: "低",
          preventionMeasures: ["定期的な社会参加", "家族・友人との交流促進", "地域活動への参加"],
        },
      ],
    },
    "patient-2": {
      id: "careplan-002",
      patientName: "佐藤 花子",
      careManagerName: "田中 健一",
      createdDate: new Date("2024-04-15"),
      lastUpdated: new Date("2024-05-20"),
      nextReview: new Date("2024-07-15"),
      goals: [
        {
          id: "goal-1",
          title: "呼吸機能の維持・改善",
          description: "在宅酸素療法を適切に管理し、呼吸困難の軽減を図る",
          targetDate: new Date("2024-07-15"),
          progress: 80,
          status: "進行中",
        },
        {
          id: "goal-2",
          title: "ADLの維持",
          description: "日常生活動作を可能な限り自立して行う",
          targetDate: new Date("2024-08-15"),
          progress: 70,
          status: "進行中",
        },
      ],
      services: [
        {
          category: "訪問看護",
          frequency: "週3回",
          duration: "60分/回",
          provider: "訪問看護ステーション ひまわり",
          objectives: ["酸素療法の管理・指導", "呼吸リハビリテーション", "機器の動作確認", "感染予防指導"],
        },
      ],
      riskAssessment: [
        {
          risk: "呼吸不全の急性増悪",
          level: "高",
          preventionMeasures: ["酸素濃縮器の適切な管理", "感染予防の徹底", "定期的なSpO2測定"],
        },
      ],
    },
  }

  return carePlans[patientId as keyof typeof carePlans] || carePlans["patient-1"]
}

const getRiskLevelColor = (level: string) => {
  switch (level) {
    case "高":
      return "destructive"
    case "中":
      return "secondary"
    case "低":
      return "outline"
    default:
      return "outline"
  }
}

const getStatusColor = (status: string) => {
  switch (status) {
    case "達成":
      return "bg-green-100 text-green-800"
    case "ほぼ達成":
      return "bg-blue-100 text-blue-800"
    case "進行中":
      return "bg-yellow-100 text-yellow-800"
    case "要見直し":
      return "bg-red-100 text-red-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

export default function CarePlanPage({ params }: CarePlanProps) {
  const carePlan = getCarePlan(params.id)

  return (
    <div className="container mx-auto p-6 max-w-5xl">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <Heart className="h-6 w-6 text-green-600" />
          <h1 className="text-2xl font-bold">ケアプラン</h1>
        </div>
        <p className="text-muted-foreground">利用者の自立支援と生活の質向上を目指した総合的なケア計画</p>
      </div>

      {/* 基本情報 */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            基本情報
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-muted-foreground">利用者名</label>
                <p className="font-medium">{carePlan.patientName}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">ケアマネジャー</label>
                <p className="font-medium">{carePlan.careManagerName}</p>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-muted-foreground">作成日</label>
                <p className="font-medium flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  {format(carePlan.createdDate, "yyyy年M月d日", { locale: ja })}
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">最終更新</label>
                <p className="font-medium">{format(carePlan.lastUpdated, "yyyy年M月d日", { locale: ja })}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">次回見直し予定</label>
                <p className="font-medium">{format(carePlan.nextReview, "yyyy年M月d日", { locale: ja })}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ケア目標 */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            ケア目標
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {carePlan.goals.map((goal) => (
              <div key={goal.id} className="border rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="font-medium mb-1">{goal.title}</h3>
                    <p className="text-sm text-muted-foreground mb-2">{goal.description}</p>
                    <p className="text-xs text-muted-foreground">
                      目標達成日: {format(goal.targetDate, "yyyy年M月d日", { locale: ja })}
                    </p>
                  </div>
                  <Badge className={getStatusColor(goal.status)}>{goal.status}</Badge>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>進捗状況</span>
                    <span>{goal.progress}%</span>
                  </div>
                  <Progress value={goal.progress} className="h-2" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* サービス内容 */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            サービス内容
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {carePlan.services.map((service, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="grid grid-cols-2 gap-4 mb-3">
                  <div>
                    <h3 className="font-medium mb-1">{service.category}</h3>
                    <p className="text-sm text-muted-foreground">{service.provider}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{service.frequency}</p>
                    <p className="text-xs text-muted-foreground">{service.duration}</p>
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-medium mb-2">サービス目標・内容</h4>
                  <ul className="space-y-1">
                    {service.objectives.map((objective, objIndex) => (
                      <li key={objIndex} className="flex items-start gap-2 text-sm">
                        <CheckCircle2 className="h-3 w-3 text-green-600 mt-1 flex-shrink-0" />
                        <span>{objective}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* リスクアセスメント */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5" />
            リスクアセスメント
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {carePlan.riskAssessment.map((risk, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-medium">{risk.risk}</h3>
                  <Badge variant={getRiskLevelColor(risk.level) as any}>リスク: {risk.level}</Badge>
                </div>
                <div>
                  <h4 className="text-sm font-medium mb-2">予防・対策</h4>
                  <ul className="space-y-1">
                    {risk.preventionMeasures.map((measure, measureIndex) => (
                      <li key={measureIndex} className="flex items-start gap-2 text-sm">
                        <CheckCircle2 className="h-3 w-3 text-blue-600 mt-1 flex-shrink-0" />
                        <span>{measure}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* アクション */}
      <div className="flex gap-3">
        <Button onClick={() => window.print()} variant="outline">
          印刷
        </Button>
        <Button onClick={() => window.close()} className="bg-orange-500 hover:bg-orange-600">
          閉じる
        </Button>
      </div>
    </div>
  )
}
