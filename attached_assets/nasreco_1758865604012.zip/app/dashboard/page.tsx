"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Plus,
  Clock,
  Users,
  ClipboardList,
  AlertCircle,
  ArrowRight,
  Calendar,
  Bell,
  Info,
  FileText,
  ShieldAlert,
} from "lucide-react"
import Link from "next/link"
import { format, isSameDay } from "date-fns"
import { ja } from "date-fns/locale"

import { VisitStatus, VisitType } from "@/lib/db/schedule-schema"
import type { VisitSchedule } from "@/lib/db/schedule-schema"
import { getVisitStatusName, getVisitStatusColor } from "@/lib/utils/schedule-utils"

import { ScheduleDetailDialog } from "@/components/schedule/schedule-detail-dialog"
import { VisitRecordDialog } from "@/components/schedule/visit-record-dialog"

const mockPatients = [
  { id: "patient-1", name: "佐藤 一郎", age: 68, condition: "糖尿病管理" },
  { id: "patient-2", name: "田中 正男", age: 75, condition: "血圧管理" },
  { id: "patient-3", name: "鈴木 良子", age: 82, condition: "リハビリ" },
]
const mockStaff = [
  { id: "staff-1", name: "山田 花子", role: "看護師" },
  { id: "staff-2", name: "佐藤 次郎", role: "看護師" },
]

const getPatientMedicalProfile = (patientId: string) => {
  const mockProfiles: Record<string, any> = {
    "patient-1": {
      specialManagementAdditionStatus: { priorityType: "type1" as const },
    },
    "patient-2": {
      specialManagementAdditionStatus: { priorityType: "type2" as const },
    },
    "patient-3": {
      specialManagementAdditionStatus: { priorityType: "type2" as const },
    },
  }
  return mockProfiles[patientId]
}

const getSpecialManagementBadge = (patientId: string) => {
  const profile = getPatientMedicalProfile(patientId)
  if (!profile?.specialManagementAdditionStatus) return null

  const status = profile.specialManagementAdditionStatus
  if (status.priorityType === "type1") {
    return (
      <Badge variant="destructive" className="h-6 px-2">
        <ShieldAlert className="h-3 w-3 mr-1" />
        特管Ⅰ
      </Badge>
    )
  }
  if (status.priorityType === "type2") {
    return (
      <Badge variant="secondary" className="h-6 px-2 bg-yellow-400 text-yellow-900">
        <ShieldAlert className="h-3 w-3 mr-1" />
        特管Ⅱ
      </Badge>
    )
  }
  return null
}

export default function DashboardPage() {
  const today = new Date()

  const initialSchedules: VisitSchedule[] = [
    {
      id: "dash-schedule-1",
      patientId: "patient-1",
      staffId: "staff-1",
      visitDate: today,
      startTime: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 9, 0),
      endTime: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 10, 0),
      visitType: VisitType.REGULAR,
      status: VisitStatus.COMPLETED,
      note: "定期訪問 - バイタルチェックと服薬確認",
      createdAt: new Date(),
      updatedAt: new Date(),
      createdBy: "dashboard-user",
    },
    {
      id: "dash-schedule-2",
      patientId: "patient-2",
      staffId: "staff-1",
      visitDate: today,
      startTime: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 10, 30),
      endTime: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 11, 15),
      visitType: VisitType.ASSESSMENT,
      status: VisitStatus.IN_PROGRESS,
      note: "アセスメント訪問 - 状態評価と計画見直し",
      createdAt: new Date(),
      updatedAt: new Date(),
      createdBy: "dashboard-user",
    },
    {
      id: "dash-schedule-3",
      patientId: "patient-3",
      staffId: "staff-2",
      visitDate: today,
      startTime: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 13, 0),
      endTime: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 13, 45),
      visitType: VisitType.REGULAR,
      status: VisitStatus.SCHEDULED,
      note: "定期訪問 - 創傷処置",
      createdAt: new Date(),
      updatedAt: new Date(),
      createdBy: "dashboard-user",
    },
  ]

  const [schedules, setSchedules] = useState<VisitSchedule[]>(initialSchedules)
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false)
  const [selectedSchedule, setSelectedSchedule] = useState<VisitSchedule | null>(null)
  const [isRecordDialogOpen, setIsRecordDialogOpen] = useState(false)
  const [recordingSchedule, setRecordingSchedule] = useState<VisitSchedule | null>(null)

  const getPatientInfo = (patientId: string) => mockPatients.find((p) => p.id === patientId)
  const getStaffName = (staffId: string) => mockStaff.find((s) => s.id === staffId)?.name || "不明"

  const handleDetailClick = (schedule: VisitSchedule) => {
    setSelectedSchedule(schedule)
    setIsDetailDialogOpen(true)
  }

  const handleRecordClick = (schedule: VisitSchedule) => {
    setRecordingSchedule(schedule)
    setIsRecordDialogOpen(true)
  }

  const handleSaveRecord = (recordData: any) => {
    setSchedules((prev) =>
      prev.map((s) => (s.id === recordData.scheduleId ? { ...s, status: recordData.visitStatus } : s)),
    )
    setIsRecordDialogOpen(false)
    setRecordingSchedule(null)
  }

  const handleEditSchedule = (schedule: VisitSchedule) => {
    setIsDetailDialogOpen(false)
  }

  const todaySchedules = schedules
    .filter((s) => isSameDay(s.visitDate, today))
    .sort((a, b) => a.startTime.getTime() - b.startTime.getTime())

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex flex-col space-y-2 md:flex-row md:items-center md:justify-between md:space-y-0">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">ダッシュボード</h2>
          <p className="text-muted-foreground">本日は{format(today, "yyyy年M月d日 (E)", { locale: ja })}です。</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" size="sm">
            <Bell className="mr-2 h-4 w-4" />
            通知 <Badge className="ml-1 bg-primary text-primary-foreground">3</Badge>
          </Button>
          <Button variant="outline" size="sm" asChild>
            <Link href="/schedules">
              <Calendar className="mr-2 h-4 w-4" />
              カレンダー
            </Link>
          </Button>
          <Button size="sm" asChild>
            <Link href="/records/new">
              <Plus className="mr-2 h-4 w-4" />
              新規記録
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">本日の訪問予定</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{todaySchedules.length}件</div>
            <p className="text-xs text-muted-foreground">
              残り {todaySchedules.filter((s) => s.status !== VisitStatus.COMPLETED).length} 件
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">担当患者数</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12名</div>
            <p className="text-xs text-muted-foreground">先月比 +2名</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">未完了の記録</CardTitle>
            <ClipboardList className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3件</div>
            <p className="text-xs text-muted-foreground">24時間以内</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">要注意アラート</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2件</div>
            <p className="text-xs text-muted-foreground">確認が必要です</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="schedule" className="space-y-4">
        <TabsList className="grid grid-cols-3 w-full md:w-auto md:inline-grid">
          <TabsTrigger value="schedule">訪問スケジュール</TabsTrigger>
          <TabsTrigger value="alerts">要注意患者</TabsTrigger>
          <TabsTrigger value="records">最近の記録</TabsTrigger>
        </TabsList>

        <TabsContent value="schedule" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>本日の訪問スケジュール</CardTitle>
              <CardDescription>{format(today, "yyyy年M月d日 (E)", { locale: ja })} の訪問予定です</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {todaySchedules.length > 0 ? (
                todaySchedules.map((scheduleItem) => {
                  const patient = getPatientInfo(scheduleItem.patientId)
                  const visitDuration =
                    (scheduleItem.endTime.getTime() - scheduleItem.startTime.getTime()) / (1000 * 60)
                  const bgColor =
                    scheduleItem.status === VisitStatus.COMPLETED
                      ? "bg-green-50"
                      : scheduleItem.status === VisitStatus.IN_PROGRESS
                        ? "bg-orange-50"
                        : "bg-white"
                  const borderColor =
                    scheduleItem.status === VisitStatus.COMPLETED
                      ? "border-green-200"
                      : scheduleItem.status === VisitStatus.IN_PROGRESS
                        ? "border-orange-300"
                        : "border-gray-200"
                  return (
                    <div
                      key={scheduleItem.id}
                      className={`p-4 rounded-lg border ${bgColor} ${borderColor} shadow-sm space-y-3`}
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-3">
                          <div className="text-center w-16 flex-shrink-0">
                            <div className="text-xl font-bold">{format(scheduleItem.startTime, "HH:mm")}</div>
                            <div className="text-sm text-gray-500">{visitDuration}分</div>
                          </div>
                          <div>
                            <h4 className="text-lg font-bold">
                              {patient?.name} <span className="text-base font-medium">({patient?.age}歳)</span>
                            </h4>
                            <p className="text-sm text-gray-600">{patient?.condition}</p>
                          </div>
                        </div>
                        <Badge className={`${getVisitStatusColor(scheduleItem.status)} h-6 px-2.5`}>
                          {getVisitStatusName(scheduleItem.status)}
                        </Badge>
                      </div>

                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          {getSpecialManagementBadge(scheduleItem.patientId)}
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="bg-white"
                            onClick={() => handleDetailClick(scheduleItem)}
                          >
                            <Info className="mr-1.5 h-4 w-4" /> 詳細
                          </Button>
                          {(scheduleItem.status === VisitStatus.IN_PROGRESS ||
                            scheduleItem.status === VisitStatus.SCHEDULED) && (
                            <Button
                              size="sm"
                              className={`${scheduleItem.status === VisitStatus.IN_PROGRESS ? "bg-orange-500 hover:bg-orange-600" : "bg-primary hover:bg-primary/90"}`}
                              onClick={() => handleRecordClick(scheduleItem)}
                            >
                              <FileText className="mr-1.5 h-4 w-4" /> 記録
                            </Button>
                          )}
                        </div>
                      </div>

                      {scheduleItem.note && (
                        <div className="pt-2 border-t border-gray-200/80">
                          <p className="text-sm text-gray-500">備考: {scheduleItem.note}</p>
                        </div>
                      )}
                    </div>
                  )
                })
              ) : (
                <p className="text-center text-muted-foreground py-4">本日の訪問予定はありません。</p>
              )}
              <div className="mt-4 flex justify-end">
                <Button variant="outline" size="sm" asChild>
                  <Link href="/schedules">
                    スケジュール管理へ
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <ScheduleDetailDialog
        schedule={selectedSchedule}
        isOpen={isDetailDialogOpen}
        onClose={() => setIsDetailDialogOpen(false)}
        onEdit={handleEditSchedule}
        onCreateRecord={handleRecordClick}
        patientName={selectedSchedule ? getPatientInfo(selectedSchedule.patientId)?.name || "不明" : ""}
        staffName={selectedSchedule ? getStaffName(selectedSchedule.staffId) : ""}
      />

      <VisitRecordDialog
        schedule={recordingSchedule}
        isOpen={isRecordDialogOpen}
        onClose={() => setRecordingSchedule(null)}
        onSave={handleSaveRecord}
        patientName={recordingSchedule ? getPatientInfo(recordingSchedule.patientId)?.name || "不明" : ""}
        staffName={recordingSchedule ? getStaffName(recordingSchedule.staffId) : ""}
      />
    </div>
  )
}
