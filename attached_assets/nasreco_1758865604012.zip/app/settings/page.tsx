import type { Metadata } from "next"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import Link from "next/link"

export const metadata: Metadata = {
  title: "設定 | NASRECO",
  description: "システム設定を管理します",
}

export default function SettingsPage() {
  return (
    <div className="container mx-auto py-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight">設定</h1>
        <p className="text-muted-foreground">アカウント設定とシステム設定を管理します。</p>
      </div>

      <Tabs defaultValue="account">
        <TabsList className="mb-4">
          <TabsTrigger value="account">アカウント</TabsTrigger>
          <TabsTrigger value="notifications">通知</TabsTrigger>
          <TabsTrigger value="appearance">表示設定</TabsTrigger>
          <TabsTrigger value="system">システム</TabsTrigger>
        </TabsList>

        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle>アカウント情報</CardTitle>
              <CardDescription>アカウント情報を更新します。</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">名前</Label>
                <Input id="name" defaultValue="山田 花子" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">メールアドレス</Label>
                <Input id="email" defaultValue="yamada@kenkokai.example.com" />
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">キャンセル</Button>
              <Button>保存</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>通知設定</CardTitle>
              <CardDescription>通知の受け取り方を設定します。</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">メール通知</p>
                  <p className="text-sm text-muted-foreground">重要な通知をメールで受け取ります。</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">アプリ内通知</p>
                  <p className="text-sm text-muted-foreground">アプリ内で通知を受け取ります。</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">LINE通知</p>
                  <p className="text-sm text-muted-foreground">緊急の通知をLINEで受け取ります。</p>
                </div>
                <Switch />
              </div>
            </CardContent>
            <CardFooter>
              <Button>保存</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <CardTitle>表示設定</CardTitle>
              <CardDescription>アプリの表示方法をカスタマイズします。</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">ダークモード</p>
                  <p className="text-sm text-muted-foreground">暗い背景で表示します。</p>
                </div>
                <Switch />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">大きいフォント</p>
                  <p className="text-sm text-muted-foreground">文字サイズを大きくします。</p>
                </div>
                <Switch />
              </div>
            </CardContent>
            <CardFooter>
              <Button>保存</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="system">
          <Card>
            <CardHeader>
              <CardTitle>システム設定</CardTitle>
              <CardDescription>システム全体の設定を管理します。</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <Button variant="outline" className="justify-start" asChild>
                  <Link href="/settings/master-data">
                    <span className="mr-2">🏢</span>
                    事業所情報
                  </Link>
                </Button>

                <Button variant="outline" className="justify-start" asChild>
                  <Link href="/settings/users">
                    <span className="mr-2">👥</span>
                    ユーザー管理
                  </Link>
                </Button>
                <Button variant="outline" className="justify-start" asChild>
                  <Link href="/settings/forms">
                    <span className="mr-2">📋</span>
                    フォーム管理
                  </Link>
                </Button>

                <Button variant="outline" className="justify-start" asChild>
                  <Link href="/settings/templates">
                    <span className="mr-2">📝</span>
                    テンプレート管理
                  </Link>
                </Button>

                <Button variant="outline" className="justify-start" asChild>
                  <Link href="/settings/integrations">
                    <span className="mr-2">🔄</span>
                    データ連携
                  </Link>
                </Button>

                <Button variant="outline" className="justify-start" asChild>
                  <Link href="/settings/reports">
                    <span className="mr-2">📊</span>
                    レポート設定
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
