"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Plus, Search, Edit, Trash2, Copy, Check, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { FormTemplate } from "@/lib/db/form-schema"

// モックデータ
const mockTemplates: FormTemplate[] = [
  {
    id: "template-1",
    name: "標準訪問記録",
    description: "通常の訪問看護記録用テンプレート",
    type: "visit",
    sections: [
      {
        id: "section-1",
        title: "基本情報",
        fields: [
          { id: "field-1", type: "date", label: "訪問日", isRequired: true, width: "half" },
          { id: "field-2", type: "time", label: "訪問時間", isRequired: true, width: "half" },
          {
            id: "field-3",
            type: "select",
            label: "訪問理由",
            options: [
              { label: "定期訪問", value: "regular" },
              { label: "緊急訪問", value: "emergency" },
              { label: "臨時訪問", value: "extra" },
            ],
            width: "full",
          },
        ],
        order: 0,
        isCollapsible: true,
        isCollapsed: false,
      },
      {
        id: "section-2",
        title: "バイタルサイン",
        fields: [
          { id: "field-4", type: "number", label: "体温", helpText: "℃", width: "third" },
          { id: "field-5", type: "number", label: "脈拍", helpText: "回/分", width: "third" },
          { id: "field-6", type: "number", label: "血圧（収縮期）", helpText: "mmHg", width: "third" },
          { id: "field-7", type: "number", label: "血圧（拡張期）", helpText: "mmHg", width: "third" },
          { id: "field-8", type: "number", label: "SpO2", helpText: "%", width: "third" },
          { id: "field-9", type: "number", label: "呼吸数", helpText: "回/分", width: "third" },
        ],
        order: 1,
        isCollapsible: true,
        isCollapsed: false,
      },
      {
        id: "section-3",
        title: "看護記録",
        fields: [
          { id: "field-10", type: "textarea", label: "観察事項", isRequired: true, width: "full" },
          { id: "field-11", type: "textarea", label: "実施したケア", isRequired: true, width: "full" },
          { id: "field-12", type: "textarea", label: "患者・家族の反応", width: "full" },
          { id: "field-13", type: "media", label: "写真・動画", width: "full" },
        ],
        order: 2,
        isCollapsible: true,
        isCollapsed: false,
      },
    ],
    createdAt: new Date("2025-01-01"),
    updatedAt: new Date("2025-01-01"),
    createdBy: "user-1",
    isActive: true,
    tenantId: "tenant-1",
    version: 1,
  },
  {
    id: "template-2",
    name: "褥瘡アセスメント",
    description: "褥瘡の状態評価用テンプレート",
    type: "assessment",
    sections: [
      {
        id: "section-4",
        title: "基本情報",
        fields: [{ id: "field-14", type: "date", label: "評価日", isRequired: true, width: "full" }],
        order: 0,
        isCollapsible: true,
        isCollapsed: false,
      },
      {
        id: "section-5",
        title: "褥瘡評価",
        fields: [
          {
            id: "field-15",
            type: "select",
            label: "褥瘡部位",
            options: [
              { label: "仙骨部", value: "sacrum" },
              { label: "尾骨部", value: "coccyx" },
              { label: "大転子部", value: "greater_trochanter" },
              { label: "踵部", value: "heel" },
              { label: "その他", value: "other" },
            ],
            isRequired: true,
            width: "full",
          },
          {
            id: "field-16",
            type: "select",
            label: "DESIGN-R分類",
            options: [
              { label: "d1", value: "d1" },
              { label: "d2", value: "d2" },
              { label: "D3", value: "D3" },
              { label: "D4", value: "D4" },
              { label: "D5", value: "D5" },
            ],
            isRequired: true,
            width: "half",
          },
          { id: "field-17", type: "number", label: "サイズ（縦）", helpText: "cm", width: "half" },
          { id: "field-18", type: "number", label: "サイズ（横）", helpText: "cm", width: "half" },
          { id: "field-19", type: "number", label: "サイズ（深さ）", helpText: "cm", width: "half" },
          { id: "field-20", type: "media", label: "褥瘡画像", isRequired: true, width: "full" },
          { id: "field-21", type: "textarea", label: "所見", width: "full" },
        ],
        order: 1,
        isCollapsible: true,
        isCollapsed: false,
      },
    ],
    createdAt: new Date("2025-01-15"),
    updatedAt: new Date("2025-01-15"),
    createdBy: "user-1",
    isActive: true,
    tenantId: "tenant-1",
    version: 1,
  },
  {
    id: "template-3",
    name: "服薬管理記録",
    description: "服薬状況と管理に関する記録テンプレート",
    type: "visit",
    sections: [
      {
        id: "section-6",
        title: "基本情報",
        fields: [
          { id: "field-22", type: "date", label: "訪問日", isRequired: true, width: "half" },
          { id: "field-23", type: "time", label: "訪問時間", isRequired: true, width: "half" },
        ],
        order: 0,
        isCollapsible: true,
        isCollapsed: false,
      },
      {
        id: "section-7",
        title: "服薬状況",
        fields: [
          {
            id: "field-24",
            type: "radio",
            label: "服薬状況",
            options: [
              { label: "指示通り服用できている", value: "as_directed" },
              { label: "一部服用できていない", value: "partially" },
              { label: "ほとんど服用できていない", value: "rarely" },
            ],
            isRequired: true,
            width: "full",
          },
          {
            id: "field-25",
            type: "checkbox",
            label: "服薬できない理由",
            options: [
              { label: "飲み忘れ", value: "forget" },
              { label: "副作用", value: "side_effect" },
              { label: "嚥下困難", value: "swallowing_difficulty" },
              { label: "理解力低下", value: "cognitive_decline" },
              { label: "その他", value: "other" },
            ],
            width: "full",
            dependsOn: { field: "field-24", value: "partially" },
          },
          { id: "field-26", type: "textarea", label: "詳細", width: "full" },
        ],
        order: 1,
        isCollapsible: true,
        isCollapsed: false,
      },
    ],
    createdAt: new Date("2025-02-01"),
    updatedAt: new Date("2025-02-01"),
    createdBy: "user-2",
    isActive: true,
    tenantId: "tenant-1",
    version: 1,
  },
]

export default function TemplatesPage() {
  const [templates, setTemplates] = useState<FormTemplate[]>(mockTemplates)
  const [searchQuery, setSearchQuery] = useState("")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const router = useRouter()

  // 検索とフィルタリング
  const filteredTemplates = templates.filter((template) => {
    const matchesSearch =
      template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.description?.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesType = typeFilter === "all" || template.type === typeFilter

    return matchesSearch && matchesType
  })

  // テンプレートの削除
  const handleDeleteTemplate = (templateId: string) => {
    if (confirm("このテンプレートを削除してもよろしいですか？")) {
      setTemplates(templates.filter((template) => template.id !== templateId))
    }
  }

  // テンプレートの複製
  const handleDuplicateTemplate = (templateId: string) => {
    const templateToDuplicate = templates.find((template) => template.id === templateId)

    if (templateToDuplicate) {
      const newTemplate: FormTemplate = {
        ...templateToDuplicate,
        id: `template-${Date.now()}`,
        name: `${templateToDuplicate.name} (コピー)`,
        createdAt: new Date(),
        updatedAt: new Date(),
        version: 1,
      }

      setTemplates([...templates, newTemplate])
    }
  }

  // テンプレートの有効/無効切り替え
  const handleToggleActive = (templateId: string) => {
    setTemplates(
      templates.map((template) =>
        template.id === templateId ? { ...template, isActive: !template.isActive, updatedAt: new Date() } : template,
      ),
    )
  }

  // 新しいテンプレートの作成
  const handleCreateTemplate = () => {
    router.push("/settings/templates/new")
  }

  // テンプレートの編集
  const handleEditTemplate = (templateId: string) => {
    router.push(`/settings/templates/edit/${templateId}`)
  }

  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">テンプレート管理</h1>
          <p className="text-muted-foreground">フォームテンプレートの作成・編集・管理を行います</p>
        </div>
        <Button onClick={handleCreateTemplate}>
          <Plus className="mr-2 h-4 w-4" />
          新しいテンプレート
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>テンプレート一覧</CardTitle>
          <CardDescription>システムで使用するフォームテンプレートの一覧です</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="テンプレートを検索..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="タイプで絞り込み" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">すべてのタイプ</SelectItem>
                <SelectItem value="visit">訪問記録</SelectItem>
                <SelectItem value="assessment">アセスメント</SelectItem>
                <SelectItem value="plan">看護計画</SelectItem>
                <SelectItem value="custom">カスタム</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>テンプレート名</TableHead>
                <TableHead>タイプ</TableHead>
                <TableHead>最終更新日</TableHead>
                <TableHead>状態</TableHead>
                <TableHead className="w-[150px]">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTemplates.length > 0 ? (
                filteredTemplates.map((template) => (
                  <TableRow key={template.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{template.name}</div>
                        {template.description && (
                          <div className="text-sm text-muted-foreground">{template.description}</div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {template.type === "visit" && "訪問記録"}
                        {template.type === "assessment" && "アセスメント"}
                        {template.type === "plan" && "看護計画"}
                        {template.type === "custom" && "カスタム"}
                      </Badge>
                    </TableCell>
                    <TableCell>{template.updatedAt.toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Badge
                        variant={template.isActive ? "default" : "secondary"}
                        className="cursor-pointer"
                        onClick={() => handleToggleActive(template.id)}
                      >
                        {template.isActive ? <Check className="mr-1 h-3 w-3" /> : <X className="mr-1 h-3 w-3" />}
                        {template.isActive ? "有効" : "無効"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="icon" onClick={() => handleEditTemplate(template.id)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDuplicateTemplate(template.id)}>
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteTemplate(template.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-4">
                    テンプレートが見つかりません
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
