"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Plus } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"

// モックデータ
const mockForms = [
  {
    id: "1",
    name: "基本訪問記録フォーム",
    description: "標準的な訪問記録用フォーム",
    type: "record",
    lastUpdated: "2023-05-15",
    fields: 24,
  },
  {
    id: "2",
    name: "褥瘡アセスメント",
    description: "褥瘡の状態評価用フォーム",
    type: "assessment",
    lastUpdated: "2023-06-22",
    fields: 15,
  },
  {
    id: "3",
    name: "服薬管理チェックリスト",
    description: "服薬状況の確認用フォーム",
    type: "checklist",
    lastUpdated: "2023-04-10",
    fields: 12,
  },
  {
    id: "4",
    name: "ADL評価シート",
    description: "日常生活動作の評価フォーム",
    type: "assessment",
    lastUpdated: "2023-07-05",
    fields: 18,
  },
]

export default function FormsPage() {
  const router = useRouter()
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [newFormName, setNewFormName] = useState("")
  const [newFormDescription, setNewFormDescription] = useState("")
  const [newFormType, setNewFormType] = useState("record")

  const handleCreateForm = () => {
    // 実際の実装ではAPIを呼び出してフォームを作成する
    console.log("Creating form:", { name: newFormName, description: newFormDescription, type: newFormType })
    setIsCreateDialogOpen(false)

    // 新しいフォームのエディタページに遷移する想定
    // router.push(`/settings/forms/editor/new`)

    // モックデータなのでリセット
    setNewFormName("")
    setNewFormDescription("")
    setNewFormType("record")
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">フォーム管理</h1>
          <p className="text-muted-foreground mt-1">カスタムフォームの作成・編集・管理を行います</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              新規フォーム作成
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>新規フォームの作成</DialogTitle>
              <DialogDescription>新しいカスタムフォームの基本情報を入力してください。</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">フォーム名</Label>
                <Input
                  id="name"
                  value={newFormName}
                  onChange={(e) => setNewFormName(e.target.value)}
                  placeholder="例: 訪問看護記録フォーム"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description">説明</Label>
                <Textarea
                  id="description"
                  value={newFormDescription}
                  onChange={(e) => setNewFormDescription(e.target.value)}
                  placeholder="このフォームの用途や特徴を記入してください"
                />
              </div>
              <div className="grid gap-2">
                <Label>フォームタイプ</Label>
                <Tabs defaultValue="record" value={newFormType} onValueChange={setNewFormType}>
                  <TabsList className="grid grid-cols-3">
                    <TabsTrigger value="record">記録</TabsTrigger>
                    <TabsTrigger value="assessment">アセスメント</TabsTrigger>
                    <TabsTrigger value="checklist">チェックリスト</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                キャンセル
              </Button>
              <Button onClick={handleCreateForm} disabled={!newFormName.trim()}>
                作成
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {mockForms.map((form) => (
          <Card key={form.id} className="overflow-hidden">
            <CardHeader className="pb-3">
              <CardTitle>{form.name}</CardTitle>
              <CardDescription>{form.description}</CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center">
                  <span className="text-muted-foreground">タイプ:</span>
                  <span className="ml-1 font-medium">
                    {form.type === "record" ? "記録" : form.type === "assessment" ? "アセスメント" : "チェックリスト"}
                  </span>
                </div>
                <div className="flex items-center">
                  <span className="text-muted-foreground">項目数:</span>
                  <span className="ml-1 font-medium">{form.fields}</span>
                </div>
              </div>
              <div className="mt-2 text-sm text-muted-foreground">最終更新: {form.lastUpdated}</div>
            </CardContent>
            <CardFooter className="flex justify-between pt-3">
              <Button variant="outline" size="sm" onClick={() => router.push(`/settings/forms/${form.id}`)}>
                プレビュー
              </Button>
              <Button size="sm" onClick={() => router.push(`/settings/forms/editor/${form.id}`)}>
                編集
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}
