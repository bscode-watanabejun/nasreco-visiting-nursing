"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Save } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

// モックデータ - 実際の実装ではAPIから取得
const mockForm = {
  id: "1",
  name: "基本訪問記録フォーム",
  description: "標準的な訪問記録用フォーム",
  type: "record",
  sections: [
    {
      id: "s1",
      title: "基本情報",
      fields: [
        { id: "f1", type: "text", label: "利用者名", required: true, placeholder: "山田 太郎" },
        { id: "f2", type: "date", label: "訪問日", required: true },
        { id: "f3", type: "time", label: "訪問時間", required: true },
        { id: "f4", type: "select", label: "訪問スタッフ", required: true, options: ["看護師A", "看護師B", "看護師C"] },
      ],
    },
    {
      id: "s2",
      title: "バイタルサイン",
      fields: [
        { id: "f5", type: "number", label: "体温", required: false, unit: "℃", min: 35, max: 42, step: 0.1 },
        { id: "f6", type: "number", label: "脈拍", required: false, unit: "回/分", min: 40, max: 200 },
        { id: "f7", type: "number", label: "血圧（収縮期）", required: false, unit: "mmHg", min: 60, max: 300 },
        { id: "f8", type: "number", label: "血圧（拡張期）", required: false, unit: "mmHg", min: 40, max: 200 },
        { id: "f9", type: "number", label: "SpO2", required: false, unit: "%", min: 70, max: 100 },
      ],
    },
    {
      id: "s3",
      title: "処置内容",
      fields: [
        {
          id: "f10",
          type: "checkbox",
          label: "実施した処置",
          options: ["点滴", "採血", "褥瘡処置", "膀胱留置カテーテル管理", "胃ろう管理", "吸引", "酸素管理"],
        },
        { id: "f11", type: "textarea", label: "処置詳細", rows: 3 },
      ],
    },
    {
      id: "s4",
      title: "観察・アセスメント",
      fields: [
        { id: "f12", type: "radio", label: "全身状態", options: ["良好", "普通", "不良"] },
        { id: "f13", type: "textarea", label: "観察内容", rows: 4 },
        { id: "f14", type: "textarea", label: "アセスメント", rows: 4 },
      ],
    },
    {
      id: "s5",
      title: "指導内容・次回予定",
      fields: [
        { id: "f15", type: "textarea", label: "指導内容", rows: 3 },
        { id: "f16", type: "textarea", label: "次回予定", rows: 2 },
        { id: "f17", type: "date", label: "次回訪問予定日" },
      ],
    },
  ],
}

export default function FormEditorPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("design")
  const [formData, setFormData] = useState(mockForm)
  const [formName, setFormName] = useState(mockForm.name)
  const [formDescription, setFormDescription] = useState(mockForm.description)

  // 実際の実装ではAPIからフォームデータを取得
  useEffect(() => {
    // API呼び出しのモック
    console.log(`Fetching form data for ID: ${params.id}`)
    // setFormData(fetchedData)
    // setFormName(fetchedData.name)
    // setFormDescription(fetchedData.description)
  }, [params.id])

  const handleSave = () => {
    const updatedForm = {
      ...formData,
      name: formName,
      description: formDescription,
    }

    // 実際の実装ではAPIを呼び出して保存
    console.log("Saving form:", updatedForm)

    // 成功メッセージを表示するなどの処理
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Button variant="ghost" size="icon" onClick={() => router.push("/settings/forms")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="ml-4">
            <h1 className="text-3xl font-bold tracking-tight">フォームエディタ</h1>
            <p className="text-muted-foreground mt-1">
              {params.id === "new" ? "新規フォームの作成" : "フォームの編集"}
            </p>
          </div>
        </div>
        <Button onClick={handleSave}>
          <Save className="mr-2 h-4 w-4" />
          保存
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="form-name">フォーム名</Label>
              <Input id="form-name" value={formName} onChange={(e) => setFormName(e.target.value)} className="mt-1" />
            </div>
            <div>
              <Label htmlFor="form-type">フォームタイプ</Label>
              <Input
                id="form-type"
                value={
                  formData.type === "record"
                    ? "記録"
                    : formData.type === "assessment"
                      ? "アセスメント"
                      : "チェックリスト"
                }
                readOnly
                className="mt-1 bg-muted"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="form-description">説明</Label>
            <Textarea
              id="form-description"
              value={formDescription}
              onChange={(e) => setFormDescription(e.target.value)}
              className="mt-1"
            />
          </div>
        </div>

        <Separator />

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="design">デザイン</TabsTrigger>
            <TabsTrigger value="logic">ロジック</TabsTrigger>
            <TabsTrigger value="preview">プレビュー</TabsTrigger>
          </TabsList>
          <TabsContent value="design" className="mt-6">
            <div className="bg-card rounded-lg border p-6">
              <div className="space-y-6">
                {formData.sections.map((section, sectionIndex) => (
                  <div key={section.id} className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-medium">{section.title}</h3>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          編集
                        </Button>
                        <Button variant="outline" size="sm">
                          移動
                        </Button>
                        <Button variant="destructive" size="sm">
                          削除
                        </Button>
                      </div>
                    </div>
                    <div className="grid gap-4 pl-4 border-l-2 border-muted-foreground/20">
                      {section.fields.map((field, fieldIndex) => (
                        <div key={field.id} className="flex items-center justify-between bg-background p-3 rounded-md">
                          <div className="flex-1">
                            <div className="flex items-center">
                              <span className="font-medium">{field.label}</span>
                              {field.required && <span className="ml-2 text-red-500 text-sm">*</span>}
                            </div>
                            <div className="text-sm text-muted-foreground mt-1">
                              タイプ: {field.type}
                              {field.unit && ` (単位: ${field.unit})`}
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="sm">
                              編集
                            </Button>
                            <Button variant="ghost" size="sm">
                              移動
                            </Button>
                            <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                              削除
                            </Button>
                          </div>
                        </div>
                      ))}
                      <Button variant="outline" className="w-full">
                        + フィールド追加
                      </Button>
                    </div>
                  </div>
                ))}
                <Button variant="outline" className="w-full">
                  + セクション追加
                </Button>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="logic" className="mt-6">
            <div className="bg-card rounded-lg border p-6">
              <div className="text-center py-12">
                <h3 className="text-lg font-medium mb-2">条件付きロジック設定</h3>
                <p className="text-muted-foreground mb-4">
                  特定の条件に基づいて表示/非表示を切り替えるロジックを設定できます
                </p>
                <Button>+ 新しいロジックを追加</Button>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="preview" className="mt-6">
            <div className="bg-card rounded-lg border p-6">
              <h2 className="text-xl font-bold mb-6">{formName}</h2>

              {formData.sections.map((section) => (
                <div key={section.id} className="mb-8">
                  <h3 className="text-lg font-medium mb-4 pb-2 border-b">{section.title}</h3>
                  <div className="grid gap-4">
                    {section.fields.map((field) => (
                      <div key={field.id} className="space-y-2">
                        <Label>
                          {field.label}
                          {field.required && <span className="text-red-500 ml-1">*</span>}
                        </Label>

                        {field.type === "text" && <Input placeholder={field.placeholder || ""} />}

                        {field.type === "textarea" && <Textarea rows={field.rows || 3} />}

                        {field.type === "number" && (
                          <div className="flex items-center">
                            <Input type="number" min={field.min} max={field.max} step={field.step || 1} />
                            {field.unit && <span className="ml-2">{field.unit}</span>}
                          </div>
                        )}

                        {field.type === "date" && <Input type="date" />}

                        {field.type === "time" && <Input type="time" />}

                        {/* 他のフィールドタイプも同様に実装 */}
                      </div>
                    ))}
                  </div>
                </div>
              ))}

              <div className="flex justify-end space-x-4 mt-6">
                <Button variant="outline">キャンセル</Button>
                <Button>保存</Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
