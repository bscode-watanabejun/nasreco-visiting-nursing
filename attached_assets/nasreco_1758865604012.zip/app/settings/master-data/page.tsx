"use client"

import { useState } from "react"
import { Plus, Trash2, Save, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Switch } from "@/components/ui/switch"
import type { MasterDataCategory, MasterDataItem } from "@/lib/db/form-schema"

// モックデータ
const mockMasterData: MasterDataCategory[] = [
  {
    id: "category-1",
    name: "診療科目",
    description: "医療機関の診療科目リスト",
    items: [
      { id: "item-1", value: "internal", label: "内科", category: "category-1", order: 0, isActive: true },
      { id: "item-2", value: "surgery", label: "外科", category: "category-1", order: 1, isActive: true },
      { id: "item-3", value: "pediatrics", label: "小児科", category: "category-1", order: 2, isActive: true },
      { id: "item-4", value: "orthopedics", label: "整形外科", category: "category-1", order: 3, isActive: true },
      { id: "item-5", value: "psychiatry", label: "精神科", category: "category-1", order: 4, isActive: true },
    ],
    createdAt: new Date("2025-01-01"),
    updatedAt: new Date("2025-01-01"),
    tenantId: "tenant-1",
  },
  {
    id: "category-2",
    name: "訪問理由",
    description: "訪問看護の理由カテゴリ",
    items: [
      { id: "item-6", value: "regular", label: "定期訪問", category: "category-2", order: 0, isActive: true },
      { id: "item-7", value: "emergency", label: "緊急訪問", category: "category-2", order: 1, isActive: true },
      { id: "item-8", value: "assessment", label: "アセスメント", category: "category-2", order: 2, isActive: true },
      { id: "item-9", value: "instruction", label: "指導", category: "category-2", order: 3, isActive: true },
      { id: "item-10", value: "followup", label: "フォローアップ", category: "category-2", order: 4, isActive: true },
    ],
    createdAt: new Date("2025-01-01"),
    updatedAt: new Date("2025-01-01"),
    tenantId: "tenant-1",
  },
  {
    id: "category-3",
    name: "処置内容",
    description: "訪問看護で実施する処置内容リスト",
    items: [
      {
        id: "item-11",
        value: "vital_check",
        label: "バイタルチェック",
        category: "category-3",
        order: 0,
        isActive: true,
      },
      { id: "item-12", value: "medication", label: "服薬管理", category: "category-3", order: 1, isActive: true },
      { id: "item-13", value: "wound_care", label: "創傷ケア", category: "category-3", order: 2, isActive: true },
      { id: "item-14", value: "injection", label: "注射", category: "category-3", order: 3, isActive: true },
      { id: "item-15", value: "rehabilitation", label: "リハビリ", category: "category-3", order: 4, isActive: true },
    ],
    createdAt: new Date("2025-01-01"),
    updatedAt: new Date("2025-01-01"),
    tenantId: "tenant-1",
  },
]

export default function MasterDataPage() {
  const [masterData, setMasterData] = useState<MasterDataCategory[]>(mockMasterData)
  const [activeTab, setActiveTab] = useState<string>(mockMasterData[0]?.id || "")
  const [searchQuery, setSearchQuery] = useState("")
  const [newCategoryName, setNewCategoryName] = useState("")
  const [newCategoryDescription, setNewCategoryDescription] = useState("")
  const [showNewCategoryForm, setShowNewCategoryForm] = useState(false)
  const [editingItem, setEditingItem] = useState<MasterDataItem | null>(null)
  const [newItemLabel, setNewItemLabel] = useState("")
  const [newItemValue, setNewItemValue] = useState("")

  // アクティブなカテゴリを取得
  const activeCategory = masterData.find((category) => category.id === activeTab)

  // 検索フィルタリング
  const filteredItems =
    activeCategory?.items.filter(
      (item) =>
        item.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.value.toLowerCase().includes(searchQuery.toLowerCase()),
    ) || []

  // 新しいカテゴリの追加
  const handleAddCategory = () => {
    if (!newCategoryName) return

    const newCategory: MasterDataCategory = {
      id: `category-${Date.now()}`,
      name: newCategoryName,
      description: newCategoryDescription,
      items: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      tenantId: "tenant-1", // 実際の実装ではテナントIDを設定
    }

    setMasterData([...masterData, newCategory])
    setActiveTab(newCategory.id)
    setNewCategoryName("")
    setNewCategoryDescription("")
    setShowNewCategoryForm(false)
  }

  // カテゴリの削除
  const handleDeleteCategory = (categoryId: string) => {
    if (confirm("このカテゴリを削除してもよろしいですか？関連するすべての項目も削除されます。")) {
      const updatedMasterData = masterData.filter((category) => category.id !== categoryId)
      setMasterData(updatedMasterData)

      if (activeTab === categoryId) {
        setActiveTab(updatedMasterData[0]?.id || "")
      }
    }
  }

  // 新しい項目の追加
  const handleAddItem = () => {
    if (!activeCategory || !newItemLabel || !newItemValue) return

    const newItem: MasterDataItem = {
      id: `item-${Date.now()}`,
      value: newItemValue,
      label: newItemLabel,
      category: activeCategory.id,
      order: activeCategory.items.length,
      isActive: true,
    }

    const updatedCategory = {
      ...activeCategory,
      items: [...activeCategory.items, newItem],
      updatedAt: new Date(),
    }

    setMasterData(masterData.map((category) => (category.id === activeCategory.id ? updatedCategory : category)))

    setNewItemLabel("")
    setNewItemValue("")
  }

  // 項目の更新
  const handleUpdateItem = (item: MasterDataItem, updates: Partial<MasterDataItem>) => {
    if (!activeCategory) return

    const updatedItems = activeCategory.items.map((i) => (i.id === item.id ? { ...i, ...updates } : i))

    const updatedCategory = {
      ...activeCategory,
      items: updatedItems,
      updatedAt: new Date(),
    }

    setMasterData(masterData.map((category) => (category.id === activeCategory.id ? updatedCategory : category)))
  }

  // 項目の削除
  const handleDeleteItem = (itemId: string) => {
    if (!activeCategory) return

    const updatedItems = activeCategory.items.filter((item) => item.id !== itemId)

    const updatedCategory = {
      ...activeCategory,
      items: updatedItems,
      updatedAt: new Date(),
    }

    setMasterData(masterData.map((category) => (category.id === activeCategory.id ? updatedCategory : category)))
  }

  // 編集モードの切り替え
  const toggleEditMode = (item: MasterDataItem | null) => {
    setEditingItem(item)
  }

  // 編集内容の保存
  const saveItemChanges = () => {
    if (!editingItem || !activeCategory) return

    handleUpdateItem(editingItem, editingItem)
    setEditingItem(null)
  }

  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">マスタデータ管理</h1>
          <p className="text-muted-foreground">システムで使用する選択肢や項目リストを管理します</p>
        </div>
        <Button onClick={() => setShowNewCategoryForm(!showNewCategoryForm)}>
          <Plus className="mr-2 h-4 w-4" />
          新しいカテゴリ
        </Button>
      </div>

      {showNewCategoryForm && (
        <Card>
          <CardHeader>
            <CardTitle>新しいカテゴリの追加</CardTitle>
            <CardDescription>新しいマスタデータカテゴリを作成します</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="category-name">カテゴリ名</Label>
              <Input
                id="category-name"
                value={newCategoryName}
                onChange={(e) => setNewCategoryName(e.target.value)}
                placeholder="例: 診療科目"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="category-description">説明</Label>
              <Input
                id="category-description"
                value={newCategoryDescription}
                onChange={(e) => setNewCategoryDescription(e.target.value)}
                placeholder="例: 医療機関の診療科目リスト"
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowNewCategoryForm(false)}>
                キャンセル
              </Button>
              <Button onClick={handleAddCategory} disabled={!newCategoryName}>
                カテゴリを追加
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {masterData.length > 0 ? (
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="flex justify-between items-center">
            <TabsList className="mb-4">
              {masterData.map((category) => (
                <TabsTrigger key={category.id} value={category.id}>
                  {category.name}
                </TabsTrigger>
              ))}
            </TabsList>
            {activeTab && (
              <Button variant="outline" size="sm" onClick={() => handleDeleteCategory(activeTab)}>
                <Trash2 className="mr-2 h-4 w-4" />
                カテゴリを削除
              </Button>
            )}
          </div>

          {masterData.map((category) => (
            <TabsContent key={category.id} value={category.id} className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>{category.name}</CardTitle>
                  <CardDescription>{category.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="項目を検索..."
                        className="pl-8"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                  </div>

                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>表示名</TableHead>
                        <TableHead>値</TableHead>
                        <TableHead>有効</TableHead>
                        <TableHead className="w-[100px]">操作</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredItems.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell>
                            {editingItem?.id === item.id ? (
                              <Input
                                value={editingItem.label}
                                onChange={(e) =>
                                  setEditingItem({
                                    ...editingItem,
                                    label: e.target.value,
                                  })
                                }
                              />
                            ) : (
                              item.label
                            )}
                          </TableCell>
                          <TableCell>
                            {editingItem?.id === item.id ? (
                              <Input
                                value={editingItem.value}
                                onChange={(e) =>
                                  setEditingItem({
                                    ...editingItem,
                                    value: e.target.value,
                                  })
                                }
                              />
                            ) : (
                              item.value
                            )}
                          </TableCell>
                          <TableCell>
                            <Switch
                              checked={editingItem?.id === item.id ? editingItem.isActive : item.isActive}
                              onCheckedChange={(checked) => {
                                if (editingItem?.id === item.id) {
                                  setEditingItem({
                                    ...editingItem,
                                    isActive: checked,
                                  })
                                } else {
                                  handleUpdateItem(item, { isActive: checked })
                                }
                              }}
                            />
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {editingItem?.id === item.id ? (
                                <Button variant="ghost" size="icon" onClick={saveItemChanges}>
                                  <Save className="h-4 w-4" />
                                </Button>
                              ) : (
                                <Button variant="ghost" size="icon" onClick={() => toggleEditMode(item)}>
                                  <svg
                                    xmlns="http://www.w3.org/2000/svg"
                                    width="24"
                                    height="24"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    strokeWidth="2"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    className="h-4 w-4"
                                  >
                                    <path d="M17 3a2.85 2.85 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
                                    <path d="m15 5 4 4" />
                                  </svg>
                                </Button>
                              )}
                              <Button variant="ghost" size="icon" onClick={() => handleDeleteItem(item.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                      <TableRow>
                        <TableCell>
                          <Input
                            placeholder="新しい表示名"
                            value={newItemLabel}
                            onChange={(e) => setNewItemLabel(e.target.value)}
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            placeholder="新しい値"
                            value={newItemValue}
                            onChange={(e) => setNewItemValue(e.target.value)}
                          />
                        </TableCell>
                        <TableCell>
                          <Switch checked={true} disabled />
                        </TableCell>
                        <TableCell>
                          <Button onClick={handleAddItem} disabled={!newItemLabel || !newItemValue}>
                            追加
                          </Button>
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <p className="text-muted-foreground mb-4">
              マスタデータカテゴリがありません。新しいカテゴリを追加してください。
            </p>
            <Button onClick={() => setShowNewCategoryForm(true)}>
              <Plus className="mr-2 h-4 w-4" />
              カテゴリを追加
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
