"use client"

import { useState } from "react"
import { Plus, Search, Edit, Trash2, Save, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { TextTemplate } from "@/lib/db/form-schema"

// モックデータ
const mockTextTemplates: TextTemplate[] = [
  {
    id: "text-1",
    title: "バイタル安定",
    content: "バイタルサインは安定しています。特に異常所見は認められません。",
    category: "観察記録",
    tags: ["バイタル", "一般状態"],
    createdAt: new Date("2025-01-01"),
    updatedAt: new Date("2025-01-01"),
    createdBy: "user-1",
    tenantId: "tenant-1",
    usageCount: 42,
  },
  {
    id: "text-2",
    title: "服薬管理",
    content: "処方薬の管理状況を確認。指示通りに内服できています。残薬の過不足はありません。",
    category: "服薬管理",
    tags: ["服薬", "管理"],
    createdAt: new Date("2025-01-05"),
    updatedAt: new Date("2025-01-05"),
    createdBy: "user-1",
    tenantId: "tenant-1",
    usageCount: 38,
  },
  {
    id: "text-3",
    title: "褥瘡処置",
    content:
      "仙骨部の褥瘡に対し、洗浄・消毒後、指示のあるハイドロコロイド材を貼付しました。発赤の範囲は縮小傾向にあります。",
    category: "処置",
    tags: ["褥瘡", "創傷ケア"],
    createdAt: new Date("2025-01-10"),
    updatedAt: new Date("2025-01-10"),
    createdBy: "user-2",
    tenantId: "tenant-1",
    usageCount: 15,
  },
  {
    id: "text-4",
    title: "リハビリ実施",
    content:
      "関節可動域訓練および筋力強化訓練を実施。痛みなく実施できました。自主トレーニングの方法についても再指導しました。",
    category: "リハビリ",
    tags: ["ROM", "筋力訓練", "自主トレ"],
    createdAt: new Date("2025-01-15"),
    updatedAt: new Date("2025-01-15"),
    createdBy: "user-2",
    tenantId: "tenant-1",
    usageCount: 27,
  },
  {
    id: "text-5",
    title: "食事摂取状況",
    content: "食事摂取量は全量摂取。水分摂取も良好です。嚥下状態に問題はありません。",
    category: "栄養",
    tags: ["食事", "嚥下", "水分"],
    createdAt: new Date("2025-01-20"),
    updatedAt: new Date("2025-01-20"),
    createdBy: "user-1",
    tenantId: "tenant-1",
    usageCount: 31,
  },
]

// カテゴリのリスト
const categories = ["観察記録", "服薬管理", "処置", "リハビリ", "栄養", "排泄", "清潔", "指導", "その他"]

export default function TextTemplatesPage() {
  const [textTemplates, setTextTemplates] = useState<TextTemplate[]>(mockTextTemplates)
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState<string>("all")
  const [editingTemplate, setEditingTemplate] = useState<TextTemplate | null>(null)
  const [newTemplate, setNewTemplate] = useState<Partial<TextTemplate>>({
    title: "",
    content: "",
    category: "",
    tags: [],
  })
  const [showNewForm, setShowNewForm] = useState(false)
  const [newTagInput, setNewTagInput] = useState("")

  // 検索とフィルタリング
  const filteredTemplates = textTemplates.filter((template) => {
    const matchesSearch =
      template.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesCategory = categoryFilter === "all" || template.category === categoryFilter

    return matchesSearch && matchesCategory
  })

  // テンプレートの削除
  const handleDeleteTemplate = (templateId: string) => {
    if (confirm("このテンプレートを削除してもよろしいですか？")) {
      setTextTemplates(textTemplates.filter((template) => template.id !== templateId))
    }
  }

  // 編集モードの切り替え
  const handleEditTemplate = (template: TextTemplate) => {
    setEditingTemplate({ ...template })
  }

  // 編集内容の保存
  const handleSaveEdit = () => {
    if (!editingTemplate) return

    setTextTemplates(
      textTemplates.map((template) =>
        template.id === editingTemplate.id ? { ...editingTemplate, updatedAt: new Date() } : template,
      ),
    )
    setEditingTemplate(null)
  }

  // 編集のキャンセル
  const handleCancelEdit = () => {
    setEditingTemplate(null)
  }

  // 新しいテンプレートの追加
  const handleAddTemplate = () => {
    if (!newTemplate.title || !newTemplate.content || !newTemplate.category) return

    const newTextTemplate: TextTemplate = {
      id: `text-${Date.now()}`,
      title: newTemplate.title,
      content: newTemplate.content,
      category: newTemplate.category,
      tags: newTemplate.tags || [],
      createdAt: new Date(),
      updatedAt: new Date(),
      createdBy: "user-1", // 実際の実装ではログインユーザーのIDを設定
      tenantId: "tenant-1", // 実際の実装ではテナントIDを設定
      usageCount: 0,
    }

    setTextTemplates([...textTemplates, newTextTemplate])
    setNewTemplate({
      title: "",
      content: "",
      category: "",
      tags: [],
    })
    setShowNewForm(false)
  }

  // タグの追加
  const handleAddTag = (templateId: string | null, tag: string) => {
    if (!tag) return

    if (templateId === null) {
      // 新規テンプレートにタグを追加
      setNewTemplate({
        ...newTemplate,
        tags: [...(newTemplate.tags || []), tag],
      })
      setNewTagInput("")
    } else if (editingTemplate && editingTemplate.id === templateId) {
      // 編集中のテンプレートにタグを追加
      setEditingTemplate({
        ...editingTemplate,
        tags: [...editingTemplate.tags, tag],
      })
      setNewTagInput("")
    }
  }

  // タグの削除
  const handleRemoveTag = (templateId: string | null, tagIndex: number) => {
    if (templateId === null) {
      // 新規テンプレートからタグを削除
      const newTags = [...(newTemplate.tags || [])]
      newTags.splice(tagIndex, 1)
      setNewTemplate({
        ...newTemplate,
        tags: newTags,
      })
    } else if (editingTemplate && editingTemplate.id === templateId) {
      // 編集中のテンプレートからタグを削除
      const newTags = [...editingTemplate.tags]
      newTags.splice(tagIndex, 1)
      setEditingTemplate({
        ...editingTemplate,
        tags: newTags,
      })
    }
  }

  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">定型文テンプレート</h1>
          <p className="text-muted-foreground">記録入力時に使用する定型文テンプレートを管理します</p>
        </div>
        <Button onClick={() => setShowNewForm(!showNewForm)}>
          <Plus className="mr-2 h-4 w-4" />
          新しい定型文
        </Button>
      </div>

      {showNewForm && (
        <Card>
          <CardHeader>
            <CardTitle>新しい定型文テンプレート</CardTitle>
            <CardDescription>記録入力時に使用する定型文を作成します</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="new-title" className="text-sm font-medium">
                タイトル
              </label>
              <Input
                id="new-title"
                value={newTemplate.title}
                onChange={(e) => setNewTemplate({ ...newTemplate, title: e.target.value })}
                placeholder="例: バイタル安定"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="new-content" className="text-sm font-medium">
                内容
              </label>
              <Textarea
                id="new-content"
                value={newTemplate.content}
                onChange={(e) => setNewTemplate({ ...newTemplate, content: e.target.value })}
                placeholder="例: バイタルサインは安定しています。特に異常所見は認められません。"
                rows={4}
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="new-category" className="text-sm font-medium">
                カテゴリ
              </label>
              <Select
                value={newTemplate.category}
                onValueChange={(value) => setNewTemplate({ ...newTemplate, category: value })}
              >
                <SelectTrigger id="new-category">
                  <SelectValue placeholder="カテゴリを選択" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">タグ</label>
              <div className="flex flex-wrap gap-2 mb-2">
                {(newTemplate.tags || []).map((tag, index) => (
                  <Badge key={index} variant="secondary" className="gap-1">
                    {tag}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(null, index)}
                      className="ml-1 rounded-full hover:bg-muted"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
              <div className="flex gap-2">
                <Input
                  value={newTagInput}
                  onChange={(e) => setNewTagInput(e.target.value)}
                  placeholder="新しいタグ"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault()
                      handleAddTag(null, newTagInput)
                    }
                  }}
                />
                <Button type="button" onClick={() => handleAddTag(null, newTagInput)} disabled={!newTagInput}>
                  追加
                </Button>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button
                variant="outline"
                onClick={() => {
                  setShowNewForm(false)
                  setNewTemplate({
                    title: "",
                    content: "",
                    category: "",
                    tags: [],
                  })
                }}
              >
                キャンセル
              </Button>
              <Button
                onClick={handleAddTemplate}
                disabled={!newTemplate.title || !newTemplate.content || !newTemplate.category}
              >
                保存
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>定型文テンプレート一覧</CardTitle>
          <CardDescription>記録入力時に使用できる定型文テンプレートの一覧です</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="テンプレートを検索..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="カテゴリで絞り込み" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">すべてのカテゴリ</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>タイトル</TableHead>
                <TableHead className="w-[40%]">内容</TableHead>
                <TableHead>カテゴリ</TableHead>
                <TableHead>タグ</TableHead>
                <TableHead>使用回数</TableHead>
                <TableHead className="w-[100px]">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTemplates.length > 0 ? (
                filteredTemplates.map((template) => (
                  <TableRow key={template.id}>
                    <TableCell>
                      {editingTemplate?.id === template.id ? (
                        <Input
                          value={editingTemplate.title}
                          onChange={(e) =>
                            setEditingTemplate({
                              ...editingTemplate,
                              title: e.target.value,
                            })
                          }
                        />
                      ) : (
                        template.title
                      )}
                    </TableCell>
                    <TableCell>
                      {editingTemplate?.id === template.id ? (
                        <Textarea
                          value={editingTemplate.content}
                          onChange={(e) =>
                            setEditingTemplate({
                              ...editingTemplate,
                              content: e.target.value,
                            })
                          }
                          rows={3}
                        />
                      ) : (
                        <div className="line-clamp-3">{template.content}</div>
                      )}
                    </TableCell>
                    <TableCell>
                      {editingTemplate?.id === template.id ? (
                        <Select
                          value={editingTemplate.category}
                          onValueChange={(value) =>
                            setEditingTemplate({
                              ...editingTemplate,
                              category: value,
                            })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map((category) => (
                              <SelectItem key={category} value={category}>
                                {category}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <Badge variant="outline">{template.category}</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      {editingTemplate?.id === template.id ? (
                        <div className="space-y-2">
                          <div className="flex flex-wrap gap-1">
                            {editingTemplate.tags.map((tag, index) => (
                              <Badge key={index} variant="secondary" className="gap-1">
                                {tag}
                                <button
                                  type="button"
                                  onClick={() => handleRemoveTag(template.id, index)}
                                  className="ml-1 rounded-full hover:bg-muted"
                                >
                                  <X className="h-3 w-3" />
                                </button>
                              </Badge>
                            ))}
                          </div>
                          <div className="flex gap-1">
                            <Input
                              value={newTagInput}
                              onChange={(e) => setNewTagInput(e.target.value)}
                              placeholder="新しいタグ"
                              size={10}
                              onKeyDown={(e) => {
                                if (e.key === "Enter") {
                                  e.preventDefault()
                                  handleAddTag(template.id, newTagInput)
                                }
                              }}
                            />
                            <Button
                              size="sm"
                              onClick={() => handleAddTag(template.id, newTagInput)}
                              disabled={!newTagInput}
                            >
                              追加
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-wrap gap-1">
                          {template.tags.map((tag, index) => (
                            <Badge key={index} variant="secondary">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>{template.usageCount}回</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {editingTemplate?.id === template.id ? (
                          <>
                            <Button variant="ghost" size="icon" onClick={handleSaveEdit}>
                              <Save className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={handleCancelEdit}>
                              <X className="h-4 w-4" />
                            </Button>
                          </>
                        ) : (
                          <>
                            <Button variant="ghost" size="icon" onClick={() => handleEditTemplate(template)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDeleteTemplate(template.id)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-4">
                    テンプレートが見つかりません
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
