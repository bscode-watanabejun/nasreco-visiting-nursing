"use client"

import type React from "react"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Logo } from "@/components/logo"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, Loader2 } from "lucide-react"
import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth/auth-context"
import { useRouter, useSearchParams } from "next/navigation"

export default function Home() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { login, error, user, loading } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()
  const redirect = searchParams.get("redirect") || "/dashboard"
  const [isClient, setIsClient] = useState(false)

  // クライアントサイドレンダリングの確認
  useEffect(() => {
    setIsClient(true)
  }, [])

  // ユーザーが既にログインしている場合はリダイレクト
  useEffect(() => {
    if (isClient && !loading && user) {
      router.push(redirect)
    }
  }, [loading, user, router, redirect, isClient])

  // ログインフォームの送信
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      await login(email, password)
    } catch (submitError) {
      console.error("Form submission error:", submitError)
    } finally {
      setIsSubmitting(false)
    }
  }

  // ローディング中または既にログイン済みの場合
  if (!isClient || loading || user) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <main className="flex-1 flex items-center justify-center p-4 md:p-8">
        <div className="w-full max-w-5xl grid gap-6 lg:grid-cols-2">
          <div className="flex flex-col justify-center space-y-6">
            <div className="space-y-2">
              <Logo size="lg" />
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">出張看護記録システム</h1>
              <p className="text-xl text-muted-foreground">
                看護師の業務効率を向上させ、患者ケアの質を高めるための包括的な記録システム
              </p>
            </div>
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span>NANDA看護診断に基づいた計画書作成</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span>SOAP形式での記録と計画書との紐付け</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span>患者情報の一元管理</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span>AI支援による業務効率化</span>
              </div>
            </div>
          </div>

          <Card className="shadow-lg">
            <form onSubmit={handleSubmit}>
              <CardHeader className="space-y-1">
                <CardTitle className="text-2xl text-center">ログイン</CardTitle>
                <CardDescription className="text-center">アカウント情報を入力してログインしてください</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {error && <div className="p-3 rounded-md bg-red-50 text-red-800 text-sm">{error}</div>}
                <div className="space-y-2">
                  <Label htmlFor="email">メールアドレス</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="name@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password">パスワード</Label>
                    <Link href="/forgot-password" className="text-sm text-primary underline underline-offset-4">
                      パスワードを忘れた方
                    </Link>
                  </div>
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>
                <div className="text-sm text-muted-foreground">
                  <p>テスト用アカウント:</p>
                  <p>メールアドレス: yamada@kenkokai.example.com</p>
                  <p>パスワード: password123</p>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col">
                <Button className="w-full" size="lg" type="submit" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ログイン中...
                    </>
                  ) : (
                    "ログイン"
                  )}
                </Button>
                <p className="mt-4 text-center text-sm text-muted-foreground">
                  アカウントをお持ちでない方は
                  <Link href="/register" className="text-primary underline underline-offset-4">
                    新規登録
                  </Link>
                  してください
                </p>
              </CardFooter>
            </form>
          </Card>
        </div>
      </main>

      <footer className="w-full border-t py-4">
        <div className="container flex flex-col items-center justify-center gap-2 md:flex-row md:gap-4">
          <p className="text-center text-sm leading-loose text-muted-foreground">
            © 2025 NASRECO. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground underline underline-offset-4">
              利用規約
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground underline underline-offset-4">
              プライバシーポリシー
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
