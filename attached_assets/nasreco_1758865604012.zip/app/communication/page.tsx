"use client"

import { useState, useEffect } from "react"
import { ChatList } from "@/components/communication/chat-list"
import { ChatWindow } from "@/components/communication/chat-window"
import { useMediaQuery } from "@/hooks/use-media-query"

export default function CommunicationPage() {
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null)
  const isMobile = useMediaQuery("(max-width: 768px)")

  // モバイル表示時の処理
  const handleChatSelect = (chatId: string) => {
    setSelectedChatId(chatId)
  }

  const handleBack = () => {
    setSelectedChatId(null)
  }

  // URLからチャットIDを取得する処理（実際の実装ではuseParamsなどを使用）
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const chatId = params.get("chatId")
    if (chatId) {
      setSelectedChatId(chatId)
    }
  }, [])

  // モバイル表示の場合
  if (isMobile) {
    return (
      <div className="h-[calc(100vh-4rem)]">
        {selectedChatId ? <ChatWindow chatId={selectedChatId} onBack={handleBack} isMobile={true} /> : <ChatList />}
      </div>
    )
  }

  // デスクトップ表示の場合
  return (
    <div className="grid grid-cols-[320px_1fr] h-[calc(100vh-4rem)]">
      <ChatList />
      {selectedChatId ? (
        <ChatWindow chatId={selectedChatId} />
      ) : (
        <div className="flex items-center justify-center h-full bg-muted/30">
          <div className="text-center">
            <h3 className="text-lg font-medium">チャットを選択してください</h3>
            <p className="text-muted-foreground">左側のリストからチャットを選択して会話を開始します</p>
          </div>
        </div>
      )}
    </div>
  )
}
