"use client"
import { ChatWindow } from "@/components/communication/chat-window"
import { useRouter } from "next/navigation"

interface ChatPageProps {
  params: {
    id: string
  }
}

export default function ChatPage({ params }: ChatPageProps) {
  const router = useRouter()

  const handleBack = () => {
    router.push("/communication")
  }

  return (
    <div className="h-[calc(100vh-4rem)]">
      <ChatWindow chatId={params.id} onBack={handleBack} />
    </div>
  )
}
