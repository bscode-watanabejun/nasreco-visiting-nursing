"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AutoResponseSettings } from "@/components/communication/auto-response-settings"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"

export default function CommunicationSettingsPage() {
  const [lineApiKey, setLineApiKey] = useState("")
  const [lineChannelSecret, setLineChannelSecret] = useState("")
  const [mcsApiKey, setMcsApiKey] = useState("")
  const [lineIntegrationEnabled, setLineIntegrationEnabled] = useState(false)
  const [mcsIntegrationEnabled, setMcsIntegrationEnabled] = useState(false)

  return (
    <div className="container py-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">コミュニケーション設定</h1>
        <p className="text-muted-foreground">チャット機能や外部連携の設定を管理します。</p>
      </div>

      <Tabs defaultValue="general">
        <TabsList className="mb-4">
          <TabsTrigger value="general">一般設定</TabsTrigger>
          <TabsTrigger value="auto-response">自動応答</TabsTrigger>
          <TabsTrigger value="integrations">外部連携</TabsTrigger>
          <TabsTrigger value="notifications">通知設定</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>一般設定</CardTitle>
              <CardDescription>コミュニケーション機能の基本設定を行います。</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="enable-chat">チャット機能</Label>
                  <p className="text-sm text-muted-foreground">システム内のチャット機能を有効にします。</p>
                </div>
                <Switch id="enable-chat" defaultChecked />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="enable-file-sharing">ファイル共有</Label>
                  <p className="text-sm text-muted-foreground">チャット内でのファイル共有を許可します。</p>
                </div>
                <Switch id="enable-file-sharing" defaultChecked />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="enable-read-receipts">既読通知</Label>
                  <p className="text-sm text-muted-foreground">メッセージの既読状態を表示します。</p>
                </div>
                <Switch id="enable-read-receipts" defaultChecked />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="message-retention">メッセージ保持期間</Label>
                  <p className="text-sm text-muted-foreground">メッセージを保持する期間を設定します。</p>
                </div>
                <div className="w-[180px]">
                  <Input id="message-retention" type="number" min="1" defaultValue="365" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="auto-response">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>自動応答設定</CardTitle>
                <CardDescription>チャットルームごとの自動応答設定を行います。</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">以下のチャットルームの自動応答設定を編集できます。</p>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    社内チャット
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    利用者向けチャット
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    多職種連携チャット
                  </Button>
                </div>
              </CardContent>
            </Card>

            <AutoResponseSettings roomId="default" />
          </div>
        </TabsContent>

        <TabsContent value="integrations">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>LINE連携設定</CardTitle>
                <CardDescription>公式LINEアカウントとの連携設定を行います。</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="enable-line">LINE連携を有効にする</Label>
                    <p className="text-sm text-muted-foreground">公式LINEアカウントとの連携を有効にします。</p>
                  </div>
                  <Switch
                    id="enable-line"
                    checked={lineIntegrationEnabled}
                    onCheckedChange={setLineIntegrationEnabled}
                  />
                </div>

                {lineIntegrationEnabled && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="line-api-key">LINE Messaging API キー</Label>
                      <Input
                        id="line-api-key"
                        value={lineApiKey}
                        onChange={(e) => setLineApiKey(e.target.value)}
                        placeholder="LINE Messaging APIのアクセストークンを入力"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="line-channel-secret">LINEチャンネルシークレット</Label>
                      <Input
                        id="line-channel-secret"
                        value={lineChannelSecret}
                        onChange={(e) => setLineChannelSecret(e.target.value)}
                        type="password"
                        placeholder="LINEチャンネルシークレットを入力"
                      />
                    </div>
                    <Button className="mt-2">LINE連携を設定</Button>
                  </>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>MCS連携設定</CardTitle>
                <CardDescription>メディカルケアステーション(MCS)との連携設定を行います。</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="enable-mcs">MCS連携を有効にする</Label>
                    <p className="text-sm text-muted-foreground">MCSとの連携を有効にします。</p>
                  </div>
                  <Switch id="enable-mcs" checked={mcsIntegrationEnabled} onCheckedChange={setMcsIntegrationEnabled} />
                </div>

                {mcsIntegrationEnabled && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="mcs-api-key">MCS API キー</Label>
                      <Input
                        id="mcs-api-key"
                        value={mcsApiKey}
                        onChange={(e) => setMcsApiKey(e.target.value)}
                        placeholder="MCS APIキーを入力"
                      />
                    </div>
                    <Button className="mt-2">MCS連携を設定</Button>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>通知設定</CardTitle>
              <CardDescription>メッセージ通知の設定を行います。</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="enable-browser-notifications">ブラウザ通知</Label>
                  <p className="text-sm text-muted-foreground">新しいメッセージをブラウザ通知で受け取ります。</p>
                </div>
                <Switch id="enable-browser-notifications" defaultChecked />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="enable-email-notifications">メール通知</Label>
                  <p className="text-sm text-muted-foreground">重要なメッセージをメールで通知します。</p>
                </div>
                <Switch id="enable-email-notifications" />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="enable-sound">通知音</Label>
                  <p className="text-sm text-muted-foreground">新しいメッセージを受信したときに音を鳴らします。</p>
                </div>
                <Switch id="enable-sound" defaultChecked />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="quiet-hours">静音時間</Label>
                  <p className="text-sm text-muted-foreground">指定した時間帯は通知を抑制します。</p>
                </div>
                <Switch id="quiet-hours" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
