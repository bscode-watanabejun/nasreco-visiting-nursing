import { ScheduleCalendar } from "@/components/schedule/schedule-calendar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function SchedulesPage() {
  return (
    <div className="container mx-auto py-6 space-y-6 px-4">
      <h1 className="text-3xl font-bold">訪問スケジュール管理</h1>

      <Tabs defaultValue="calendar">
        <TabsList className="grid w-full grid-cols-1 sm:grid-cols-3">
          <TabsTrigger value="calendar">カレンダー</TabsTrigger>
          <TabsTrigger value="route">ルート最適化</TabsTrigger>
          <TabsTrigger value="recurring">定期訪問管理</TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="mt-6">
          <ScheduleCalendar />
        </TabsContent>

        <TabsContent value="route" className="mt-6">
          <div className="bg-gray-50 border rounded-lg p-8 text-center">
            <h3 className="text-lg font-medium mb-2">ルート最適化</h3>
            <p className="text-gray-500">訪問ルートの最適化機能は現在開発中です。</p>
          </div>
        </TabsContent>

        <TabsContent value="recurring" className="mt-6">
          <div className="bg-gray-50 border rounded-lg p-8 text-center">
            <h3 className="text-lg font-medium mb-2">定期訪問管理</h3>
            <p className="text-gray-500">定期訪問パターンの登録と自動スケジュール生成機能は現在開発中です。</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
