"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ChevronDown, ChevronUp, Camera, Paperclip, Save, Send, MessageSquare, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import type { FormTemplate, TextTemplate } from "@/lib/db/form-schema"

// モックデータ
const mockPatients = [
  { id: "patient-1", name: "佐藤 一郎", age: 68 },
  { id: "patient-2", name: "田中 正男", age: 75 },
  { id: "patient-3", name: "鈴木 良子", age: 82 },
  { id: "patient-4", name: "佐藤 花子", age: 45 },
  { id: "patient-5", name: "高橋 健太", age: 58 },
]

// モックテンプレート
const mockTemplate: FormTemplate = {
  id: "template-1",
  name: "標準訪問記録",
  description: "通常の訪問看護記録用テンプレート",
  type: "visit",
  sections: [
    {
      id: "section-1",
      title: "基本情報",
      fields: [
        { id: "field-1", type: "date", label: "訪問日", isRequired: true, width: "half" },
        { id: "field-2", type: "time", label: "訪問時間", isRequired: true, width: "half" },
        {
          id: "field-3",
          type: "select",
          label: "訪問理由",
          options: [
            { label: "定期訪問", value: "regular" },
            { label: "緊急訪問", value: "emergency" },
            { label: "臨時訪問", value: "extra" },
          ],
          width: "full",
        },
      ],
      order: 0,
      isCollapsible: true,
      isCollapsed: false,
    },
    {
      id: "section-2",
      title: "バイタルサイン",
      fields: [
        { id: "field-4", type: "number", label: "体温", helpText: "℃", width: "third" },
        { id: "field-5", type: "number", label: "脈拍", helpText: "回/分", width: "third" },
        { id: "field-6", type: "number", label: "血圧（収縮期）", helpText: "mmHg", width: "third" },
        { id: "field-7", type: "number", label: "血圧（拡張期）", helpText: "mmHg", width: "third" },
        { id: "field-8", type: "number", label: "SpO2", helpText: "%", width: "third" },
        { id: "field-9", type: "number", label: "呼吸数", helpText: "回/分", width: "third" },
      ],
      order: 1,
      isCollapsible: true,
      isCollapsed: false,
    },
    {
      id: "section-3",
      title: "看護記録",
      fields: [
        { id: "field-10", type: "textarea", label: "観察事項", isRequired: true, width: "full" },
        { id: "field-11", type: "textarea", label: "実施したケア", isRequired: true, width: "full" },
        { id: "field-12", type: "textarea", label: "患者・家族の反応", width: "full" },
        { id: "field-13", type: "media", label: "写真・動画", width: "full" },
      ],
      order: 2,
      isCollapsible: true,
      isCollapsed: false,
    },
  ],
  createdAt: new Date("2025-01-01"),
  updatedAt: new Date("2025-01-01"),
  createdBy: "user-1",
  isActive: true,
  tenantId: "tenant-1",
  version: 1,
}

// モック定型文
const mockTextTemplates: TextTemplate[] = [
  {
    id: "text-1",
    title: "バイタル安定",
    content: "バイタルサインは安定しています。特に異常所見は認められません。",
    category: "観察記録",
    tags: ["バイタル", "一般状態"],
    createdAt: new Date("2025-01-01"),
    updatedAt: new Date("2025-01-01"),
    createdBy: "user-1",
    tenantId: "tenant-1",
    usageCount: 42,
  },
  {
    id: "text-2",
    title: "服薬管理",
    content: "処方薬の管理状況を確認。指示通りに内服できています。残薬の過不足はありません。",
    category: "服薬管理",
    tags: ["服薬", "管理"],
    createdAt: new Date("2025-01-05"),
    updatedAt: new Date("2025-01-05"),
    createdBy: "user-1",
    tenantId: "tenant-1",
    usageCount: 38,
  },
  {
    id: "text-3",
    title: "褥瘡処置",
    content:
      "仙骨部の褥瘡に対し、洗浄・消毒後、指示のあるハイドロコロイド材を貼付しました。発赤の範囲は縮小傾向にあります。",
    category: "処置",
    tags: ["褥瘡", "創傷ケア"],
    createdAt: new Date("2025-01-10"),
    updatedAt: new Date("2025-01-10"),
    createdBy: "user-2",
    tenantId: "tenant-1",
    usageCount: 15,
  },
]

export default function NewRecordPage() {
  const [selectedPatient, setSelectedPatient] = useState<string>("")
  const [formData, setFormData] = useState<Record<string, any>>({})
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({})
  const [activeTab, setActiveTab] = useState<"form" | "preview">("form")
  const [mediaAttachments, setMediaAttachments] = useState<{ id: string; url: string; type: string }[]>([])
  const [openTemplateField, setOpenTemplateField] = useState<string | null>(null)
  const router = useRouter()

  // セクションの折りたたみ状態を初期化
  useEffect(() => {
    const initialCollapsedState: Record<string, boolean> = {}
    mockTemplate.sections.forEach((section) => {
      initialCollapsedState[section.id] = section.isCollapsed || false
    })
    setCollapsedSections(initialCollapsedState)
  }, [])

  // 現在の日時を初期値として設定
  useEffect(() => {
    const now = new Date()
    const today = now.toISOString().split("T")[0]
    const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`

    setFormData({
      ...formData,
      "field-1": today,
      "field-2": currentTime,
    })
  }, [])

  const toggleSection = (sectionId: string) => {
    setCollapsedSections({
      ...collapsedSections,
      [sectionId]: !collapsedSections[sectionId],
    })
  }

  const handleFieldChange = (fieldId: string, value: any) => {
    setFormData({
      ...formData,
      [fieldId]: value,
    })
  }

  const handleMediaUpload = (fieldId: string, files: FileList | null) => {
    if (!files || files.length === 0) return

    // 実際の実装ではファイルをアップロードする処理を実装
    // ここではモックデータを使用
    const newAttachments = Array.from(files).map((file) => ({
      id: `attachment-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      url: URL.createObjectURL(file),
      type: file.type.startsWith("image/") ? "image" : "video",
    }))

    setMediaAttachments([...mediaAttachments, ...newAttachments])
  }

  const handleRemoveMedia = (attachmentId: string) => {
    setMediaAttachments(mediaAttachments.filter((attachment) => attachment.id !== attachmentId))
  }

  const insertTextTemplate = (fieldId: string, content: string) => {
    const currentValue = formData[fieldId] || ""
    const newValue = currentValue ? `${currentValue}\n${content}` : content

    handleFieldChange(fieldId, newValue)
    setOpenTemplateField(null)
  }

  const shouldShowField = (field: any): boolean => {
    if (field.isHidden) return false

    if (field.dependsOn) {
      const { field: dependsOnField, value: dependsOnValue } = field.dependsOn
      return formData[dependsOnField] === dependsOnValue
    }

    return true
  }

  const handleSaveAsDraft = () => {
    // 実際の実装ではAPIを呼び出して下書き保存する処理を実装
    alert("下書きとして保存しました")
    router.push("/records")
  }

  const handleSubmit = () => {
    // 実際の実装ではAPIを呼び出して記録を保存する処理を実装
    alert("記録を保存しました")
    router.push("/records")
  }

  const renderField = (field: any) => {
    if (!shouldShowField(field)) return null

    const fieldWidth = field.width || "full"
    const widthClass = {
      full: "col-span-12",
      half: "col-span-6",
      third: "col-span-4",
    }[fieldWidth]

    return (
      <div key={field.id} className={`${widthClass} space-y-2`}>
        <Label htmlFor={field.id}>
          {field.label}
          {field.isRequired && <span className="text-destructive ml-1">*</span>}
        </Label>

        {field.type === "text" && (
          <Input
            id={field.id}
            placeholder={field.placeholder}
            value={formData[field.id] || ""}
            onChange={(e) => handleFieldChange(field.id, e.target.value)}
            disabled={field.isReadOnly}
          />
        )}

        {field.type === "textarea" && (
          <div className="space-y-2">
            <div className="relative">
              <Textarea
                id={field.id}
                placeholder={field.placeholder}
                value={formData[field.id] || ""}
                onChange={(e) => handleFieldChange(field.id, e.target.value)}
                disabled={field.isReadOnly}
                rows={4}
              />
              <div className="absolute bottom-2 right-2">
                <Popover
                  open={openTemplateField === field.id}
                  onOpenChange={(open) => {
                    if (open) {
                      setOpenTemplateField(field.id)
                    } else {
                      setOpenTemplateField(null)
                    }
                  }}
                >
                  <PopoverTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MessageSquare className="h-4 w-4" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-80 p-0" align="end">
                    <Command>
                      <CommandInput placeholder="定型文を検索..." />
                      <CommandList>
                        <CommandEmpty>定型文が見つかりません</CommandEmpty>
                        {mockTextTemplates.map((template) => (
                          <CommandGroup key={template.id} heading={template.category}>
                            <CommandItem
                              onSelect={() => insertTextTemplate(field.id, template.content)}
                              className="cursor-pointer"
                            >
                              <div>
                                <p className="font-medium">{template.title}</p>
                                <p className="text-xs text-muted-foreground line-clamp-1">{template.content}</p>
                              </div>
                            </CommandItem>
                          </CommandGroup>
                        ))}
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>
        )}

        {field.type === "number" && (
          <Input
            id={field.id}
            type="number"
            placeholder={field.placeholder}
            value={formData[field.id] || ""}
            onChange={(e) => handleFieldChange(field.id, e.target.value)}
            disabled={field.isReadOnly}
          />
        )}

        {field.type === "select" && (
          <Select
            value={formData[field.id] || ""}
            onValueChange={(value) => handleFieldChange(field.id, value)}
            disabled={field.isReadOnly}
          >
            <SelectTrigger id={field.id}>
              <SelectValue placeholder={field.placeholder || "選択してください"} />
            </SelectTrigger>
            <SelectContent>
              {(field.options || []).map((option: any) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        {field.type === "checkbox" && (
          <div className="space-y-2">
            {(field.options || []).map((option: any) => {
              const checkboxId = `${field.id}-${option.value}`
              return (
                <div key={option.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={checkboxId}
                    checked={(formData[field.id] || []).includes(option.value)}
                    onCheckedChange={(checked) => {
                      const currentValues = formData[field.id] || []
                      const newValues = checked
                        ? [...currentValues, option.value]
                        : currentValues.filter((v: string) => v !== option.value)
                      handleFieldChange(field.id, newValues)
                    }}
                    disabled={field.isReadOnly}
                  />
                  <Label htmlFor={checkboxId}>{option.label}</Label>
                </div>
              )
            })}
          </div>
        )}

        {field.type === "radio" && (
          <RadioGroup
            value={formData[field.id] || ""}
            onValueChange={(value) => handleFieldChange(field.id, value)}
            disabled={field.isReadOnly}
          >
            {(field.options || []).map((option: any) => {
              const radioId = `${field.id}-${option.value}`
              return (
                <div key={option.value} className="flex items-center space-x-2">
                  <RadioGroupItem value={option.value} id={radioId} />
                  <Label htmlFor={radioId}>{option.label}</Label>
                </div>
              )
            })}
          </RadioGroup>
        )}

        {field.type === "date" && (
          <Input
            id={field.id}
            type="date"
            value={formData[field.id] || ""}
            onChange={(e) => handleFieldChange(field.id, e.target.value)}
            disabled={field.isReadOnly}
          />
        )}

        {field.type === "time" && (
          <Input
            id={field.id}
            type="time"
            value={formData[field.id] || ""}
            onChange={(e) => handleFieldChange(field.id, e.target.value)}
            disabled={field.isReadOnly}
          />
        )}

        {field.type === "scale" && (
          <div className="pt-4 pb-2">
            <Slider
              id={field.id}
              min={(field.metadata?.min as number) || 0}
              max={(field.metadata?.max as number) || 10}
              step={(field.metadata?.step as number) || 1}
              value={[formData[field.id] || (field.metadata?.min as number) || 0]}
              onValueChange={(value) => handleFieldChange(field.id, value[0])}
              disabled={field.isReadOnly}
            />
            <div className="flex justify-between mt-1 text-xs text-muted-foreground">
              <span>{field.metadata?.min || 0}</span>
              <span>{formData[field.id] || (field.metadata?.min as number) || 0}</span>
              <span>{field.metadata?.max || 10}</span>
            </div>
          </div>
        )}

        {field.type === "media" && (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <label
                htmlFor={`${field.id}-file`}
                className="flex h-10 w-full cursor-pointer items-center justify-center gap-2 rounded-md border border-input bg-background px-3 py-2 text-sm font-medium ring-offset-background hover:bg-accent hover:text-accent-foreground"
              >
                <Paperclip className="h-4 w-4" />
                <span>ファイルを選択</span>
                <input
                  id={`${field.id}-file`}
                  type="file"
                  accept="image/*,video/*"
                  multiple
                  className="hidden"
                  onChange={(e) => handleMediaUpload(field.id, e.target.files)}
                />
              </label>
              <label
                htmlFor={`${field.id}-camera`}
                className="flex h-10 cursor-pointer items-center justify-center gap-2 rounded-md border border-input bg-background px-3 py-2 text-sm font-medium ring-offset-background hover:bg-accent hover:text-accent-foreground"
              >
                <Camera className="h-4 w-4" />
                <span>カメラ</span>
                <input
                  id={`${field.id}-camera`}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={(e) => handleMediaUpload(field.id, e.target.files)}
                />
              </label>
            </div>

            {mediaAttachments.length > 0 && (
              <div className="grid grid-cols-2 gap-2 mt-2">
                {mediaAttachments.map((attachment) => (
                  <div key={attachment.id} className="relative rounded-md overflow-hidden border">
                    {attachment.type === "image" ? (
                      <img
                        src={attachment.url || "/placeholder.svg"}
                        alt="添付画像"
                        className="w-full h-32 object-cover"
                      />
                    ) : (
                      <video src={attachment.url} controls className="w-full h-32 object-cover" />
                    )}
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute top-1 right-1 h-6 w-6"
                      onClick={() => handleRemoveMedia(attachment.id)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {field.helpText && <p className="text-xs text-muted-foreground">{field.helpText}</p>}
      </div>
    )
  }

  const renderSection = (section: any) => {
    const isCollapsed = collapsedSections[section.id]

    return (
      <Card key={section.id} className="mb-4">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle>{section.title}</CardTitle>
            {section.isCollapsible && (
              <Button variant="ghost" size="icon" onClick={() => toggleSection(section.id)}>
                {isCollapsed ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
              </Button>
            )}
          </div>
          {section.description && <CardDescription>{section.description}</CardDescription>}
        </CardHeader>
        {!isCollapsed && (
          <CardContent>
            <div className="grid grid-cols-12 gap-4">{section.fields.map(renderField)}</div>
          </CardContent>
        )}
      </Card>
    )
  }

  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">新規記録作成</h1>
          <p className="text-muted-foreground">訪問看護の記録を作成します</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setActiveTab(activeTab === "form" ? "preview" : "form")}>
            {activeTab === "form" ? "プレビュー" : "編集"}
          </Button>
          <Button variant="outline" onClick={handleSaveAsDraft}>
            <Save className="mr-2 h-4 w-4" />
            下書き保存
          </Button>
          <Button onClick={handleSubmit}>
            <Send className="mr-2 h-4 w-4" />
            送信
          </Button>
        </div>
      </div>

      <div className="flex items-center space-x-2">
        <Label htmlFor="patient-select" className="min-w-32">
          患者を選択:
        </Label>
        <Select value={selectedPatient} onValueChange={setSelectedPatient}>
          <SelectTrigger id="patient-select">
            <SelectValue placeholder="患者を選択してください" />
          </SelectTrigger>
          <SelectContent>
            {mockPatients.map((patient) => (
              <SelectItem key={patient.id} value={patient.id}>
                {patient.name} ({patient.age}歳)
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "form" | "preview")}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="form">フォーム</TabsTrigger>
          <TabsTrigger value="preview">プレビュー</TabsTrigger>
        </TabsList>
        <TabsContent value="form" className="mt-4 space-y-4">
          {mockTemplate.sections.map(renderSection)}
        </TabsContent>
        <TabsContent value="preview" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>記録プレビュー</CardTitle>
              <CardDescription>作成した記録のプレビューです</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h3 className="font-medium">患者情報</h3>
                <p>
                  {selectedPatient
                    ? mockPatients.find((p) => p.id === selectedPatient)?.name || "患者未選択"
                    : "患者未選択"}
                </p>
              </div>

              {mockTemplate.sections.map((section) => (
                <div key={section.id} className="space-y-2">
                  <h3 className="font-medium">{section.title}</h3>
                  <div className="space-y-2">
                    {section.fields.map((field) => {
                      if (!shouldShowField(field)) return null

                      let displayValue = formData[field.id]

                      if (field.type === "select") {
                        const option = field.options?.find((opt: any) => opt.value === displayValue)
                        displayValue = option ? option.label : displayValue
                      }

                      if (field.type === "checkbox" && Array.isArray(displayValue)) {
                        const selectedOptions = field.options
                          ?.filter((opt: any) => displayValue.includes(opt.value))
                          .map((opt: any) => opt.label)
                        displayValue = selectedOptions?.join(", ")
                      }

                      if (field.type === "radio") {
                        const option = field.options?.find((opt: any) => opt.value === displayValue)
                        displayValue = option ? option.label : displayValue
                      }

                      if (field.type === "media") {
                        return (
                          <div key={field.id} className="space-y-1">
                            <p className="text-sm text-muted-foreground">{field.label}</p>
                            {mediaAttachments.length > 0 ? (
                              <div className="grid grid-cols-2 gap-2">
                                {mediaAttachments.map((attachment) => (
                                  <div key={attachment.id} className="rounded-md overflow-hidden border">
                                    {attachment.type === "image" ? (
                                      <img
                                        src={attachment.url || "/placeholder.svg"}
                                        alt="添付画像"
                                        className="w-full h-32 object-cover"
                                      />
                                    ) : (
                                      <video src={attachment.url} controls className="w-full h-32 object-cover" />
                                    )}
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <p className="text-sm">添付ファイルなし</p>
                            )}
                          </div>
                        )
                      }

                      return (
                        <div key={field.id} className="space-y-1">
                          <p className="text-sm text-muted-foreground">{field.label}</p>
                          <p className="text-sm whitespace-pre-line">{displayValue || "未入力"}</p>
                        </div>
                      )
                    })}
                  </div>
                </div>
              ))}
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setActiveTab("form")}>
                編集に戻る
              </Button>
              <div className="flex gap-2">
                <Button variant="outline" onClick={handleSaveAsDraft}>
                  <Save className="mr-2 h-4 w-4" />
                  下書き保存
                </Button>
                <Button onClick={handleSubmit}>
                  <Send className="mr-2 h-4 w-4" />
                  送信
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
