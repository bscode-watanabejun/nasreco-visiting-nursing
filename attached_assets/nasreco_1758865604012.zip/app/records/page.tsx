import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Filter, FileText, Pencil, MoreHorizontal } from "lucide-react"

export default function RecordsPage() {
  // 仮の看護記録データ
  const records = [
    {
      id: 1,
      patient: "佐藤 一郎",
      recordType: "訪問看護記録",
      createdAt: "2025-03-27",
      createdBy: "山田 花子",
      planRef: "No.1",
    },
    {
      id: 2,
      patient: "田中 正男",
      recordType: "訪問看護記録",
      createdAt: "2025-03-26",
      createdBy: "山田 花子",
      planRef: "No.2",
    },
    {
      id: 3,
      patient: "鈴木 良子",
      recordType: "訪問看護記録",
      createdAt: "2025-03-25",
      createdBy: "田中 太郎",
      planRef: "No.1, No.3",
    },
    {
      id: 4,
      patient: "佐藤 花子",
      recordType: "バイタル測定",
      createdAt: "2025-03-24",
      createdBy: "山田 花子",
      planRef: "-",
    },
    {
      id: 5,
      patient: "高橋 健太",
      recordType: "訪問看護記録",
      createdAt: "2025-03-23",
      createdBy: "佐藤 健",
      planRef: "No.2",
    },
  ]

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">看護記録</h2>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          新規記録作成
        </Button>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">すべての記録</TabsTrigger>
          <TabsTrigger value="today">本日の記録</TabsTrigger>
          <TabsTrigger value="incomplete">未完了</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <div className="flex items-center space-x-2">
            <div className="flex-1">
              <Input placeholder="患者名または記録タイプで検索..." />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>看護記録一覧</CardTitle>
              <CardDescription>
                すべての看護記録の一覧です。詳細を確認するには記録をクリックしてください。
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>記録ID</TableHead>
                    <TableHead>患者名</TableHead>
                    <TableHead>記録タイプ</TableHead>
                    <TableHead>作成日</TableHead>
                    <TableHead>作成者</TableHead>
                    <TableHead>計画参照</TableHead>
                    <TableHead>操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {records.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>{record.id}</TableCell>
                      <TableCell className="font-medium">{record.patient}</TableCell>
                      <TableCell>{record.recordType}</TableCell>
                      <TableCell>{record.createdAt}</TableCell>
                      <TableCell>{record.createdBy}</TableCell>
                      <TableCell>{record.planRef}</TableCell>
                      <TableCell>
                        <div className="flex space-x-1">
                          <Button variant="ghost" size="icon">
                            <FileText className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="today">
          <Card>
            <CardHeader>
              <CardTitle>本日の記録</CardTitle>
              <CardDescription>本日作成された看護記録の一覧です。</CardDescription>
            </CardHeader>
            <CardContent>
              <p>本日の記録データがここに表示されます。</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="incomplete">
          <Card>
            <CardHeader>
              <CardTitle>未完了の記録</CardTitle>
              <CardDescription>下書き状態または未完了の看護記録の一覧です。</CardDescription>
            </CardHeader>
            <CardContent>
              <p>未完了の記録データがここに表示されます。</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
