"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { TemplateSelector } from "@/components/records/template-selector"
import { TextSnippetSelector } from "@/components/records/text-snippet-selector"
import { VoiceInput } from "@/components/records/voice-input"
import { VitalSignsInput } from "@/components/records/vital-signs-input"
import {
  Calendar,
  Clock,
  Save,
  FileText,
  User,
  Stethoscope,
  Clipboard,
  Mic,
  PanelLeft,
  PanelRight,
  Activity,
} from "lucide-react"
import type { RecordContent, RecordType, VitalSigns, TextSnippet, RecordTemplate } from "@/lib/db/record-schema"

export default function CreateRecordPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("basic")
  const [showTemplatePanel, setShowTemplatePanel] = useState(false)
  const [showSnippetPanel, setShowSnippetPanel] = useState(false)
  const [recordType, setRecordType] = useState<RecordType>("visit")
  const [patientId, setPatientId] = useState("")
  const [visitDate, setVisitDate] = useState(new Date().toISOString().split("T")[0])
  const [visitTime, setVisitTime] = useState(
    new Date().toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit" }),
  )
  const [recordContent, setRecordContent] = useState<RecordContent>({
    subjective: "",
    objective: "",
    assessment: "",
    plan: "",
    notes: "",
  })
  const [relatedPlans, setRelatedPlans] = useState<string[]>([])

  // テンプレート選択時の処理
  const handleSelectTemplate = (template: RecordTemplate) => {
    setRecordContent((prev) => ({
      ...prev,
      subjective: template.content.subjective || prev.subjective,
      objective: template.content.objective || prev.objective,
      assessment: template.content.assessment || prev.assessment,
      plan: template.content.plan || prev.plan,
    }))
    setShowTemplatePanel(false)
  }

  // 定型文選択時の処理
  const handleSelectSnippet = (snippet: TextSnippet) => {
    // 現在アクティブなフィールドに定型文を挿入
    const activeElement = document.activeElement as HTMLTextAreaElement
    if (activeElement && activeElement.tagName === "TEXTAREA") {
      const fieldName = activeElement.name as keyof RecordContent
      if (fieldName && typeof recordContent[fieldName] === "string") {
        const currentValue = recordContent[fieldName] as string
        const cursorPosition = activeElement.selectionStart || 0
        const newValue =
          currentValue.substring(0, cursorPosition) +
          snippet.content +
          currentValue.substring(activeElement.selectionEnd || cursorPosition)

        setRecordContent((prev) => ({
          ...prev,
          [fieldName]: newValue,
        }))

        // カーソル位置を更新
        setTimeout(() => {
          const newPosition = cursorPosition + snippet.content.length
          activeElement.focus()
          activeElement.setSelectionRange(newPosition, newPosition)
        }, 0)
      }
    }
  }

  // 音声入力の処理
  const handleVoiceTranscript = (field: keyof RecordContent, transcript: string) => {
    setRecordContent((prev) => ({
      ...prev,
      [field]: transcript,
    }))
  }

  // バイタルサイン保存時の処理
  const handleSaveVitalSigns = (vitalSigns: VitalSigns) => {
    setRecordContent((prev) => ({
      ...prev,
      vitalSigns,
    }))
    setActiveTab("soap") // バイタル入力後はSOAPタブに戻る
  }

  // 記録保存時の処理
  const handleSaveRecord = async () => {
    // 実際の実装ではAPIを呼び出して記録を保存
    console.log("記録を保存:", {
      recordType,
      patientId,
      visitDate,
      visitTime,
      content: recordContent,
      relatedPlans,
    })

    // 保存後は記録一覧ページにリダイレクト
    router.push("/records")
  }

  // モックの患者データ
  const patients = [
    { id: "patient-1", name: "佐藤 一郎", age: 68 },
    { id: "patient-2", name: "田中 正男", age: 75 },
    { id: "patient-3", name: "鈴木 良子", age: 82 },
    { id: "patient-4", name: "佐藤 花子", age: 45 },
    { id: "patient-5", name: "高橋 健太", age: 58 },
  ]

  // モックの看護計画データ
  const nursingPlans = [
    { id: "plan-1", title: "非効果的血糖コントロール" },
    { id: "plan-2", title: "心拍出量減少" },
    { id: "plan-3", title: "移動障害" },
    { id: "plan-4", title: "疼痛" },
    { id: "plan-5", title: "非効果的呼吸パターン" },
  ]

  return (
    <div className="container py-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">新規記録作成</h1>
          <p className="text-muted-foreground">訪問看護の記録を作成します。</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => setShowTemplatePanel(!showTemplatePanel)}>
            {showTemplatePanel ? <PanelRight className="mr-2 h-4 w-4" /> : <PanelLeft className="mr-2 h-4 w-4" />}
            テンプレート
          </Button>
          <Button variant="outline" onClick={() => setShowSnippetPanel(!showSnippetPanel)}>
            {showSnippetPanel ? <PanelRight className="mr-2 h-4 w-4" /> : <PanelLeft className="mr-2 h-4 w-4" />}
            定型文
          </Button>
          <Button onClick={handleSaveRecord}>
            <Save className="mr-2 h-4 w-4" />
            保存
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {/* メインコンテンツ */}
        <div
          className={`md:col-span-2 lg:col-span-3 space-y-6 ${showTemplatePanel || showSnippetPanel ? "lg:col-span-2" : ""}`}
        >
          {/* 基本情報 */}
          <Card>
            <CardHeader>
              <CardTitle>基本情報</CardTitle>
              <CardDescription>記録の基本情報を入力してください。</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="record-type" className="flex items-center">
                    <FileText className="mr-2 h-4 w-4" />
                    記録タイプ
                  </Label>
                  <Select value={recordType} onValueChange={(value) => setRecordType(value as RecordType)}>
                    <SelectTrigger id="record-type">
                      <SelectValue placeholder="記録タイプを選択" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="visit">訪問看護記録</SelectItem>
                      <SelectItem value="vital">バイタル測定</SelectItem>
                      <SelectItem value="medication">服薬管理</SelectItem>
                      <SelectItem value="treatment">処置記録</SelectItem>
                      <SelectItem value="assessment">アセスメント</SelectItem>
                      <SelectItem value="plan">看護計画</SelectItem>
                      <SelectItem value="other">その他</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="patient" className="flex items-center">
                    <User className="mr-2 h-4 w-4" />
                    患者
                  </Label>
                  <Select value={patientId} onValueChange={setPatientId}>
                    <SelectTrigger id="patient">
                      <SelectValue placeholder="患者を選択" />
                    </SelectTrigger>
                    <SelectContent>
                      {patients.map((patient) => (
                        <SelectItem key={patient.id} value={patient.id}>
                          {patient.name} ({patient.age}歳)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="visit-date" className="flex items-center">
                    <Calendar className="mr-2 h-4 w-4" />
                    訪問日
                  </Label>
                  <Input id="visit-date" type="date" value={visitDate} onChange={(e) => setVisitDate(e.target.value)} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="visit-time" className="flex items-center">
                    <Clock className="mr-2 h-4 w-4" />
                    訪問時間
                  </Label>
                  <Input id="visit-time" type="time" value={visitTime} onChange={(e) => setVisitTime(e.target.value)} />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="flex items-center">
                  <Clipboard className="mr-2 h-4 w-4" />
                  関連する看護計画
                </Label>
                <div className="grid grid-cols-2 gap-2">
                  {nursingPlans.map((plan) => (
                    <div key={plan.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`plan-${plan.id}`}
                        checked={relatedPlans.includes(plan.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setRelatedPlans([...relatedPlans, plan.id])
                          } else {
                            setRelatedPlans(relatedPlans.filter((id) => id !== plan.id))
                          }
                        }}
                      />
                      <Label htmlFor={`plan-${plan.id}`} className="text-sm">
                        {plan.title}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* タブコンテンツ */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-3">
              <TabsTrigger value="soap" className="flex items-center">
                <Stethoscope className="mr-2 h-4 w-4" />
                SOAP記録
              </TabsTrigger>
              <TabsTrigger value="vital" className="flex items-center">
                <Activity className="mr-2 h-4 w-4" />
                バイタルサイン
              </TabsTrigger>
              <TabsTrigger value="voice" className="flex items-center">
                <Mic className="mr-2 h-4 w-4" />
                音声入力
              </TabsTrigger>
            </TabsList>

            {/* SOAP記録タブ */}
            <TabsContent value="soap" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="subjective" className="text-lg font-medium">
                  S: 主観的情報（患者の訴え）
                </Label>
                <Textarea
                  id="subjective"
                  name="subjective"
                  placeholder="患者さんの訴えや状態について入力してください..."
                  value={recordContent.subjective}
                  onChange={(e) => setRecordContent({ ...recordContent, subjective: e.target.value })}
                  className="min-h-[100px]"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="objective" className="text-lg font-medium">
                  O: 客観的情報（観察・測定結果）
                </Label>
                <Textarea
                  id="objective"
                  name="objective"
                  placeholder="観察した内容や測定結果について入力してください..."
                  value={recordContent.objective}
                  onChange={(e) => setRecordContent({ ...recordContent, objective: e.target.value })}
                  className="min-h-[100px]"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="assessment" className="text-lg font-medium">
                  A: アセスメント（評価）
                </Label>
                <Textarea
                  id="assessment"
                  name="assessment"
                  placeholder="観察結果からのアセスメントを入力してください..."
                  value={recordContent.assessment}
                  onChange={(e) => setRecordContent({ ...recordContent, assessment: e.target.value })}
                  className="min-h-[100px]"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="plan" className="text-lg font-medium">
                  P: 計画
                </Label>
                <Textarea
                  id="plan"
                  name="plan"
                  placeholder="今後の計画や次回の訪問予定について入力してください..."
                  value={recordContent.plan}
                  onChange={(e) => setRecordContent({ ...recordContent, plan: e.target.value })}
                  className="min-h-[100px]"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes" className="text-lg font-medium">
                  備考
                </Label>
                <Textarea
                  id="notes"
                  name="notes"
                  placeholder="その他の特記事項があれば入力してください..."
                  value={recordContent.notes}
                  onChange={(e) => setRecordContent({ ...recordContent, notes: e.target.value })}
                  className="min-h-[100px]"
                />
              </div>
            </TabsContent>

            {/* バイタルサインタブ */}
            <TabsContent value="vital" className="mt-4">
              <VitalSignsInput initialValues={recordContent.vitalSigns} onSave={handleSaveVitalSigns} />
            </TabsContent>

            {/* 音声入力タブ */}
            <TabsContent value="voice" className="space-y-4 mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Mic className="mr-2 h-5 w-5" />
                    音声入力
                  </CardTitle>
                  <CardDescription>
                    音声を認識してテキストに変換します。入力したいフィールドを選択してから音声入力を開始してください。
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>入力先フィールド</Label>
                      <Select defaultValue="subjective">
                        <SelectTrigger>
                          <SelectValue placeholder="入力先を選択" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="subjective">S: 主観的情報</SelectItem>
                          <SelectItem value="objective">O: 客観的情報</SelectItem>
                          <SelectItem value="assessment">A: アセスメント</SelectItem>
                          <SelectItem value="plan">P: 計画</SelectItem>
                          <SelectItem value="notes">備考</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <VoiceInput
                      onTranscriptReady={(transcript) => handleVoiceTranscript("subjective", transcript)}
                      placeholder="音声入力を開始するには「音声入力」ボタンをクリックしてください..."
                      initialText={recordContent.subjective}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => router.push("/records")}>
              キャンセル
            </Button>
            <Button onClick={handleSaveRecord}>
              <Save className="mr-2 h-4 w-4" />
              記録を保存
            </Button>
          </div>
        </div>

        {/* サイドパネル */}
        {showTemplatePanel && (
          <div className="md:col-span-1 h-[calc(100vh-12rem)] sticky top-20">
            <TemplateSelector onSelectTemplate={handleSelectTemplate} recordType={recordType} />
          </div>
        )}

        {showSnippetPanel && (
          <div className="md:col-span-1 h-[calc(100vh-12rem)] sticky top-20">
            <TextSnippetSelector onSelectSnippet={handleSelectSnippet} />
          </div>
        )}
      </div>
    </div>
  )
}
